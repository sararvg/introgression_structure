### quail test using datasets from Sanchez (2012)----

#data load and non parametric tests ----
quail_ds3_N100 <- cbind(rep="quail_ds3_N100", read.table("structure_quail_N100.txt", header=T, dec = "."))
quail_ds3_N100_no0 <- top(quail_ds3_N100, 100, 1, 1)
quail_ds3_N100_ref <- cbind(rep="quail_ds3_N100_ref", read.table("structure_quail_N100_popinfo.txt", header=T, dec = "."))
quail_ds3_N100_ref_no0 <- top(quail_ds3_N100_ref, 100, 1, 1)
require(coin)
wilcoxsign_test(quail_ds3_N100_no0$Structure_q_values ~ quail_ds3_N100_ref_no0$Structure_q_values, paired = TRUE)
wilcoxsign_test(quail_ds3_N100_no0$Structure_q_values ~ quail_ds3_N100_ref_no0$Structure_q_values, paired = TRUE, alternative = "greater")
wilcoxsign_test(quail_ds3_N100_no0$Structure_q_values ~ quail_ds3_N100_ref_no0$Structure_q_values, paired = TRUE, alternative = "less")


colnames(quail_ds3_N100_no0) <- c("rep", "individuals", "label", "q_values_no_ref")
colnames(quail_ds3_N100_ref_no0) <- c("rep", "individuals", "label", "q_values_ref")

quail_no0 <- cbind(quail_ds3_N100_no0, quail_ds3_N100_ref_no0$q_values_ref)
quail_no0 <- cbind (qdif= quail_no0$q_values_no_ref - quail_no0$`quail_ds3_N100_ref_no0$q_values_ref`, quail_no0)

#plots----
library(ggplot2)

plot.quail <- ggplot(data= quail_no0, aes(y=q_values_no_ref, x=quail_ds3_N100_ref_no0$q_values_ref)) +
  theme_bw() + xlab("q without reference") + ylab("q with reference") +
  geom_point(size=2, colour=I(alpha("blue",1/5))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot.quail

