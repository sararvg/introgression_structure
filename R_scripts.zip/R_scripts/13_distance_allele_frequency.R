# figure 5: distance in allele frequency estimates 

#load data fpr each generation and population
setwd('C:/results/freq')

# frequencies generation 0 pop 1 ----
F_P1_G0_R1 <- read.table("freq_pop1_0.1100.0530_1", header=T, dec = ".")
F_P1_G0_R2 <- read.table("freq_pop1_0.1100.0530_2", header=T, dec = ".")
F_P1_G0_R3 <- read.table("freq_pop1_0.1100.0530_3", header=T, dec = ".")
F_P1_G0_R4 <- read.table("freq_pop1_0.1100.0530_4", header=T, dec = ".")
F_P1_G0_R5 <- read.table("freq_pop1_0.1100.0530_5", header=T, dec = ".")
F_P1_G0_R6 <- read.table("freq_pop1_0.1100.0530_6", header=T, dec = ".")
F_P1_G0_R7 <- read.table("freq_pop1_0.1100.0530_7", header=T, dec = ".")
F_P1_G0_R8 <- read.table("freq_pop1_0.1100.0530_8", header=T, dec = ".")
F_P1_G0_R9 <- read.table("freq_pop1_0.1100.0530_9", header=T, dec = ".")
F_P1_G0_R10 <- read.table("freq_pop1_0.1100.0530_10", header=T, dec = ".")
F_P1_G0_R11 <- read.table("freq_pop1_0.1100.0530_11", header=T, dec = ".")
F_P1_G0_R12<- read.table("freq_pop1_0.1100.0530_12", header=T, dec = ".")
F_P1_G0_R13 <- read.table("freq_pop1_0.1100.0530_13", header=T, dec = ".")
F_P1_G0_R14 <- read.table("freq_pop1_0.1100.0530_14", header=T, dec = ".")
F_P1_G0_R15 <- read.table("freq_pop1_0.1100.0530_15", header=T, dec = ".")
F_P1_G0_R16 <- read.table("freq_pop1_0.1100.0530_16", header=T, dec = ".")
F_P1_G0_R17 <- read.table("freq_pop1_0.1100.0530_17", header=T, dec = ".")
F_P1_G0_R18 <- read.table("freq_pop1_0.1100.0530_18", header=T, dec = ".")
F_P1_G0_R19 <- read.table("freq_pop1_0.1100.0530_19", header=T, dec = ".")
F_P1_G0_R20 <- read.table("freq_pop1_0.1100.0530_20", header=T, dec = ".")
F_P1_G0_R21 <- read.table("freq_pop1_0.1100.0530_21", header=T, dec = ".")
F_P1_G0_R22 <- read.table("freq_pop1_0.1100.0530_22", header=T, dec = ".")
F_P1_G0_R23 <- read.table("freq_pop1_0.1100.0530_23", header=T, dec = ".")
F_P1_G0_R24 <- read.table("freq_pop1_0.1100.0530_24", header=T, dec = ".")
F_P1_G0_R25 <- read.table("freq_pop1_0.1100.0530_25", header=T, dec = ".")
F_P1_G0_R26 <- read.table("freq_pop1_0.1100.0530_26", header=T, dec = ".")
F_P1_G0_R27 <- read.table("freq_pop1_0.1100.0530_27", header=T, dec = ".")
F_P1_G0_R28 <- read.table("freq_pop1_0.1100.0530_28", header=T, dec = ".")
F_P1_G0_R29 <- read.table("freq_pop1_0.1100.0530_29", header=T, dec = ".")
F_P1_G0_R30 <- read.table("freq_pop1_0.1100.0530_30", header=T, dec = ".")
F_P1_G0_R31 <- read.table("freq_pop1_0.1100.0530_31", header=T, dec = ".")
F_P1_G0_R32 <- read.table("freq_pop1_0.1100.0530_32", header=T, dec = ".")
F_P1_G0_R33 <- read.table("freq_pop1_0.1100.0530_33", header=T, dec = ".")
F_P1_G0_R34 <- read.table("freq_pop1_0.1100.0530_34", header=T, dec = ".")
F_P1_G0_R35 <- read.table("freq_pop1_0.1100.0530_35", header=T, dec = ".")
F_P1_G0_R36 <- read.table("freq_pop1_0.1100.0530_36", header=T, dec = ".")
F_P1_G0_R37 <- read.table("freq_pop1_0.1100.0530_37", header=T, dec = ".")
F_P1_G0_R38 <- read.table("freq_pop1_0.1100.0530_38", header=T, dec = ".")
F_P1_G0_R39 <- read.table("freq_pop1_0.1100.0530_39", header=T, dec = ".")
F_P1_G0_R40 <- read.table("freq_pop1_0.1100.0530_40", header=T, dec = ".")
F_P1_G0_R41 <- read.table("freq_pop1_0.1100.0530_41", header=T, dec = ".")
F_P1_G0_R42 <- read.table("freq_pop1_0.1100.0530_42", header=T, dec = ".")
F_P1_G0_R43 <- read.table("freq_pop1_0.1100.0530_43", header=T, dec = ".")
F_P1_G0_R44 <- read.table("freq_pop1_0.1100.0530_44", header=T, dec = ".")
F_P1_G0_R45 <- read.table("freq_pop1_0.1100.0530_45", header=T, dec = ".")
F_P1_G0_R46 <- read.table("freq_pop1_0.1100.0530_46", header=T, dec = ".")
F_P1_G0_R47 <- read.table("freq_pop1_0.1100.0530_47", header=T, dec = ".")
F_P1_G0_R48 <- read.table("freq_pop1_0.1100.0530_48", header=T, dec = ".")
F_P1_G0_R49 <- read.table("freq_pop1_0.1100.0530_49", header=T, dec = ".")
F_P1_G0_R50 <- read.table("freq_pop1_0.1100.0530_50", header=T, dec = ".")
F_P1_G0_R51 <- read.table("freq_pop1_0.1100.0530_51", header=T, dec = ".")
F_P1_G0_R52 <- read.table("freq_pop1_0.1100.0530_52", header=T, dec = ".")
F_P1_G0_R53 <- read.table("freq_pop1_0.1100.0530_53", header=T, dec = ".")
F_P1_G0_R54 <- read.table("freq_pop1_0.1100.0530_54", header=T, dec = ".")
F_P1_G0_R55 <- read.table("freq_pop1_0.1100.0530_55", header=T, dec = ".")
F_P1_G0_R56 <- read.table("freq_pop1_0.1100.0530_56", header=T, dec = ".")
F_P1_G0_R57 <- read.table("freq_pop1_0.1100.0530_57", header=T, dec = ".")
F_P1_G0_R58 <- read.table("freq_pop1_0.1100.0530_58", header=T, dec = ".")
F_P1_G0_R59 <- read.table("freq_pop1_0.1100.0530_59", header=T, dec = ".")
F_P1_G0_R60 <- read.table("freq_pop1_0.1100.0530_60", header=T, dec = ".")
F_P1_G0_R61 <- read.table("freq_pop1_0.1100.0530_61", header=T, dec = ".")
F_P1_G0_R62 <- read.table("freq_pop1_0.1100.0530_62", header=T, dec = ".")
F_P1_G0_R63 <- read.table("freq_pop1_0.1100.0530_63", header=T, dec = ".")
F_P1_G0_R64 <- read.table("freq_pop1_0.1100.0530_64", header=T, dec = ".")
F_P1_G0_R65 <- read.table("freq_pop1_0.1100.0530_65", header=T, dec = ".")
F_P1_G0_R66 <- read.table("freq_pop1_0.1100.0530_66", header=T, dec = ".")
F_P1_G0_R67 <- read.table("freq_pop1_0.1100.0530_67", header=T, dec = ".")
F_P1_G0_R68 <- read.table("freq_pop1_0.1100.0530_68", header=T, dec = ".")
F_P1_G0_R69 <- read.table("freq_pop1_0.1100.0530_69", header=T, dec = ".")
F_P1_G0_R70 <- read.table("freq_pop1_0.1100.0530_70", header=T, dec = ".")
F_P1_G0_R71 <- read.table("freq_pop1_0.1100.0530_71", header=T, dec = ".")
F_P1_G0_R72 <- read.table("freq_pop1_0.1100.0530_72", header=T, dec = ".")
F_P1_G0_R73 <- read.table("freq_pop1_0.1100.0530_73", header=T, dec = ".")
F_P1_G0_R74 <- read.table("freq_pop1_0.1100.0530_74", header=T, dec = ".")
F_P1_G0_R75 <- read.table("freq_pop1_0.1100.0530_75", header=T, dec = ".")
F_P1_G0_R76 <- read.table("freq_pop1_0.1100.0530_76", header=T, dec = ".")
F_P1_G0_R77 <- read.table("freq_pop1_0.1100.0530_77", header=T, dec = ".")
F_P1_G0_R78 <- read.table("freq_pop1_0.1100.0530_78", header=T, dec = ".")
F_P1_G0_R79 <- read.table("freq_pop1_0.1100.0530_79", header=T, dec = ".")
F_P1_G0_R80 <- read.table("freq_pop1_0.1100.0530_80", header=T, dec = ".")
F_P1_G0_R81 <- read.table("freq_pop1_0.1100.0530_81", header=T, dec = ".")
F_P1_G0_R82 <- read.table("freq_pop1_0.1100.0530_82", header=T, dec = ".")
F_P1_G0_R83 <- read.table("freq_pop1_0.1100.0530_83", header=T, dec = ".")
F_P1_G0_R84 <- read.table("freq_pop1_0.1100.0530_84", header=T, dec = ".")
F_P1_G0_R85 <- read.table("freq_pop1_0.1100.0530_85", header=T, dec = ".")
F_P1_G0_R86 <- read.table("freq_pop1_0.1100.0530_86", header=T, dec = ".")
F_P1_G0_R87 <- read.table("freq_pop1_0.1100.0530_87", header=T, dec = ".")
F_P1_G0_R88 <- read.table("freq_pop1_0.1100.0530_88", header=T, dec = ".")
F_P1_G0_R89 <- read.table("freq_pop1_0.1100.0530_89", header=T, dec = ".")
F_P1_G0_R90 <- read.table("freq_pop1_0.1100.0530_90", header=T, dec = ".")
F_P1_G0_R91 <- read.table("freq_pop1_0.1100.0530_91", header=T, dec = ".")
F_P1_G0_R92 <- read.table("freq_pop1_0.1100.0530_92", header=T, dec = ".")
F_P1_G0_R93 <- read.table("freq_pop1_0.1100.0530_93", header=T, dec = ".")
F_P1_G0_R94 <- read.table("freq_pop1_0.1100.0530_94", header=T, dec = ".")
F_P1_G0_R95 <- read.table("freq_pop1_0.1100.0530_95", header=T, dec = ".")
F_P1_G0_R96 <- read.table("freq_pop1_0.1100.0530_96", header=T, dec = ".")
F_P1_G0_R97 <- read.table("freq_pop1_0.1100.0530_97", header=T, dec = ".")
F_P1_G0_R98 <- read.table("freq_pop1_0.1100.0530_98", header=T, dec = ".")
F_P1_G0_R99 <- read.table("freq_pop1_0.1100.0530_99", header=T, dec = ".")
F_P1_G0_R100 <- read.table("freq_pop1_0.1100.0530_100", header=T, dec = ".")

# frequencies generation 0 pop 2 ----
F_P2_G0_R1 <- read.table("freq_pop2_0.1100.0530_1", header=T, dec = ".")
F_P2_G0_R2 <- read.table("freq_pop2_0.1100.0530_2", header=T, dec = ".")
F_P2_G0_R3 <- read.table("freq_pop2_0.1100.0530_3", header=T, dec = ".")
F_P2_G0_R4 <- read.table("freq_pop2_0.1100.0530_4", header=T, dec = ".")
F_P2_G0_R5 <- read.table("freq_pop2_0.1100.0530_5", header=T, dec = ".")
F_P2_G0_R6 <- read.table("freq_pop2_0.1100.0530_6", header=T, dec = ".")
F_P2_G0_R7 <- read.table("freq_pop2_0.1100.0530_7", header=T, dec = ".")
F_P2_G0_R8 <- read.table("freq_pop2_0.1100.0530_8", header=T, dec = ".")
F_P2_G0_R9 <- read.table("freq_pop2_0.1100.0530_9", header=T, dec = ".")
F_P2_G0_R10 <- read.table("freq_pop2_0.1100.0530_10", header=T, dec = ".")
F_P2_G0_R11 <- read.table("freq_pop2_0.1100.0530_11", header=T, dec = ".")
F_P2_G0_R12 <- read.table("freq_pop2_0.1100.0530_12", header=T, dec = ".")
F_P2_G0_R13 <- read.table("freq_pop2_0.1100.0530_13", header=T, dec = ".")
F_P2_G0_R14 <- read.table("freq_pop2_0.1100.0530_14", header=T, dec = ".")
F_P2_G0_R15 <- read.table("freq_pop2_0.1100.0530_15", header=T, dec = ".")
F_P2_G0_R16 <- read.table("freq_pop2_0.1100.0530_16", header=T, dec = ".")
F_P2_G0_R17 <- read.table("freq_pop2_0.1100.0530_17", header=T, dec = ".")
F_P2_G0_R18 <- read.table("freq_pop2_0.1100.0530_18", header=T, dec = ".")
F_P2_G0_R19 <- read.table("freq_pop2_0.1100.0530_19", header=T, dec = ".")
F_P2_G0_R20 <- read.table("freq_pop2_0.1100.0530_20", header=T, dec = ".")
F_P2_G0_R21 <- read.table("freq_pop2_0.1100.0530_21", header=T, dec = ".")
F_P2_G0_R22 <- read.table("freq_pop2_0.1100.0530_22", header=T, dec = ".")
F_P2_G0_R23 <- read.table("freq_pop2_0.1100.0530_23", header=T, dec = ".")
F_P2_G0_R24 <- read.table("freq_pop2_0.1100.0530_24", header=T, dec = ".")
F_P2_G0_R25 <- read.table("freq_pop2_0.1100.0530_25", header=T, dec = ".")
F_P2_G0_R26 <- read.table("freq_pop2_0.1100.0530_26", header=T, dec = ".")
F_P2_G0_R27 <- read.table("freq_pop2_0.1100.0530_27", header=T, dec = ".")
F_P2_G0_R28 <- read.table("freq_pop2_0.1100.0530_28", header=T, dec = ".")
F_P2_G0_R29 <- read.table("freq_pop2_0.1100.0530_29", header=T, dec = ".")
F_P2_G0_R30 <- read.table("freq_pop2_0.1100.0530_30", header=T, dec = ".")
F_P2_G0_R31 <- read.table("freq_pop2_0.1100.0530_31", header=T, dec = ".")
F_P2_G0_R32 <- read.table("freq_pop2_0.1100.0530_32", header=T, dec = ".")
F_P2_G0_R33 <- read.table("freq_pop2_0.1100.0530_33", header=T, dec = ".")
F_P2_G0_R34 <- read.table("freq_pop2_0.1100.0530_34", header=T, dec = ".")
F_P2_G0_R35 <- read.table("freq_pop2_0.1100.0530_35", header=T, dec = ".")
F_P2_G0_R36 <- read.table("freq_pop2_0.1100.0530_36", header=T, dec = ".")
F_P2_G0_R37 <- read.table("freq_pop2_0.1100.0530_37", header=T, dec = ".")
F_P2_G0_R38 <- read.table("freq_pop2_0.1100.0530_38", header=T, dec = ".")
F_P2_G0_R39 <- read.table("freq_pop2_0.1100.0530_39", header=T, dec = ".")
F_P2_G0_R40 <- read.table("freq_pop2_0.1100.0530_40", header=T, dec = ".")
F_P2_G0_R41 <- read.table("freq_pop2_0.1100.0530_41", header=T, dec = ".")
F_P2_G0_R42 <- read.table("freq_pop2_0.1100.0530_42", header=T, dec = ".")
F_P2_G0_R43 <- read.table("freq_pop2_0.1100.0530_43", header=T, dec = ".")
F_P2_G0_R44 <- read.table("freq_pop2_0.1100.0530_44", header=T, dec = ".")
F_P2_G0_R45 <- read.table("freq_pop2_0.1100.0530_45", header=T, dec = ".")
F_P2_G0_R46 <- read.table("freq_pop2_0.1100.0530_46", header=T, dec = ".")
F_P2_G0_R47 <- read.table("freq_pop2_0.1100.0530_47", header=T, dec = ".")
F_P2_G0_R48 <- read.table("freq_pop2_0.1100.0530_48", header=T, dec = ".")
F_P2_G0_R49 <- read.table("freq_pop2_0.1100.0530_49", header=T, dec = ".")
F_P2_G0_R50 <- read.table("freq_pop2_0.1100.0530_50", header=T, dec = ".")
F_P2_G0_R51 <- read.table("freq_pop2_0.1100.0530_51", header=T, dec = ".")
F_P2_G0_R52 <- read.table("freq_pop2_0.1100.0530_52", header=T, dec = ".")
F_P2_G0_R53 <- read.table("freq_pop2_0.1100.0530_53", header=T, dec = ".")
F_P2_G0_R54 <- read.table("freq_pop2_0.1100.0530_54", header=T, dec = ".")
F_P2_G0_R55 <- read.table("freq_pop2_0.1100.0530_55", header=T, dec = ".")
F_P2_G0_R56 <- read.table("freq_pop2_0.1100.0530_56", header=T, dec = ".")
F_P2_G0_R57 <- read.table("freq_pop2_0.1100.0530_57", header=T, dec = ".")
F_P2_G0_R58 <- read.table("freq_pop2_0.1100.0530_58", header=T, dec = ".")
F_P2_G0_R59 <- read.table("freq_pop2_0.1100.0530_59", header=T, dec = ".")
F_P2_G0_R60 <- read.table("freq_pop2_0.1100.0530_60", header=T, dec = ".")
F_P2_G0_R61 <- read.table("freq_pop2_0.1100.0530_61", header=T, dec = ".")
F_P2_G0_R62 <- read.table("freq_pop2_0.1100.0530_62", header=T, dec = ".")
F_P2_G0_R63 <- read.table("freq_pop2_0.1100.0530_63", header=T, dec = ".")
F_P2_G0_R64 <- read.table("freq_pop2_0.1100.0530_64", header=T, dec = ".")
F_P2_G0_R65 <- read.table("freq_pop2_0.1100.0530_65", header=T, dec = ".")
F_P2_G0_R66 <- read.table("freq_pop2_0.1100.0530_66", header=T, dec = ".")
F_P2_G0_R67 <- read.table("freq_pop2_0.1100.0530_67", header=T, dec = ".")
F_P2_G0_R68 <- read.table("freq_pop2_0.1100.0530_68", header=T, dec = ".")
F_P2_G0_R69 <- read.table("freq_pop2_0.1100.0530_69", header=T, dec = ".")
F_P2_G0_R70 <- read.table("freq_pop2_0.1100.0530_70", header=T, dec = ".")
F_P2_G0_R71 <- read.table("freq_pop2_0.1100.0530_71", header=T, dec = ".")
F_P2_G0_R72 <- read.table("freq_pop2_0.1100.0530_72", header=T, dec = ".")
F_P2_G0_R73 <- read.table("freq_pop2_0.1100.0530_73", header=T, dec = ".")
F_P2_G0_R74 <- read.table("freq_pop2_0.1100.0530_74", header=T, dec = ".")
F_P2_G0_R75 <- read.table("freq_pop2_0.1100.0530_75", header=T, dec = ".")
F_P2_G0_R76 <- read.table("freq_pop2_0.1100.0530_76", header=T, dec = ".")
F_P2_G0_R77 <- read.table("freq_pop2_0.1100.0530_77", header=T, dec = ".")
F_P2_G0_R78 <- read.table("freq_pop2_0.1100.0530_78", header=T, dec = ".")
F_P2_G0_R79 <- read.table("freq_pop2_0.1100.0530_79", header=T, dec = ".")
F_P2_G0_R80 <- read.table("freq_pop2_0.1100.0530_80", header=T, dec = ".")
F_P2_G0_R81 <- read.table("freq_pop2_0.1100.0530_81", header=T, dec = ".")
F_P2_G0_R82 <- read.table("freq_pop2_0.1100.0530_82", header=T, dec = ".")
F_P2_G0_R83 <- read.table("freq_pop2_0.1100.0530_83", header=T, dec = ".")
F_P2_G0_R84 <- read.table("freq_pop2_0.1100.0530_84", header=T, dec = ".")
F_P2_G0_R85 <- read.table("freq_pop2_0.1100.0530_85", header=T, dec = ".")
F_P2_G0_R86 <- read.table("freq_pop2_0.1100.0530_86", header=T, dec = ".")
F_P2_G0_R87 <- read.table("freq_pop2_0.1100.0530_87", header=T, dec = ".")
F_P2_G0_R88 <- read.table("freq_pop2_0.1100.0530_88", header=T, dec = ".")
F_P2_G0_R89 <- read.table("freq_pop2_0.1100.0530_89", header=T, dec = ".")
F_P2_G0_R90 <- read.table("freq_pop2_0.1100.0530_90", header=T, dec = ".")
F_P2_G0_R91 <- read.table("freq_pop2_0.1100.0530_91", header=T, dec = ".")
F_P2_G0_R92 <- read.table("freq_pop2_0.1100.0530_92", header=T, dec = ".")
F_P2_G0_R93 <- read.table("freq_pop2_0.1100.0530_93", header=T, dec = ".")
F_P2_G0_R94 <- read.table("freq_pop2_0.1100.0530_94", header=T, dec = ".")
F_P2_G0_R95 <- read.table("freq_pop2_0.1100.0530_95", header=T, dec = ".")
F_P2_G0_R96 <- read.table("freq_pop2_0.1100.0530_96", header=T, dec = ".")
F_P2_G0_R97 <- read.table("freq_pop2_0.1100.0530_97", header=T, dec = ".")
F_P2_G0_R98 <- read.table("freq_pop2_0.1100.0530_98", header=T, dec = ".")
F_P2_G0_R99 <- read.table("freq_pop2_0.1100.0530_99", header=T, dec = ".")
F_P2_G0_R100 <- read.table("freq_pop2_0.1100.0530_100", header=T, dec = ".")

# frequencies Structure generation 0 pop 1 ----
FS_P1_G0_R1 <- read.table("freq_Str_pop1_gen0_0.1100.0530_1", header=T, dec = ".")
FS_P1_G0_R2 <- read.table("freq_Str_pop1_gen0_0.1100.0530_2", header=T, dec = ".")
FS_P1_G0_R3 <- read.table("freq_Str_pop1_gen0_0.1100.0530_3", header=T, dec = ".")
FS_P1_G0_R4 <- read.table("freq_Str_pop1_gen0_0.1100.0530_4", header=T, dec = ".")
FS_P1_G0_R5 <- read.table("freq_Str_pop1_gen0_0.1100.0530_5", header=T, dec = ".")
FS_P1_G0_R6 <- read.table("freq_Str_pop1_gen0_0.1100.0530_6", header=T, dec = ".")
FS_P1_G0_R7 <- read.table("freq_Str_pop1_gen0_0.1100.0530_7", header=T, dec = ".")
FS_P1_G0_R8 <- read.table("freq_Str_pop1_gen0_0.1100.0530_8", header=T, dec = ".")
FS_P1_G0_R9 <- read.table("freq_Str_pop1_gen0_0.1100.0530_9", header=T, dec = ".")
FS_P1_G0_R10 <- read.table("freq_Str_pop1_gen0_0.1100.0530_10", header=T, dec = ".")
FS_P1_G0_R11 <- read.table("freq_Str_pop1_gen0_0.1100.0530_11", header=T, dec = ".")
FS_P1_G0_R12 <- read.table("freq_Str_pop1_gen0_0.1100.0530_12", header=T, dec = ".")
FS_P1_G0_R13 <- read.table("freq_Str_pop1_gen0_0.1100.0530_13", header=T, dec = ".")
FS_P1_G0_R14 <- read.table("freq_Str_pop1_gen0_0.1100.0530_14", header=T, dec = ".")
FS_P1_G0_R15 <- read.table("freq_Str_pop1_gen0_0.1100.0530_15", header=T, dec = ".")
FS_P1_G0_R16 <- read.table("freq_Str_pop1_gen0_0.1100.0530_16", header=T, dec = ".")
FS_P1_G0_R17 <- read.table("freq_Str_pop1_gen0_0.1100.0530_17", header=T, dec = ".")
FS_P1_G0_R18 <- read.table("freq_Str_pop1_gen0_0.1100.0530_18", header=T, dec = ".")
FS_P1_G0_R19 <- read.table("freq_Str_pop1_gen0_0.1100.0530_19", header=T, dec = ".")
FS_P1_G0_R20 <- read.table("freq_Str_pop1_gen0_0.1100.0530_20", header=T, dec = ".")
FS_P1_G0_R21 <- read.table("freq_Str_pop1_gen0_0.1100.0530_21", header=T, dec = ".")
FS_P1_G0_R22 <- read.table("freq_Str_pop1_gen0_0.1100.0530_22", header=T, dec = ".")
FS_P1_G0_R23 <- read.table("freq_Str_pop1_gen0_0.1100.0530_23", header=T, dec = ".")
FS_P1_G0_R24 <- read.table("freq_Str_pop1_gen0_0.1100.0530_24", header=T, dec = ".")
FS_P1_G0_R25 <- read.table("freq_Str_pop1_gen0_0.1100.0530_25", header=T, dec = ".")
FS_P1_G0_R26 <- read.table("freq_Str_pop1_gen0_0.1100.0530_26", header=T, dec = ".")
FS_P1_G0_R27 <- read.table("freq_Str_pop1_gen0_0.1100.0530_27", header=T, dec = ".")
FS_P1_G0_R28 <- read.table("freq_Str_pop1_gen0_0.1100.0530_28", header=T, dec = ".")
FS_P1_G0_R29 <- read.table("freq_Str_pop1_gen0_0.1100.0530_29", header=T, dec = ".")
FS_P1_G0_R30 <- read.table("freq_Str_pop1_gen0_0.1100.0530_30", header=T, dec = ".")
FS_P1_G0_R31 <- read.table("freq_Str_pop1_gen0_0.1100.0530_31", header=T, dec = ".")
FS_P1_G0_R32 <- read.table("freq_Str_pop1_gen0_0.1100.0530_32", header=T, dec = ".")
FS_P1_G0_R33 <- read.table("freq_Str_pop1_gen0_0.1100.0530_33", header=T, dec = ".")
FS_P1_G0_R34 <- read.table("freq_Str_pop1_gen0_0.1100.0530_34", header=T, dec = ".")
FS_P1_G0_R35 <- read.table("freq_Str_pop1_gen0_0.1100.0530_35", header=T, dec = ".")
FS_P1_G0_R36 <- read.table("freq_Str_pop1_gen0_0.1100.0530_36", header=T, dec = ".")
FS_P1_G0_R37 <- read.table("freq_Str_pop1_gen0_0.1100.0530_37", header=T, dec = ".")
FS_P1_G0_R38 <- read.table("freq_Str_pop1_gen0_0.1100.0530_38", header=T, dec = ".")
FS_P1_G0_R39 <- read.table("freq_Str_pop1_gen0_0.1100.0530_39", header=T, dec = ".")
FS_P1_G0_R40 <- read.table("freq_Str_pop1_gen0_0.1100.0530_40", header=T, dec = ".")
FS_P1_G0_R41 <- read.table("freq_Str_pop1_gen0_0.1100.0530_41", header=T, dec = ".")
FS_P1_G0_R42 <- read.table("freq_Str_pop1_gen0_0.1100.0530_42", header=T, dec = ".")
FS_P1_G0_R43 <- read.table("freq_Str_pop1_gen0_0.1100.0530_43", header=T, dec = ".")
FS_P1_G0_R44 <- read.table("freq_Str_pop1_gen0_0.1100.0530_44", header=T, dec = ".")
FS_P1_G0_R45 <- read.table("freq_Str_pop1_gen0_0.1100.0530_45", header=T, dec = ".")
FS_P1_G0_R46 <- read.table("freq_Str_pop1_gen0_0.1100.0530_46", header=T, dec = ".")
FS_P1_G0_R47 <- read.table("freq_Str_pop1_gen0_0.1100.0530_47", header=T, dec = ".")
FS_P1_G0_R48 <- read.table("freq_Str_pop1_gen0_0.1100.0530_48", header=T, dec = ".")
FS_P1_G0_R49 <- read.table("freq_Str_pop1_gen0_0.1100.0530_49", header=T, dec = ".")
FS_P1_G0_R50 <- read.table("freq_Str_pop1_gen0_0.1100.0530_50", header=T, dec = ".")
FS_P1_G0_R51 <- read.table("freq_Str_pop1_gen0_0.1100.0530_51", header=T, dec = ".")
FS_P1_G0_R52 <- read.table("freq_Str_pop1_gen0_0.1100.0530_52", header=T, dec = ".")
FS_P1_G0_R53 <- read.table("freq_Str_pop1_gen0_0.1100.0530_53", header=T, dec = ".")
FS_P1_G0_R54 <- read.table("freq_Str_pop1_gen0_0.1100.0530_54", header=T, dec = ".")
FS_P1_G0_R55 <- read.table("freq_Str_pop1_gen0_0.1100.0530_55", header=T, dec = ".")
FS_P1_G0_R56 <- read.table("freq_Str_pop1_gen0_0.1100.0530_56", header=T, dec = ".")
FS_P1_G0_R57 <- read.table("freq_Str_pop1_gen0_0.1100.0530_57", header=T, dec = ".")
FS_P1_G0_R58 <- read.table("freq_Str_pop1_gen0_0.1100.0530_58", header=T, dec = ".")
FS_P1_G0_R59 <- read.table("freq_Str_pop1_gen0_0.1100.0530_59", header=T, dec = ".")
FS_P1_G0_R60 <- read.table("freq_Str_pop1_gen0_0.1100.0530_60", header=T, dec = ".")
FS_P1_G0_R61 <- read.table("freq_Str_pop1_gen0_0.1100.0530_61", header=T, dec = ".")
FS_P1_G0_R62 <- read.table("freq_Str_pop1_gen0_0.1100.0530_62", header=T, dec = ".")
FS_P1_G0_R63 <- read.table("freq_Str_pop1_gen0_0.1100.0530_63", header=T, dec = ".")
FS_P1_G0_R64 <- read.table("freq_Str_pop1_gen0_0.1100.0530_64", header=T, dec = ".")
FS_P1_G0_R65 <- read.table("freq_Str_pop1_gen0_0.1100.0530_65", header=T, dec = ".")
FS_P1_G0_R66 <- read.table("freq_Str_pop1_gen0_0.1100.0530_66", header=T, dec = ".")
FS_P1_G0_R67 <- read.table("freq_Str_pop1_gen0_0.1100.0530_67", header=T, dec = ".")
FS_P1_G0_R68 <- read.table("freq_Str_pop1_gen0_0.1100.0530_68", header=T, dec = ".")
FS_P1_G0_R69 <- read.table("freq_Str_pop1_gen0_0.1100.0530_69", header=T, dec = ".")
FS_P1_G0_R70 <- read.table("freq_Str_pop1_gen0_0.1100.0530_70", header=T, dec = ".")
FS_P1_G0_R71 <- read.table("freq_Str_pop1_gen0_0.1100.0530_71", header=T, dec = ".")
FS_P1_G0_R72 <- read.table("freq_Str_pop1_gen0_0.1100.0530_72", header=T, dec = ".")
FS_P1_G0_R73 <- read.table("freq_Str_pop1_gen0_0.1100.0530_73", header=T, dec = ".")
FS_P1_G0_R74 <- read.table("freq_Str_pop1_gen0_0.1100.0530_74", header=T, dec = ".")
FS_P1_G0_R75 <- read.table("freq_Str_pop1_gen0_0.1100.0530_75", header=T, dec = ".")
FS_P1_G0_R76 <- read.table("freq_Str_pop1_gen0_0.1100.0530_76", header=T, dec = ".")
FS_P1_G0_R77 <- read.table("freq_Str_pop1_gen0_0.1100.0530_77", header=T, dec = ".")
FS_P1_G0_R78 <- read.table("freq_Str_pop1_gen0_0.1100.0530_78", header=T, dec = ".")
FS_P1_G0_R79 <- read.table("freq_Str_pop1_gen0_0.1100.0530_79", header=T, dec = ".")
FS_P1_G0_R80 <- read.table("freq_Str_pop1_gen0_0.1100.0530_80", header=T, dec = ".")
FS_P1_G0_R81 <- read.table("freq_Str_pop1_gen0_0.1100.0530_81", header=T, dec = ".")
FS_P1_G0_R82 <- read.table("freq_Str_pop1_gen0_0.1100.0530_82", header=T, dec = ".")
FS_P1_G0_R83 <- read.table("freq_Str_pop1_gen0_0.1100.0530_83", header=T, dec = ".")
FS_P1_G0_R84 <- read.table("freq_Str_pop1_gen0_0.1100.0530_84", header=T, dec = ".")
FS_P1_G0_R85 <- read.table("freq_Str_pop1_gen0_0.1100.0530_85", header=T, dec = ".")
FS_P1_G0_R86 <- read.table("freq_Str_pop1_gen0_0.1100.0530_86", header=T, dec = ".")
FS_P1_G0_R87 <- read.table("freq_Str_pop1_gen0_0.1100.0530_87", header=T, dec = ".")
FS_P1_G0_R88 <- read.table("freq_Str_pop1_gen0_0.1100.0530_88", header=T, dec = ".")
FS_P1_G0_R89 <- read.table("freq_Str_pop1_gen0_0.1100.0530_89", header=T, dec = ".")
FS_P1_G0_R90 <- read.table("freq_Str_pop1_gen0_0.1100.0530_90", header=T, dec = ".")
FS_P1_G0_R91 <- read.table("freq_Str_pop1_gen0_0.1100.0530_91", header=T, dec = ".")
FS_P1_G0_R92 <- read.table("freq_Str_pop1_gen0_0.1100.0530_92", header=T, dec = ".")
FS_P1_G0_R93 <- read.table("freq_Str_pop1_gen0_0.1100.0530_93", header=T, dec = ".")
FS_P1_G0_R94 <- read.table("freq_Str_pop1_gen0_0.1100.0530_94", header=T, dec = ".")
FS_P1_G0_R95 <- read.table("freq_Str_pop1_gen0_0.1100.0530_95", header=T, dec = ".")
FS_P1_G0_R96 <- read.table("freq_Str_pop1_gen0_0.1100.0530_96", header=T, dec = ".")
FS_P1_G0_R97 <- read.table("freq_Str_pop1_gen0_0.1100.0530_97", header=T, dec = ".")
FS_P1_G0_R98 <- read.table("freq_Str_pop1_gen0_0.1100.0530_98", header=T, dec = ".")
FS_P1_G0_R99 <- read.table("freq_Str_pop1_gen0_0.1100.0530_99", header=T, dec = ".")
FS_P1_G0_R100 <- read.table("freq_Str_pop1_gen0_0.1100.0530_100", header=T, dec = ".")

# frequencies Structure generation 3 pop 1 ----
F_P1_G3_R1 <- read.table("freq_Str_pop1_gen3_0.1100.0530_1", header=T, dec = ".")
F_P1_G3_R2 <- read.table("freq_Str_pop1_gen3_0.1100.0530_2", header=T, dec = ".")
F_P1_G3_R3 <- read.table("freq_Str_pop1_gen3_0.1100.0530_3", header=T, dec = ".")
F_P1_G3_R4 <- read.table("freq_Str_pop1_gen3_0.1100.0530_4", header=T, dec = ".")
F_P1_G3_R5 <- read.table("freq_Str_pop1_gen3_0.1100.0530_5", header=T, dec = ".")
F_P1_G3_R6 <- read.table("freq_Str_pop1_gen3_0.1100.0530_6", header=T, dec = ".")
F_P1_G3_R7 <- read.table("freq_Str_pop1_gen3_0.1100.0530_7", header=T, dec = ".")
F_P1_G3_R8 <- read.table("freq_Str_pop1_gen3_0.1100.0530_8", header=T, dec = ".")
F_P1_G3_R9 <- read.table("freq_Str_pop1_gen3_0.1100.0530_9", header=T, dec = ".")
F_P1_G3_R10 <- read.table("freq_Str_pop1_gen3_0.1100.0530_10", header=T, dec = ".")
F_P1_G3_R11 <- read.table("freq_Str_pop1_gen3_0.1100.0530_11", header=T, dec = ".")
F_P1_G3_R12 <- read.table("freq_Str_pop1_gen3_0.1100.0530_12", header=T, dec = ".")
F_P1_G3_R13 <- read.table("freq_Str_pop1_gen3_0.1100.0530_13", header=T, dec = ".")
F_P1_G3_R14 <- read.table("freq_Str_pop1_gen3_0.1100.0530_14", header=T, dec = ".")
F_P1_G3_R15 <- read.table("freq_Str_pop1_gen3_0.1100.0530_15", header=T, dec = ".")
F_P1_G3_R16 <- read.table("freq_Str_pop1_gen3_0.1100.0530_16", header=T, dec = ".")
F_P1_G3_R17 <- read.table("freq_Str_pop1_gen3_0.1100.0530_17", header=T, dec = ".")
F_P1_G3_R18 <- read.table("freq_Str_pop1_gen3_0.1100.0530_18", header=T, dec = ".")
F_P1_G3_R19 <- read.table("freq_Str_pop1_gen3_0.1100.0530_19", header=T, dec = ".")
F_P1_G3_R20 <- read.table("freq_Str_pop1_gen3_0.1100.0530_20", header=T, dec = ".")
F_P1_G3_R21 <- read.table("freq_Str_pop1_gen3_0.1100.0530_21", header=T, dec = ".")
F_P1_G3_R22 <- read.table("freq_Str_pop1_gen3_0.1100.0530_22", header=T, dec = ".")
F_P1_G3_R23 <- read.table("freq_Str_pop1_gen3_0.1100.0530_23", header=T, dec = ".")
F_P1_G3_R24 <- read.table("freq_Str_pop1_gen3_0.1100.0530_24", header=T, dec = ".")
F_P1_G3_R25 <- read.table("freq_Str_pop1_gen3_0.1100.0530_25", header=T, dec = ".")
F_P1_G3_R26 <- read.table("freq_Str_pop1_gen3_0.1100.0530_26", header=T, dec = ".")
F_P1_G3_R27 <- read.table("freq_Str_pop1_gen3_0.1100.0530_27", header=T, dec = ".")
F_P1_G3_R28 <- read.table("freq_Str_pop1_gen3_0.1100.0530_28", header=T, dec = ".")
F_P1_G3_R29 <- read.table("freq_Str_pop1_gen3_0.1100.0530_29", header=T, dec = ".")
F_P1_G3_R30 <- read.table("freq_Str_pop1_gen3_0.1100.0530_30", header=T, dec = ".")
F_P1_G3_R31 <- read.table("freq_Str_pop1_gen3_0.1100.0530_31", header=T, dec = ".")
F_P1_G3_R32 <- read.table("freq_Str_pop1_gen3_0.1100.0530_32", header=T, dec = ".")
F_P1_G3_R33 <- read.table("freq_Str_pop1_gen3_0.1100.0530_33", header=T, dec = ".")
F_P1_G3_R34 <- read.table("freq_Str_pop1_gen3_0.1100.0530_34", header=T, dec = ".")
F_P1_G3_R35 <- read.table("freq_Str_pop1_gen3_0.1100.0530_35", header=T, dec = ".")
F_P1_G3_R36 <- read.table("freq_Str_pop1_gen3_0.1100.0530_36", header=T, dec = ".")
F_P1_G3_R37 <- read.table("freq_Str_pop1_gen3_0.1100.0530_37", header=T, dec = ".")
F_P1_G3_R38 <- read.table("freq_Str_pop1_gen3_0.1100.0530_38", header=T, dec = ".")
F_P1_G3_R39 <- read.table("freq_Str_pop1_gen3_0.1100.0530_39", header=T, dec = ".")
F_P1_G3_R40 <- read.table("freq_Str_pop1_gen3_0.1100.0530_40", header=T, dec = ".")
F_P1_G3_R41 <- read.table("freq_Str_pop1_gen3_0.1100.0530_41", header=T, dec = ".")
F_P1_G3_R42 <- read.table("freq_Str_pop1_gen3_0.1100.0530_42", header=T, dec = ".")
F_P1_G3_R43 <- read.table("freq_Str_pop1_gen3_0.1100.0530_43", header=T, dec = ".")
F_P1_G3_R44 <- read.table("freq_Str_pop1_gen3_0.1100.0530_44", header=T, dec = ".")
F_P1_G3_R45 <- read.table("freq_Str_pop1_gen3_0.1100.0530_45", header=T, dec = ".")
F_P1_G3_R46 <- read.table("freq_Str_pop1_gen3_0.1100.0530_46", header=T, dec = ".")
F_P1_G3_R47 <- read.table("freq_Str_pop1_gen3_0.1100.0530_47", header=T, dec = ".")
F_P1_G3_R48 <- read.table("freq_Str_pop1_gen3_0.1100.0530_48", header=T, dec = ".")
F_P1_G3_R49 <- read.table("freq_Str_pop1_gen3_0.1100.0530_49", header=T, dec = ".")
F_P1_G3_R50 <- read.table("freq_Str_pop1_gen3_0.1100.0530_50", header=T, dec = ".")
F_P1_G3_R51 <- read.table("freq_Str_pop1_gen3_0.1100.0530_51", header=T, dec = ".")
F_P1_G3_R52 <- read.table("freq_Str_pop1_gen3_0.1100.0530_52", header=T, dec = ".")
F_P1_G3_R53 <- read.table("freq_Str_pop1_gen3_0.1100.0530_53", header=T, dec = ".")
F_P1_G3_R54 <- read.table("freq_Str_pop1_gen3_0.1100.0530_54", header=T, dec = ".")
F_P1_G3_R55 <- read.table("freq_Str_pop1_gen3_0.1100.0530_55", header=T, dec = ".")
F_P1_G3_R56 <- read.table("freq_Str_pop1_gen3_0.1100.0530_56", header=T, dec = ".")
F_P1_G3_R57 <- read.table("freq_Str_pop1_gen3_0.1100.0530_57", header=T, dec = ".")
F_P1_G3_R58 <- read.table("freq_Str_pop1_gen3_0.1100.0530_58", header=T, dec = ".")
F_P1_G3_R59 <- read.table("freq_Str_pop1_gen3_0.1100.0530_59", header=T, dec = ".")
F_P1_G3_R60 <- read.table("freq_Str_pop1_gen3_0.1100.0530_60", header=T, dec = ".")
F_P1_G3_R61 <- read.table("freq_Str_pop1_gen3_0.1100.0530_61", header=T, dec = ".")
F_P1_G3_R62 <- read.table("freq_Str_pop1_gen3_0.1100.0530_62", header=T, dec = ".")
F_P1_G3_R63 <- read.table("freq_Str_pop1_gen3_0.1100.0530_63", header=T, dec = ".")
F_P1_G3_R64 <- read.table("freq_Str_pop1_gen3_0.1100.0530_64", header=T, dec = ".")
F_P1_G3_R65 <- read.table("freq_Str_pop1_gen3_0.1100.0530_65", header=T, dec = ".")
F_P1_G3_R66 <- read.table("freq_Str_pop1_gen3_0.1100.0530_66", header=T, dec = ".")
F_P1_G3_R67 <- read.table("freq_Str_pop1_gen3_0.1100.0530_67", header=T, dec = ".")
F_P1_G3_R68 <- read.table("freq_Str_pop1_gen3_0.1100.0530_68", header=T, dec = ".")
F_P1_G3_R69 <- read.table("freq_Str_pop1_gen3_0.1100.0530_69", header=T, dec = ".")
F_P1_G3_R70 <- read.table("freq_Str_pop1_gen3_0.1100.0530_70", header=T, dec = ".")
F_P1_G3_R71 <- read.table("freq_Str_pop1_gen3_0.1100.0530_71", header=T, dec = ".")
F_P1_G3_R72 <- read.table("freq_Str_pop1_gen3_0.1100.0530_72", header=T, dec = ".")
F_P1_G3_R73 <- read.table("freq_Str_pop1_gen3_0.1100.0530_73", header=T, dec = ".")
F_P1_G3_R74 <- read.table("freq_Str_pop1_gen3_0.1100.0530_74", header=T, dec = ".")
F_P1_G3_R75 <- read.table("freq_Str_pop1_gen3_0.1100.0530_75", header=T, dec = ".")
F_P1_G3_R76 <- read.table("freq_Str_pop1_gen3_0.1100.0530_76", header=T, dec = ".")
F_P1_G3_R77 <- read.table("freq_Str_pop1_gen3_0.1100.0530_77", header=T, dec = ".")
F_P1_G3_R78 <- read.table("freq_Str_pop1_gen3_0.1100.0530_78", header=T, dec = ".")
F_P1_G3_R79 <- read.table("freq_Str_pop1_gen3_0.1100.0530_79", header=T, dec = ".")
F_P1_G3_R80 <- read.table("freq_Str_pop1_gen3_0.1100.0530_80", header=T, dec = ".")
F_P1_G3_R81 <- read.table("freq_Str_pop1_gen3_0.1100.0530_81", header=T, dec = ".")
F_P1_G3_R82 <- read.table("freq_Str_pop1_gen3_0.1100.0530_82", header=T, dec = ".")
F_P1_G3_R83 <- read.table("freq_Str_pop1_gen3_0.1100.0530_83", header=T, dec = ".")
F_P1_G3_R84 <- read.table("freq_Str_pop1_gen3_0.1100.0530_84", header=T, dec = ".")
F_P1_G3_R85 <- read.table("freq_Str_pop1_gen3_0.1100.0530_85", header=T, dec = ".")
F_P1_G3_R86 <- read.table("freq_Str_pop1_gen3_0.1100.0530_86", header=T, dec = ".")
F_P1_G3_R87 <- read.table("freq_Str_pop1_gen3_0.1100.0530_87", header=T, dec = ".")
F_P1_G3_R88 <- read.table("freq_Str_pop1_gen3_0.1100.0530_88", header=T, dec = ".")
F_P1_G3_R89 <- read.table("freq_Str_pop1_gen3_0.1100.0530_89", header=T, dec = ".")
F_P1_G3_R90 <- read.table("freq_Str_pop1_gen3_0.1100.0530_90", header=T, dec = ".")
F_P1_G3_R91 <- read.table("freq_Str_pop1_gen3_0.1100.0530_91", header=T, dec = ".")
F_P1_G3_R92 <- read.table("freq_Str_pop1_gen3_0.1100.0530_92", header=T, dec = ".")
F_P1_G3_R93 <- read.table("freq_Str_pop1_gen3_0.1100.0530_93", header=T, dec = ".")
F_P1_G3_R94 <- read.table("freq_Str_pop1_gen3_0.1100.0530_94", header=T, dec = ".")
F_P1_G3_R95 <- read.table("freq_Str_pop1_gen3_0.1100.0530_95", header=T, dec = ".")
F_P1_G3_R96 <- read.table("freq_Str_pop1_gen3_0.1100.0530_96", header=T, dec = ".")
F_P1_G3_R97 <- read.table("freq_Str_pop1_gen3_0.1100.0530_97", header=T, dec = ".")
F_P1_G3_R98 <- read.table("freq_Str_pop1_gen3_0.1100.0530_98", header=T, dec = ".")
F_P1_G3_R99 <- read.table("freq_Str_pop1_gen3_0.1100.0530_99", header=T, dec = ".")
F_P1_G3_R100 <- read.table("freq_Str_pop1_gen3_0.1100.0530_100", header=T, dec = ".")

# frequencies Structure generation 6 pop 1 ----
F_P1_G6_R1 <- read.table("freq_Str_pop1_gen6_0.1100.0530_1", header=T, dec = ".")
F_P1_G6_R2 <- read.table("freq_Str_pop1_gen6_0.1100.0530_2", header=T, dec = ".")
F_P1_G6_R3 <- read.table("freq_Str_pop1_gen6_0.1100.0530_3", header=T, dec = ".")
F_P1_G6_R4 <- read.table("freq_Str_pop1_gen6_0.1100.0530_4", header=T, dec = ".")
F_P1_G6_R5 <- read.table("freq_Str_pop1_gen6_0.1100.0530_5", header=T, dec = ".")
F_P1_G6_R6 <- read.table("freq_Str_pop1_gen6_0.1100.0530_6", header=T, dec = ".")
F_P1_G6_R7 <- read.table("freq_Str_pop1_gen6_0.1100.0530_7", header=T, dec = ".")
F_P1_G6_R8 <- read.table("freq_Str_pop1_gen6_0.1100.0530_8", header=T, dec = ".")
F_P1_G6_R9 <- read.table("freq_Str_pop1_gen6_0.1100.0530_9", header=T, dec = ".")
F_P1_G6_R10 <- read.table("freq_Str_pop1_gen6_0.1100.0530_10", header=T, dec = ".")
F_P1_G6_R11 <- read.table("freq_Str_pop1_gen6_0.1100.0530_11", header=T, dec = ".")
F_P1_G6_R12 <- read.table("freq_Str_pop1_gen6_0.1100.0530_12", header=T, dec = ".")
F_P1_G6_R13 <- read.table("freq_Str_pop1_gen6_0.1100.0530_13", header=T, dec = ".")
F_P1_G6_R14 <- read.table("freq_Str_pop1_gen6_0.1100.0530_14", header=T, dec = ".")
F_P1_G6_R15 <- read.table("freq_Str_pop1_gen6_0.1100.0530_15", header=T, dec = ".")
F_P1_G6_R16 <- read.table("freq_Str_pop1_gen6_0.1100.0530_16", header=T, dec = ".")
F_P1_G6_R17 <- read.table("freq_Str_pop1_gen6_0.1100.0530_17", header=T, dec = ".")
F_P1_G6_R18 <- read.table("freq_Str_pop1_gen6_0.1100.0530_18", header=T, dec = ".")
F_P1_G6_R19 <- read.table("freq_Str_pop1_gen6_0.1100.0530_19", header=T, dec = ".")
F_P1_G6_R20 <- read.table("freq_Str_pop1_gen6_0.1100.0530_20", header=T, dec = ".")
F_P1_G6_R21 <- read.table("freq_Str_pop1_gen6_0.1100.0530_21", header=T, dec = ".")
F_P1_G6_R22 <- read.table("freq_Str_pop1_gen6_0.1100.0530_22", header=T, dec = ".")
F_P1_G6_R23 <- read.table("freq_Str_pop1_gen6_0.1100.0530_23", header=T, dec = ".")
F_P1_G6_R24 <- read.table("freq_Str_pop1_gen6_0.1100.0530_24", header=T, dec = ".")
F_P1_G6_R25 <- read.table("freq_Str_pop1_gen6_0.1100.0530_25", header=T, dec = ".")
F_P1_G6_R26 <- read.table("freq_Str_pop1_gen6_0.1100.0530_26", header=T, dec = ".")
F_P1_G6_R27 <- read.table("freq_Str_pop1_gen6_0.1100.0530_27", header=T, dec = ".")
F_P1_G6_R28 <- read.table("freq_Str_pop1_gen6_0.1100.0530_28", header=T, dec = ".")
F_P1_G6_R29 <- read.table("freq_Str_pop1_gen6_0.1100.0530_29", header=T, dec = ".")
F_P1_G6_R30 <- read.table("freq_Str_pop1_gen6_0.1100.0530_30", header=T, dec = ".")
F_P1_G6_R31 <- read.table("freq_Str_pop1_gen6_0.1100.0530_31", header=T, dec = ".")
F_P1_G6_R32 <- read.table("freq_Str_pop1_gen6_0.1100.0530_32", header=T, dec = ".")
F_P1_G6_R33 <- read.table("freq_Str_pop1_gen6_0.1100.0530_33", header=T, dec = ".")
F_P1_G6_R34 <- read.table("freq_Str_pop1_gen6_0.1100.0530_34", header=T, dec = ".")
F_P1_G6_R35 <- read.table("freq_Str_pop1_gen6_0.1100.0530_35", header=T, dec = ".")
F_P1_G6_R36 <- read.table("freq_Str_pop1_gen6_0.1100.0530_36", header=T, dec = ".")
F_P1_G6_R37 <- read.table("freq_Str_pop1_gen6_0.1100.0530_37", header=T, dec = ".")
F_P1_G6_R38 <- read.table("freq_Str_pop1_gen6_0.1100.0530_38", header=T, dec = ".")
F_P1_G6_R39 <- read.table("freq_Str_pop1_gen6_0.1100.0530_39", header=T, dec = ".")
F_P1_G6_R40 <- read.table("freq_Str_pop1_gen6_0.1100.0530_40", header=T, dec = ".")
F_P1_G6_R41 <- read.table("freq_Str_pop1_gen6_0.1100.0530_41", header=T, dec = ".")
F_P1_G6_R42 <- read.table("freq_Str_pop1_gen6_0.1100.0530_42", header=T, dec = ".")
F_P1_G6_R43 <- read.table("freq_Str_pop1_gen6_0.1100.0530_43", header=T, dec = ".")
F_P1_G6_R44 <- read.table("freq_Str_pop1_gen6_0.1100.0530_44", header=T, dec = ".")
F_P1_G6_R45 <- read.table("freq_Str_pop1_gen6_0.1100.0530_45", header=T, dec = ".")
F_P1_G6_R46 <- read.table("freq_Str_pop1_gen6_0.1100.0530_46", header=T, dec = ".")
F_P1_G6_R47 <- read.table("freq_Str_pop1_gen6_0.1100.0530_47", header=T, dec = ".")
F_P1_G6_R48 <- read.table("freq_Str_pop1_gen6_0.1100.0530_48", header=T, dec = ".")
F_P1_G6_R49 <- read.table("freq_Str_pop1_gen6_0.1100.0530_49", header=T, dec = ".")
F_P1_G6_R50 <- read.table("freq_Str_pop1_gen6_0.1100.0530_50", header=T, dec = ".")
F_P1_G6_R51 <- read.table("freq_Str_pop1_gen6_0.1100.0530_51", header=T, dec = ".")
F_P1_G6_R52 <- read.table("freq_Str_pop1_gen6_0.1100.0530_52", header=T, dec = ".")
F_P1_G6_R53 <- read.table("freq_Str_pop1_gen6_0.1100.0530_53", header=T, dec = ".")
F_P1_G6_R54 <- read.table("freq_Str_pop1_gen6_0.1100.0530_54", header=T, dec = ".")
F_P1_G6_R55 <- read.table("freq_Str_pop1_gen6_0.1100.0530_55", header=T, dec = ".")
F_P1_G6_R56 <- read.table("freq_Str_pop1_gen6_0.1100.0530_56", header=T, dec = ".")
F_P1_G6_R57 <- read.table("freq_Str_pop1_gen6_0.1100.0530_57", header=T, dec = ".")
F_P1_G6_R58 <- read.table("freq_Str_pop1_gen6_0.1100.0530_58", header=T, dec = ".")
F_P1_G6_R59 <- read.table("freq_Str_pop1_gen6_0.1100.0530_59", header=T, dec = ".")
F_P1_G6_R60 <- read.table("freq_Str_pop1_gen6_0.1100.0530_60", header=T, dec = ".")
F_P1_G6_R61 <- read.table("freq_Str_pop1_gen6_0.1100.0530_61", header=T, dec = ".")
F_P1_G6_R62 <- read.table("freq_Str_pop1_gen6_0.1100.0530_62", header=T, dec = ".")
F_P1_G6_R63 <- read.table("freq_Str_pop1_gen6_0.1100.0530_63", header=T, dec = ".")
F_P1_G6_R64 <- read.table("freq_Str_pop1_gen6_0.1100.0530_64", header=T, dec = ".")
F_P1_G6_R65 <- read.table("freq_Str_pop1_gen6_0.1100.0530_65", header=T, dec = ".")
F_P1_G6_R66 <- read.table("freq_Str_pop1_gen6_0.1100.0530_66", header=T, dec = ".")
F_P1_G6_R67 <- read.table("freq_Str_pop1_gen6_0.1100.0530_67", header=T, dec = ".")
F_P1_G6_R68 <- read.table("freq_Str_pop1_gen6_0.1100.0530_68", header=T, dec = ".")
F_P1_G6_R69 <- read.table("freq_Str_pop1_gen6_0.1100.0530_69", header=T, dec = ".")
F_P1_G6_R70 <- read.table("freq_Str_pop1_gen6_0.1100.0530_70", header=T, dec = ".")
F_P1_G6_R71 <- read.table("freq_Str_pop1_gen6_0.1100.0530_71", header=T, dec = ".")
F_P1_G6_R72 <- read.table("freq_Str_pop1_gen6_0.1100.0530_72", header=T, dec = ".")
F_P1_G6_R73 <- read.table("freq_Str_pop1_gen6_0.1100.0530_73", header=T, dec = ".")
F_P1_G6_R74 <- read.table("freq_Str_pop1_gen6_0.1100.0530_74", header=T, dec = ".")
F_P1_G6_R75 <- read.table("freq_Str_pop1_gen6_0.1100.0530_75", header=T, dec = ".")
F_P1_G6_R76 <- read.table("freq_Str_pop1_gen6_0.1100.0530_76", header=T, dec = ".")
F_P1_G6_R77 <- read.table("freq_Str_pop1_gen6_0.1100.0530_77", header=T, dec = ".")
F_P1_G6_R78 <- read.table("freq_Str_pop1_gen6_0.1100.0530_78", header=T, dec = ".")
F_P1_G6_R79 <- read.table("freq_Str_pop1_gen6_0.1100.0530_79", header=T, dec = ".")
F_P1_G6_R80 <- read.table("freq_Str_pop1_gen6_0.1100.0530_80", header=T, dec = ".")
F_P1_G6_R81 <- read.table("freq_Str_pop1_gen6_0.1100.0530_81", header=T, dec = ".")
F_P1_G6_R82 <- read.table("freq_Str_pop1_gen6_0.1100.0530_82", header=T, dec = ".")
F_P1_G6_R83 <- read.table("freq_Str_pop1_gen6_0.1100.0530_83", header=T, dec = ".")
F_P1_G6_R84 <- read.table("freq_Str_pop1_gen6_0.1100.0530_84", header=T, dec = ".")
F_P1_G6_R85 <- read.table("freq_Str_pop1_gen6_0.1100.0530_85", header=T, dec = ".")
F_P1_G6_R86 <- read.table("freq_Str_pop1_gen6_0.1100.0530_86", header=T, dec = ".")
F_P1_G6_R87 <- read.table("freq_Str_pop1_gen6_0.1100.0530_87", header=T, dec = ".")
F_P1_G6_R88 <- read.table("freq_Str_pop1_gen6_0.1100.0530_88", header=T, dec = ".")
F_P1_G6_R89 <- read.table("freq_Str_pop1_gen6_0.1100.0530_89", header=T, dec = ".")
F_P1_G6_R90 <- read.table("freq_Str_pop1_gen6_0.1100.0530_90", header=T, dec = ".")
F_P1_G6_R91 <- read.table("freq_Str_pop1_gen6_0.1100.0530_91", header=T, dec = ".")
F_P1_G6_R92 <- read.table("freq_Str_pop1_gen6_0.1100.0530_92", header=T, dec = ".")
F_P1_G6_R93 <- read.table("freq_Str_pop1_gen6_0.1100.0530_93", header=T, dec = ".")
F_P1_G6_R94 <- read.table("freq_Str_pop1_gen6_0.1100.0530_94", header=T, dec = ".")
F_P1_G6_R95 <- read.table("freq_Str_pop1_gen6_0.1100.0530_95", header=T, dec = ".")
F_P1_G6_R96 <- read.table("freq_Str_pop1_gen6_0.1100.0530_96", header=T, dec = ".")
F_P1_G6_R97 <- read.table("freq_Str_pop1_gen6_0.1100.0530_97", header=T, dec = ".")
F_P1_G6_R98 <- read.table("freq_Str_pop1_gen6_0.1100.0530_98", header=T, dec = ".")
F_P1_G6_R99 <- read.table("freq_Str_pop1_gen6_0.1100.0530_99", header=T, dec = ".")
F_P1_G6_R100 <- read.table("freq_Str_pop1_gen6_0.1100.0530_100", header=T, dec = ".")

# frequencies Structure generation 10 pop 1 ----
F_P1_G10_R1 <- read.table("freq_Str_pop1_gen10_0.1100.0530_1", header=T, dec = ".")
F_P1_G10_R2 <- read.table("freq_Str_pop1_gen10_0.1100.0530_2", header=T, dec = ".")
F_P1_G10_R3 <- read.table("freq_Str_pop1_gen10_0.1100.0530_3", header=T, dec = ".")
F_P1_G10_R4 <- read.table("freq_Str_pop1_gen10_0.1100.0530_4", header=T, dec = ".")
F_P1_G10_R5 <- read.table("freq_Str_pop1_gen10_0.1100.0530_5", header=T, dec = ".")
F_P1_G10_R6 <- read.table("freq_Str_pop1_gen10_0.1100.0530_6", header=T, dec = ".")
F_P1_G10_R7 <- read.table("freq_Str_pop1_gen10_0.1100.0530_7", header=T, dec = ".")
F_P1_G10_R8 <- read.table("freq_Str_pop1_gen10_0.1100.0530_8", header=T, dec = ".")
F_P1_G10_R9 <- read.table("freq_Str_pop1_gen10_0.1100.0530_9", header=T, dec = ".")
F_P1_G10_R10 <- read.table("freq_Str_pop1_gen10_0.1100.0530_10", header=T, dec = ".")
F_P1_G10_R11 <- read.table("freq_Str_pop1_gen10_0.1100.0530_11", header=T, dec = ".")
F_P1_G10_R12 <- read.table("freq_Str_pop1_gen10_0.1100.0530_12", header=T, dec = ".")
F_P1_G10_R13 <- read.table("freq_Str_pop1_gen10_0.1100.0530_13", header=T, dec = ".")
F_P1_G10_R14 <- read.table("freq_Str_pop1_gen10_0.1100.0530_14", header=T, dec = ".")
F_P1_G10_R15 <- read.table("freq_Str_pop1_gen10_0.1100.0530_15", header=T, dec = ".")
F_P1_G10_R16 <- read.table("freq_Str_pop1_gen10_0.1100.0530_16", header=T, dec = ".")
F_P1_G10_R17 <- read.table("freq_Str_pop1_gen10_0.1100.0530_17", header=T, dec = ".")
F_P1_G10_R18 <- read.table("freq_Str_pop1_gen10_0.1100.0530_18", header=T, dec = ".")
F_P1_G10_R19 <- read.table("freq_Str_pop1_gen10_0.1100.0530_19", header=T, dec = ".")
F_P1_G10_R20 <- read.table("freq_Str_pop1_gen10_0.1100.0530_20", header=T, dec = ".")
F_P1_G10_R21 <- read.table("freq_Str_pop1_gen10_0.1100.0530_21", header=T, dec = ".")
F_P1_G10_R22 <- read.table("freq_Str_pop1_gen10_0.1100.0530_22", header=T, dec = ".")
F_P1_G10_R23 <- read.table("freq_Str_pop1_gen10_0.1100.0530_23", header=T, dec = ".")
F_P1_G10_R24 <- read.table("freq_Str_pop1_gen10_0.1100.0530_24", header=T, dec = ".")
F_P1_G10_R25 <- read.table("freq_Str_pop1_gen10_0.1100.0530_25", header=T, dec = ".")
F_P1_G10_R26 <- read.table("freq_Str_pop1_gen10_0.1100.0530_26", header=T, dec = ".")
F_P1_G10_R27 <- read.table("freq_Str_pop1_gen10_0.1100.0530_27", header=T, dec = ".")
F_P1_G10_R28 <- read.table("freq_Str_pop1_gen10_0.1100.0530_28", header=T, dec = ".")
F_P1_G10_R29 <- read.table("freq_Str_pop1_gen10_0.1100.0530_29", header=T, dec = ".")
F_P1_G10_R30 <- read.table("freq_Str_pop1_gen10_0.1100.0530_30", header=T, dec = ".")
F_P1_G10_R31 <- read.table("freq_Str_pop1_gen10_0.1100.0530_31", header=T, dec = ".")
F_P1_G10_R32 <- read.table("freq_Str_pop1_gen10_0.1100.0530_32", header=T, dec = ".")
F_P1_G10_R33 <- read.table("freq_Str_pop1_gen10_0.1100.0530_33", header=T, dec = ".")
F_P1_G10_R34 <- read.table("freq_Str_pop1_gen10_0.1100.0530_34", header=T, dec = ".")
F_P1_G10_R35 <- read.table("freq_Str_pop1_gen10_0.1100.0530_35", header=T, dec = ".")
F_P1_G10_R36 <- read.table("freq_Str_pop1_gen10_0.1100.0530_36", header=T, dec = ".")
F_P1_G10_R37 <- read.table("freq_Str_pop1_gen10_0.1100.0530_37", header=T, dec = ".")
F_P1_G10_R38 <- read.table("freq_Str_pop1_gen10_0.1100.0530_38", header=T, dec = ".")
F_P1_G10_R39 <- read.table("freq_Str_pop1_gen10_0.1100.0530_39", header=T, dec = ".")
F_P1_G10_R40 <- read.table("freq_Str_pop1_gen10_0.1100.0530_40", header=T, dec = ".")
F_P1_G10_R41 <- read.table("freq_Str_pop1_gen10_0.1100.0530_41", header=T, dec = ".")
F_P1_G10_R42 <- read.table("freq_Str_pop1_gen10_0.1100.0530_42", header=T, dec = ".")
F_P1_G10_R43 <- read.table("freq_Str_pop1_gen10_0.1100.0530_43", header=T, dec = ".")
F_P1_G10_R44 <- read.table("freq_Str_pop1_gen10_0.1100.0530_44", header=T, dec = ".")
F_P1_G10_R45 <- read.table("freq_Str_pop1_gen10_0.1100.0530_45", header=T, dec = ".")
F_P1_G10_R46 <- read.table("freq_Str_pop1_gen10_0.1100.0530_46", header=T, dec = ".")
F_P1_G10_R47 <- read.table("freq_Str_pop1_gen10_0.1100.0530_47", header=T, dec = ".")
F_P1_G10_R48 <- read.table("freq_Str_pop1_gen10_0.1100.0530_48", header=T, dec = ".")
F_P1_G10_R49 <- read.table("freq_Str_pop1_gen10_0.1100.0530_49", header=T, dec = ".")
F_P1_G10_R50 <- read.table("freq_Str_pop1_gen10_0.1100.0530_50", header=T, dec = ".")
F_P1_G10_R51 <- read.table("freq_Str_pop1_gen10_0.1100.0530_51", header=T, dec = ".")
F_P1_G10_R52 <- read.table("freq_Str_pop1_gen10_0.1100.0530_52", header=T, dec = ".")
F_P1_G10_R53 <- read.table("freq_Str_pop1_gen10_0.1100.0530_53", header=T, dec = ".")
F_P1_G10_R54 <- read.table("freq_Str_pop1_gen10_0.1100.0530_54", header=T, dec = ".")
F_P1_G10_R55 <- read.table("freq_Str_pop1_gen10_0.1100.0530_55", header=T, dec = ".")
F_P1_G10_R56 <- read.table("freq_Str_pop1_gen10_0.1100.0530_56", header=T, dec = ".")
F_P1_G10_R57 <- read.table("freq_Str_pop1_gen10_0.1100.0530_57", header=T, dec = ".")
F_P1_G10_R58 <- read.table("freq_Str_pop1_gen10_0.1100.0530_58", header=T, dec = ".")
F_P1_G10_R59 <- read.table("freq_Str_pop1_gen10_0.1100.0530_59", header=T, dec = ".")
F_P1_G10_R60 <- read.table("freq_Str_pop1_gen10_0.1100.0530_60", header=T, dec = ".")
F_P1_G10_R61 <- read.table("freq_Str_pop1_gen10_0.1100.0530_61", header=T, dec = ".")
F_P1_G10_R62 <- read.table("freq_Str_pop1_gen10_0.1100.0530_62", header=T, dec = ".")
F_P1_G10_R63 <- read.table("freq_Str_pop1_gen10_0.1100.0530_63", header=T, dec = ".")
F_P1_G10_R64 <- read.table("freq_Str_pop1_gen10_0.1100.0530_64", header=T, dec = ".")
F_P1_G10_R65 <- read.table("freq_Str_pop1_gen10_0.1100.0530_65", header=T, dec = ".")
F_P1_G10_R66 <- read.table("freq_Str_pop1_gen10_0.1100.0530_66", header=T, dec = ".")
F_P1_G10_R67 <- read.table("freq_Str_pop1_gen10_0.1100.0530_67", header=T, dec = ".")
F_P1_G10_R68 <- read.table("freq_Str_pop1_gen10_0.1100.0530_68", header=T, dec = ".")
F_P1_G10_R69 <- read.table("freq_Str_pop1_gen10_0.1100.0530_69", header=T, dec = ".")
F_P1_G10_R70 <- read.table("freq_Str_pop1_gen10_0.1100.0530_70", header=T, dec = ".")
F_P1_G10_R71 <- read.table("freq_Str_pop1_gen10_0.1100.0530_71", header=T, dec = ".")
F_P1_G10_R72 <- read.table("freq_Str_pop1_gen10_0.1100.0530_72", header=T, dec = ".")
F_P1_G10_R73 <- read.table("freq_Str_pop1_gen10_0.1100.0530_73", header=T, dec = ".")
F_P1_G10_R74 <- read.table("freq_Str_pop1_gen10_0.1100.0530_74", header=T, dec = ".")
F_P1_G10_R75 <- read.table("freq_Str_pop1_gen10_0.1100.0530_75", header=T, dec = ".")
F_P1_G10_R76 <- read.table("freq_Str_pop1_gen10_0.1100.0530_76", header=T, dec = ".")
F_P1_G10_R77 <- read.table("freq_Str_pop1_gen10_0.1100.0530_77", header=T, dec = ".")
F_P1_G10_R78 <- read.table("freq_Str_pop1_gen10_0.1100.0530_78", header=T, dec = ".")
F_P1_G10_R79 <- read.table("freq_Str_pop1_gen10_0.1100.0530_79", header=T, dec = ".")
F_P1_G10_R80 <- read.table("freq_Str_pop1_gen10_0.1100.0530_80", header=T, dec = ".")
F_P1_G10_R81 <- read.table("freq_Str_pop1_gen10_0.1100.0530_81", header=T, dec = ".")
F_P1_G10_R82 <- read.table("freq_Str_pop1_gen10_0.1100.0530_82", header=T, dec = ".")
F_P1_G10_R83 <- read.table("freq_Str_pop1_gen10_0.1100.0530_83", header=T, dec = ".")
F_P1_G10_R84 <- read.table("freq_Str_pop1_gen10_0.1100.0530_84", header=T, dec = ".")
F_P1_G10_R85 <- read.table("freq_Str_pop1_gen10_0.1100.0530_85", header=T, dec = ".")
F_P1_G10_R86 <- read.table("freq_Str_pop1_gen10_0.1100.0530_86", header=T, dec = ".")
F_P1_G10_R87 <- read.table("freq_Str_pop1_gen10_0.1100.0530_87", header=T, dec = ".")
F_P1_G10_R88 <- read.table("freq_Str_pop1_gen10_0.1100.0530_88", header=T, dec = ".")
F_P1_G10_R89 <- read.table("freq_Str_pop1_gen10_0.1100.0530_89", header=T, dec = ".")
F_P1_G10_R90 <- read.table("freq_Str_pop1_gen10_0.1100.0530_90", header=T, dec = ".")
F_P1_G10_R91 <- read.table("freq_Str_pop1_gen10_0.1100.0530_91", header=T, dec = ".")
F_P1_G10_R92 <- read.table("freq_Str_pop1_gen10_0.1100.0530_92", header=T, dec = ".")
F_P1_G10_R93 <- read.table("freq_Str_pop1_gen10_0.1100.0530_93", header=T, dec = ".")
F_P1_G10_R94 <- read.table("freq_Str_pop1_gen10_0.1100.0530_94", header=T, dec = ".")
F_P1_G10_R95 <- read.table("freq_Str_pop1_gen10_0.1100.0530_95", header=T, dec = ".")
F_P1_G10_R96 <- read.table("freq_Str_pop1_gen10_0.1100.0530_96", header=T, dec = ".")
F_P1_G10_R97 <- read.table("freq_Str_pop1_gen10_0.1100.0530_97", header=T, dec = ".")
F_P1_G10_R98 <- read.table("freq_Str_pop1_gen10_0.1100.0530_98", header=T, dec = ".")
F_P1_G10_R99 <- read.table("freq_Str_pop1_gen10_0.1100.0530_99", header=T, dec = ".")
F_P1_G10_R100 <- read.table("freq_Str_pop1_gen10_0.1100.0530_100", header=T, dec = ".")

# frequencies Structure generation 0 pop 2 ----
FS_P2_G0_R1 <- read.table("freq_Str_pop2_gen0_0.1100.0530_1", header=T, dec = ".")
FS_P2_G0_R2 <- read.table("freq_Str_pop2_gen0_0.1100.0530_2", header=T, dec = ".")
FS_P2_G0_R3 <- read.table("freq_Str_pop2_gen0_0.1100.0530_3", header=T, dec = ".")
FS_P2_G0_R4 <- read.table("freq_Str_pop2_gen0_0.1100.0530_4", header=T, dec = ".")
FS_P2_G0_R5 <- read.table("freq_Str_pop2_gen0_0.1100.0530_5", header=T, dec = ".")
FS_P2_G0_R6 <- read.table("freq_Str_pop2_gen0_0.1100.0530_6", header=T, dec = ".")
FS_P2_G0_R7 <- read.table("freq_Str_pop2_gen0_0.1100.0530_7", header=T, dec = ".")
FS_P2_G0_R8 <- read.table("freq_Str_pop2_gen0_0.1100.0530_8", header=T, dec = ".")
FS_P2_G0_R9 <- read.table("freq_Str_pop2_gen0_0.1100.0530_9", header=T, dec = ".")
FS_P2_G0_R10 <- read.table("freq_Str_pop2_gen0_0.1100.0530_10", header=T, dec = ".")
FS_P2_G0_R11 <- read.table("freq_Str_pop2_gen0_0.1100.0530_11", header=T, dec = ".")
FS_P2_G0_R12 <- read.table("freq_Str_pop2_gen0_0.1100.0530_12", header=T, dec = ".")
FS_P2_G0_R13 <- read.table("freq_Str_pop2_gen0_0.1100.0530_13", header=T, dec = ".")
FS_P2_G0_R14 <- read.table("freq_Str_pop2_gen0_0.1100.0530_14", header=T, dec = ".")
FS_P2_G0_R15 <- read.table("freq_Str_pop2_gen0_0.1100.0530_15", header=T, dec = ".")
FS_P2_G0_R16 <- read.table("freq_Str_pop2_gen0_0.1100.0530_16", header=T, dec = ".")
FS_P2_G0_R17 <- read.table("freq_Str_pop2_gen0_0.1100.0530_17", header=T, dec = ".")
FS_P2_G0_R18 <- read.table("freq_Str_pop2_gen0_0.1100.0530_18", header=T, dec = ".")
FS_P2_G0_R19 <- read.table("freq_Str_pop2_gen0_0.1100.0530_19", header=T, dec = ".")
FS_P2_G0_R20 <- read.table("freq_Str_pop2_gen0_0.1100.0530_20", header=T, dec = ".")
FS_P2_G0_R21 <- read.table("freq_Str_pop2_gen0_0.1100.0530_21", header=T, dec = ".")
FS_P2_G0_R22 <- read.table("freq_Str_pop2_gen0_0.1100.0530_22", header=T, dec = ".")
FS_P2_G0_R23 <- read.table("freq_Str_pop2_gen0_0.1100.0530_23", header=T, dec = ".")
FS_P2_G0_R24 <- read.table("freq_Str_pop2_gen0_0.1100.0530_24", header=T, dec = ".")
FS_P2_G0_R25 <- read.table("freq_Str_pop2_gen0_0.1100.0530_25", header=T, dec = ".")
FS_P2_G0_R26 <- read.table("freq_Str_pop2_gen0_0.1100.0530_26", header=T, dec = ".")
FS_P2_G0_R27 <- read.table("freq_Str_pop2_gen0_0.1100.0530_27", header=T, dec = ".")
FS_P2_G0_R28 <- read.table("freq_Str_pop2_gen0_0.1100.0530_28", header=T, dec = ".")
FS_P2_G0_R29 <- read.table("freq_Str_pop2_gen0_0.1100.0530_29", header=T, dec = ".")
FS_P2_G0_R30 <- read.table("freq_Str_pop2_gen0_0.1100.0530_30", header=T, dec = ".")
FS_P2_G0_R31 <- read.table("freq_Str_pop2_gen0_0.1100.0530_31", header=T, dec = ".")
FS_P2_G0_R32 <- read.table("freq_Str_pop2_gen0_0.1100.0530_32", header=T, dec = ".")
FS_P2_G0_R33 <- read.table("freq_Str_pop2_gen0_0.1100.0530_33", header=T, dec = ".")
FS_P2_G0_R34 <- read.table("freq_Str_pop2_gen0_0.1100.0530_34", header=T, dec = ".")
FS_P2_G0_R35 <- read.table("freq_Str_pop2_gen0_0.1100.0530_35", header=T, dec = ".")
FS_P2_G0_R36 <- read.table("freq_Str_pop2_gen0_0.1100.0530_36", header=T, dec = ".")
FS_P2_G0_R37 <- read.table("freq_Str_pop2_gen0_0.1100.0530_37", header=T, dec = ".")
FS_P2_G0_R38 <- read.table("freq_Str_pop2_gen0_0.1100.0530_38", header=T, dec = ".")
FS_P2_G0_R39 <- read.table("freq_Str_pop2_gen0_0.1100.0530_39", header=T, dec = ".")
FS_P2_G0_R40 <- read.table("freq_Str_pop2_gen0_0.1100.0530_40", header=T, dec = ".")
FS_P2_G0_R41 <- read.table("freq_Str_pop2_gen0_0.1100.0530_41", header=T, dec = ".")
FS_P2_G0_R42 <- read.table("freq_Str_pop2_gen0_0.1100.0530_42", header=T, dec = ".")
FS_P2_G0_R43 <- read.table("freq_Str_pop2_gen0_0.1100.0530_43", header=T, dec = ".")
FS_P2_G0_R44 <- read.table("freq_Str_pop2_gen0_0.1100.0530_44", header=T, dec = ".")
FS_P2_G0_R45 <- read.table("freq_Str_pop2_gen0_0.1100.0530_45", header=T, dec = ".")
FS_P2_G0_R46 <- read.table("freq_Str_pop2_gen0_0.1100.0530_46", header=T, dec = ".")
FS_P2_G0_R47 <- read.table("freq_Str_pop2_gen0_0.1100.0530_47", header=T, dec = ".")
FS_P2_G0_R48 <- read.table("freq_Str_pop2_gen0_0.1100.0530_48", header=T, dec = ".")
FS_P2_G0_R49 <- read.table("freq_Str_pop2_gen0_0.1100.0530_49", header=T, dec = ".")
FS_P2_G0_R50 <- read.table("freq_Str_pop2_gen0_0.1100.0530_50", header=T, dec = ".")
FS_P2_G0_R51 <- read.table("freq_Str_pop2_gen0_0.1100.0530_51", header=T, dec = ".")
FS_P2_G0_R52 <- read.table("freq_Str_pop2_gen0_0.1100.0530_52", header=T, dec = ".")
FS_P2_G0_R53 <- read.table("freq_Str_pop2_gen0_0.1100.0530_53", header=T, dec = ".")
FS_P2_G0_R54 <- read.table("freq_Str_pop2_gen0_0.1100.0530_54", header=T, dec = ".")
FS_P2_G0_R55 <- read.table("freq_Str_pop2_gen0_0.1100.0530_55", header=T, dec = ".")
FS_P2_G0_R56 <- read.table("freq_Str_pop2_gen0_0.1100.0530_56", header=T, dec = ".")
FS_P2_G0_R57 <- read.table("freq_Str_pop2_gen0_0.1100.0530_57", header=T, dec = ".")
FS_P2_G0_R58 <- read.table("freq_Str_pop2_gen0_0.1100.0530_58", header=T, dec = ".")
FS_P2_G0_R59 <- read.table("freq_Str_pop2_gen0_0.1100.0530_59", header=T, dec = ".")
FS_P2_G0_R60 <- read.table("freq_Str_pop2_gen0_0.1100.0530_60", header=T, dec = ".")
FS_P2_G0_R61 <- read.table("freq_Str_pop2_gen0_0.1100.0530_61", header=T, dec = ".")
FS_P2_G0_R62 <- read.table("freq_Str_pop2_gen0_0.1100.0530_62", header=T, dec = ".")
FS_P2_G0_R63 <- read.table("freq_Str_pop2_gen0_0.1100.0530_63", header=T, dec = ".")
FS_P2_G0_R64 <- read.table("freq_Str_pop2_gen0_0.1100.0530_64", header=T, dec = ".")
FS_P2_G0_R65 <- read.table("freq_Str_pop2_gen0_0.1100.0530_65", header=T, dec = ".")
FS_P2_G0_R66 <- read.table("freq_Str_pop2_gen0_0.1100.0530_66", header=T, dec = ".")
FS_P2_G0_R67 <- read.table("freq_Str_pop2_gen0_0.1100.0530_67", header=T, dec = ".")
FS_P2_G0_R68 <- read.table("freq_Str_pop2_gen0_0.1100.0530_68", header=T, dec = ".")
FS_P2_G0_R69 <- read.table("freq_Str_pop2_gen0_0.1100.0530_69", header=T, dec = ".")
FS_P2_G0_R70 <- read.table("freq_Str_pop2_gen0_0.1100.0530_70", header=T, dec = ".")
FS_P2_G0_R71 <- read.table("freq_Str_pop2_gen0_0.1100.0530_71", header=T, dec = ".")
FS_P2_G0_R72 <- read.table("freq_Str_pop2_gen0_0.1100.0530_72", header=T, dec = ".")
FS_P2_G0_R73 <- read.table("freq_Str_pop2_gen0_0.1100.0530_73", header=T, dec = ".")
FS_P2_G0_R74 <- read.table("freq_Str_pop2_gen0_0.1100.0530_74", header=T, dec = ".")
FS_P2_G0_R75 <- read.table("freq_Str_pop2_gen0_0.1100.0530_75", header=T, dec = ".")
FS_P2_G0_R76 <- read.table("freq_Str_pop2_gen0_0.1100.0530_76", header=T, dec = ".")
FS_P2_G0_R77 <- read.table("freq_Str_pop2_gen0_0.1100.0530_77", header=T, dec = ".")
FS_P2_G0_R78 <- read.table("freq_Str_pop2_gen0_0.1100.0530_78", header=T, dec = ".")
FS_P2_G0_R79 <- read.table("freq_Str_pop2_gen0_0.1100.0530_79", header=T, dec = ".")
FS_P2_G0_R80 <- read.table("freq_Str_pop2_gen0_0.1100.0530_80", header=T, dec = ".")
FS_P2_G0_R81 <- read.table("freq_Str_pop2_gen0_0.1100.0530_81", header=T, dec = ".")
FS_P2_G0_R82 <- read.table("freq_Str_pop2_gen0_0.1100.0530_82", header=T, dec = ".")
FS_P2_G0_R83 <- read.table("freq_Str_pop2_gen0_0.1100.0530_83", header=T, dec = ".")
FS_P2_G0_R84 <- read.table("freq_Str_pop2_gen0_0.1100.0530_84", header=T, dec = ".")
FS_P2_G0_R85 <- read.table("freq_Str_pop2_gen0_0.1100.0530_85", header=T, dec = ".")
FS_P2_G0_R86 <- read.table("freq_Str_pop2_gen0_0.1100.0530_86", header=T, dec = ".")
FS_P2_G0_R87 <- read.table("freq_Str_pop2_gen0_0.1100.0530_87", header=T, dec = ".")
FS_P2_G0_R88 <- read.table("freq_Str_pop2_gen0_0.1100.0530_88", header=T, dec = ".")
FS_P2_G0_R89 <- read.table("freq_Str_pop2_gen0_0.1100.0530_89", header=T, dec = ".")
FS_P2_G0_R90 <- read.table("freq_Str_pop2_gen0_0.1100.0530_90", header=T, dec = ".")
FS_P2_G0_R91 <- read.table("freq_Str_pop2_gen0_0.1100.0530_91", header=T, dec = ".")
FS_P2_G0_R92 <- read.table("freq_Str_pop2_gen0_0.1100.0530_92", header=T, dec = ".")
FS_P2_G0_R93 <- read.table("freq_Str_pop2_gen0_0.1100.0530_93", header=T, dec = ".")
FS_P2_G0_R94 <- read.table("freq_Str_pop2_gen0_0.1100.0530_94", header=T, dec = ".")
FS_P2_G0_R95 <- read.table("freq_Str_pop2_gen0_0.1100.0530_95", header=T, dec = ".")
FS_P2_G0_R96 <- read.table("freq_Str_pop2_gen0_0.1100.0530_96", header=T, dec = ".")
FS_P2_G0_R97 <- read.table("freq_Str_pop2_gen0_0.1100.0530_97", header=T, dec = ".")
FS_P2_G0_R98 <- read.table("freq_Str_pop2_gen0_0.1100.0530_98", header=T, dec = ".")
FS_P2_G0_R99 <- read.table("freq_Str_pop2_gen0_0.1100.0530_99", header=T, dec = ".")
FS_P2_G0_R100 <- read.table("freq_Str_pop2_gen0_0.1100.0530_100", header=T, dec = ".")

# frequencies Structure generation 3 pop 2 ----
F_P2_G3_R1 <- read.table("freq_Str_pop2_gen3_0.1100.0530_1", header=T, dec = ".")
F_P2_G3_R2 <- read.table("freq_Str_pop2_gen3_0.1100.0530_2", header=T, dec = ".")
F_P2_G3_R3 <- read.table("freq_Str_pop2_gen3_0.1100.0530_3", header=T, dec = ".")
F_P2_G3_R4 <- read.table("freq_Str_pop2_gen3_0.1100.0530_4", header=T, dec = ".")
F_P2_G3_R5 <- read.table("freq_Str_pop2_gen3_0.1100.0530_5", header=T, dec = ".")
F_P2_G3_R6 <- read.table("freq_Str_pop2_gen3_0.1100.0530_6", header=T, dec = ".")
F_P2_G3_R7 <- read.table("freq_Str_pop2_gen3_0.1100.0530_7", header=T, dec = ".")
F_P2_G3_R8 <- read.table("freq_Str_pop2_gen3_0.1100.0530_8", header=T, dec = ".")
F_P2_G3_R9 <- read.table("freq_Str_pop2_gen3_0.1100.0530_9", header=T, dec = ".")
F_P2_G3_R10 <- read.table("freq_Str_pop2_gen3_0.1100.0530_10", header=T, dec = ".")
F_P2_G3_R11 <- read.table("freq_Str_pop2_gen3_0.1100.0530_11", header=T, dec = ".")
F_P2_G3_R12 <- read.table("freq_Str_pop2_gen3_0.1100.0530_12", header=T, dec = ".")
F_P2_G3_R13 <- read.table("freq_Str_pop2_gen3_0.1100.0530_13", header=T, dec = ".")
F_P2_G3_R14 <- read.table("freq_Str_pop2_gen3_0.1100.0530_14", header=T, dec = ".")
F_P2_G3_R15 <- read.table("freq_Str_pop2_gen3_0.1100.0530_15", header=T, dec = ".")
F_P2_G3_R16 <- read.table("freq_Str_pop2_gen3_0.1100.0530_16", header=T, dec = ".")
F_P2_G3_R17 <- read.table("freq_Str_pop2_gen3_0.1100.0530_17", header=T, dec = ".")
F_P2_G3_R18 <- read.table("freq_Str_pop2_gen3_0.1100.0530_18", header=T, dec = ".")
F_P2_G3_R19 <- read.table("freq_Str_pop2_gen3_0.1100.0530_19", header=T, dec = ".")
F_P2_G3_R20 <- read.table("freq_Str_pop2_gen3_0.1100.0530_20", header=T, dec = ".")
F_P2_G3_R21 <- read.table("freq_Str_pop2_gen3_0.1100.0530_21", header=T, dec = ".")
F_P2_G3_R22 <- read.table("freq_Str_pop2_gen3_0.1100.0530_22", header=T, dec = ".")
F_P2_G3_R23 <- read.table("freq_Str_pop2_gen3_0.1100.0530_23", header=T, dec = ".")
F_P2_G3_R24 <- read.table("freq_Str_pop2_gen3_0.1100.0530_24", header=T, dec = ".")
F_P2_G3_R25 <- read.table("freq_Str_pop2_gen3_0.1100.0530_25", header=T, dec = ".")
F_P2_G3_R26 <- read.table("freq_Str_pop2_gen3_0.1100.0530_26", header=T, dec = ".")
F_P2_G3_R27 <- read.table("freq_Str_pop2_gen3_0.1100.0530_27", header=T, dec = ".")
F_P2_G3_R28 <- read.table("freq_Str_pop2_gen3_0.1100.0530_28", header=T, dec = ".")
F_P2_G3_R29 <- read.table("freq_Str_pop2_gen3_0.1100.0530_29", header=T, dec = ".")
F_P2_G3_R30 <- read.table("freq_Str_pop2_gen3_0.1100.0530_30", header=T, dec = ".")
F_P2_G3_R31 <- read.table("freq_Str_pop2_gen3_0.1100.0530_31", header=T, dec = ".")
F_P2_G3_R32 <- read.table("freq_Str_pop2_gen3_0.1100.0530_32", header=T, dec = ".")
F_P2_G3_R33 <- read.table("freq_Str_pop2_gen3_0.1100.0530_33", header=T, dec = ".")
F_P2_G3_R34 <- read.table("freq_Str_pop2_gen3_0.1100.0530_34", header=T, dec = ".")
F_P2_G3_R35 <- read.table("freq_Str_pop2_gen3_0.1100.0530_35", header=T, dec = ".")
F_P2_G3_R36 <- read.table("freq_Str_pop2_gen3_0.1100.0530_36", header=T, dec = ".")
F_P2_G3_R37 <- read.table("freq_Str_pop2_gen3_0.1100.0530_37", header=T, dec = ".")
F_P2_G3_R38 <- read.table("freq_Str_pop2_gen3_0.1100.0530_38", header=T, dec = ".")
F_P2_G3_R39 <- read.table("freq_Str_pop2_gen3_0.1100.0530_39", header=T, dec = ".")
F_P2_G3_R40 <- read.table("freq_Str_pop2_gen3_0.1100.0530_40", header=T, dec = ".")
F_P2_G3_R41 <- read.table("freq_Str_pop2_gen3_0.1100.0530_41", header=T, dec = ".")
F_P2_G3_R42 <- read.table("freq_Str_pop2_gen3_0.1100.0530_42", header=T, dec = ".")
F_P2_G3_R43 <- read.table("freq_Str_pop2_gen3_0.1100.0530_43", header=T, dec = ".")
F_P2_G3_R44 <- read.table("freq_Str_pop2_gen3_0.1100.0530_44", header=T, dec = ".")
F_P2_G3_R45 <- read.table("freq_Str_pop2_gen3_0.1100.0530_45", header=T, dec = ".")
F_P2_G3_R46 <- read.table("freq_Str_pop2_gen3_0.1100.0530_46", header=T, dec = ".")
F_P2_G3_R47 <- read.table("freq_Str_pop2_gen3_0.1100.0530_47", header=T, dec = ".")
F_P2_G3_R48 <- read.table("freq_Str_pop2_gen3_0.1100.0530_48", header=T, dec = ".")
F_P2_G3_R49 <- read.table("freq_Str_pop2_gen3_0.1100.0530_49", header=T, dec = ".")
F_P2_G3_R50 <- read.table("freq_Str_pop2_gen3_0.1100.0530_50", header=T, dec = ".")
F_P2_G3_R51 <- read.table("freq_Str_pop2_gen3_0.1100.0530_51", header=T, dec = ".")
F_P2_G3_R52 <- read.table("freq_Str_pop2_gen3_0.1100.0530_52", header=T, dec = ".")
F_P2_G3_R53 <- read.table("freq_Str_pop2_gen3_0.1100.0530_53", header=T, dec = ".")
F_P2_G3_R54 <- read.table("freq_Str_pop2_gen3_0.1100.0530_54", header=T, dec = ".")
F_P2_G3_R55 <- read.table("freq_Str_pop2_gen3_0.1100.0530_55", header=T, dec = ".")
F_P2_G3_R56 <- read.table("freq_Str_pop2_gen3_0.1100.0530_56", header=T, dec = ".")
F_P2_G3_R57 <- read.table("freq_Str_pop2_gen3_0.1100.0530_57", header=T, dec = ".")
F_P2_G3_R58 <- read.table("freq_Str_pop2_gen3_0.1100.0530_58", header=T, dec = ".")
F_P2_G3_R59 <- read.table("freq_Str_pop2_gen3_0.1100.0530_59", header=T, dec = ".")
F_P2_G3_R60 <- read.table("freq_Str_pop2_gen3_0.1100.0530_60", header=T, dec = ".")
F_P2_G3_R61 <- read.table("freq_Str_pop2_gen3_0.1100.0530_61", header=T, dec = ".")
F_P2_G3_R62 <- read.table("freq_Str_pop2_gen3_0.1100.0530_62", header=T, dec = ".")
F_P2_G3_R63 <- read.table("freq_Str_pop2_gen3_0.1100.0530_63", header=T, dec = ".")
F_P2_G3_R64 <- read.table("freq_Str_pop2_gen3_0.1100.0530_64", header=T, dec = ".")
F_P2_G3_R65 <- read.table("freq_Str_pop2_gen3_0.1100.0530_65", header=T, dec = ".")
F_P2_G3_R66 <- read.table("freq_Str_pop2_gen3_0.1100.0530_66", header=T, dec = ".")
F_P2_G3_R67 <- read.table("freq_Str_pop2_gen3_0.1100.0530_67", header=T, dec = ".")
F_P2_G3_R68 <- read.table("freq_Str_pop2_gen3_0.1100.0530_68", header=T, dec = ".")
F_P2_G3_R69 <- read.table("freq_Str_pop2_gen3_0.1100.0530_69", header=T, dec = ".")
F_P2_G3_R70 <- read.table("freq_Str_pop2_gen3_0.1100.0530_70", header=T, dec = ".")
F_P2_G3_R71 <- read.table("freq_Str_pop2_gen3_0.1100.0530_71", header=T, dec = ".")
F_P2_G3_R72 <- read.table("freq_Str_pop2_gen3_0.1100.0530_72", header=T, dec = ".")
F_P2_G3_R73 <- read.table("freq_Str_pop2_gen3_0.1100.0530_73", header=T, dec = ".")
F_P2_G3_R74 <- read.table("freq_Str_pop2_gen3_0.1100.0530_74", header=T, dec = ".")
F_P2_G3_R75 <- read.table("freq_Str_pop2_gen3_0.1100.0530_75", header=T, dec = ".")
F_P2_G3_R76 <- read.table("freq_Str_pop2_gen3_0.1100.0530_76", header=T, dec = ".")
F_P2_G3_R77 <- read.table("freq_Str_pop2_gen3_0.1100.0530_77", header=T, dec = ".")
F_P2_G3_R78 <- read.table("freq_Str_pop2_gen3_0.1100.0530_78", header=T, dec = ".")
F_P2_G3_R79 <- read.table("freq_Str_pop2_gen3_0.1100.0530_79", header=T, dec = ".")
F_P2_G3_R80 <- read.table("freq_Str_pop2_gen3_0.1100.0530_80", header=T, dec = ".")
F_P2_G3_R81 <- read.table("freq_Str_pop2_gen3_0.1100.0530_81", header=T, dec = ".")
F_P2_G3_R82 <- read.table("freq_Str_pop2_gen3_0.1100.0530_82", header=T, dec = ".")
F_P2_G3_R83 <- read.table("freq_Str_pop2_gen3_0.1100.0530_83", header=T, dec = ".")
F_P2_G3_R84 <- read.table("freq_Str_pop2_gen3_0.1100.0530_84", header=T, dec = ".")
F_P2_G3_R85 <- read.table("freq_Str_pop2_gen3_0.1100.0530_85", header=T, dec = ".")
F_P2_G3_R86 <- read.table("freq_Str_pop2_gen3_0.1100.0530_86", header=T, dec = ".")
F_P2_G3_R87 <- read.table("freq_Str_pop2_gen3_0.1100.0530_87", header=T, dec = ".")
F_P2_G3_R88 <- read.table("freq_Str_pop2_gen3_0.1100.0530_88", header=T, dec = ".")
F_P2_G3_R89 <- read.table("freq_Str_pop2_gen3_0.1100.0530_89", header=T, dec = ".")
F_P2_G3_R90 <- read.table("freq_Str_pop2_gen3_0.1100.0530_90", header=T, dec = ".")
F_P2_G3_R91 <- read.table("freq_Str_pop2_gen3_0.1100.0530_91", header=T, dec = ".")
F_P2_G3_R92 <- read.table("freq_Str_pop2_gen3_0.1100.0530_92", header=T, dec = ".")
F_P2_G3_R93 <- read.table("freq_Str_pop2_gen3_0.1100.0530_93", header=T, dec = ".")
F_P2_G3_R94 <- read.table("freq_Str_pop2_gen3_0.1100.0530_94", header=T, dec = ".")
F_P2_G3_R95 <- read.table("freq_Str_pop2_gen3_0.1100.0530_95", header=T, dec = ".")
F_P2_G3_R96 <- read.table("freq_Str_pop2_gen3_0.1100.0530_96", header=T, dec = ".")
F_P2_G3_R97 <- read.table("freq_Str_pop2_gen3_0.1100.0530_97", header=T, dec = ".")
F_P2_G3_R98 <- read.table("freq_Str_pop2_gen3_0.1100.0530_98", header=T, dec = ".")
F_P2_G3_R99 <- read.table("freq_Str_pop2_gen3_0.1100.0530_99", header=T, dec = ".")
F_P2_G3_R100 <- read.table("freq_Str_pop2_gen3_0.1100.0530_100", header=T, dec = ".")

# frequencies Structure generation 6 pop 2 ----
F_P2_G6_R1 <- read.table("freq_Str_pop2_gen6_0.1100.0530_1", header=T, dec = ".")
F_P2_G6_R2 <- read.table("freq_Str_pop2_gen6_0.1100.0530_2", header=T, dec = ".")
F_P2_G6_R3 <- read.table("freq_Str_pop2_gen6_0.1100.0530_3", header=T, dec = ".")
F_P2_G6_R4 <- read.table("freq_Str_pop2_gen6_0.1100.0530_4", header=T, dec = ".")
F_P2_G6_R5 <- read.table("freq_Str_pop2_gen6_0.1100.0530_5", header=T, dec = ".")
F_P2_G6_R6 <- read.table("freq_Str_pop2_gen6_0.1100.0530_6", header=T, dec = ".")
F_P2_G6_R7 <- read.table("freq_Str_pop2_gen6_0.1100.0530_7", header=T, dec = ".")
F_P2_G6_R8 <- read.table("freq_Str_pop2_gen6_0.1100.0530_8", header=T, dec = ".")
F_P2_G6_R9 <- read.table("freq_Str_pop2_gen6_0.1100.0530_9", header=T, dec = ".")
F_P2_G6_R10 <- read.table("freq_Str_pop2_gen6_0.1100.0530_10", header=T, dec = ".")
F_P2_G6_R11 <- read.table("freq_Str_pop2_gen6_0.1100.0530_11", header=T, dec = ".")
F_P2_G6_R12 <- read.table("freq_Str_pop2_gen6_0.1100.0530_12", header=T, dec = ".")
F_P2_G6_R13 <- read.table("freq_Str_pop2_gen6_0.1100.0530_13", header=T, dec = ".")
F_P2_G6_R14 <- read.table("freq_Str_pop2_gen6_0.1100.0530_14", header=T, dec = ".")
F_P2_G6_R15 <- read.table("freq_Str_pop2_gen6_0.1100.0530_15", header=T, dec = ".")
F_P2_G6_R16 <- read.table("freq_Str_pop2_gen6_0.1100.0530_16", header=T, dec = ".")
F_P2_G6_R17 <- read.table("freq_Str_pop2_gen6_0.1100.0530_17", header=T, dec = ".")
F_P2_G6_R18 <- read.table("freq_Str_pop2_gen6_0.1100.0530_18", header=T, dec = ".")
F_P2_G6_R19 <- read.table("freq_Str_pop2_gen6_0.1100.0530_19", header=T, dec = ".")
F_P2_G6_R20 <- read.table("freq_Str_pop2_gen6_0.1100.0530_20", header=T, dec = ".")
F_P2_G6_R21 <- read.table("freq_Str_pop2_gen6_0.1100.0530_21", header=T, dec = ".")
F_P2_G6_R22 <- read.table("freq_Str_pop2_gen6_0.1100.0530_22", header=T, dec = ".")
F_P2_G6_R23 <- read.table("freq_Str_pop2_gen6_0.1100.0530_23", header=T, dec = ".")
F_P2_G6_R24 <- read.table("freq_Str_pop2_gen6_0.1100.0530_24", header=T, dec = ".")
F_P2_G6_R25 <- read.table("freq_Str_pop2_gen6_0.1100.0530_25", header=T, dec = ".")
F_P2_G6_R26 <- read.table("freq_Str_pop2_gen6_0.1100.0530_26", header=T, dec = ".")
F_P2_G6_R27 <- read.table("freq_Str_pop2_gen6_0.1100.0530_27", header=T, dec = ".")
F_P2_G6_R28 <- read.table("freq_Str_pop2_gen6_0.1100.0530_28", header=T, dec = ".")
F_P2_G6_R29 <- read.table("freq_Str_pop2_gen6_0.1100.0530_29", header=T, dec = ".")
F_P2_G6_R30 <- read.table("freq_Str_pop2_gen6_0.1100.0530_30", header=T, dec = ".")
F_P2_G6_R31 <- read.table("freq_Str_pop2_gen6_0.1100.0530_31", header=T, dec = ".")
F_P2_G6_R32 <- read.table("freq_Str_pop2_gen6_0.1100.0530_32", header=T, dec = ".")
F_P2_G6_R33 <- read.table("freq_Str_pop2_gen6_0.1100.0530_33", header=T, dec = ".")
F_P2_G6_R34 <- read.table("freq_Str_pop2_gen6_0.1100.0530_34", header=T, dec = ".")
F_P2_G6_R35 <- read.table("freq_Str_pop2_gen6_0.1100.0530_35", header=T, dec = ".")
F_P2_G6_R36 <- read.table("freq_Str_pop2_gen6_0.1100.0530_36", header=T, dec = ".")
F_P2_G6_R37 <- read.table("freq_Str_pop2_gen6_0.1100.0530_37", header=T, dec = ".")
F_P2_G6_R38 <- read.table("freq_Str_pop2_gen6_0.1100.0530_38", header=T, dec = ".")
F_P2_G6_R39 <- read.table("freq_Str_pop2_gen6_0.1100.0530_39", header=T, dec = ".")
F_P2_G6_R40 <- read.table("freq_Str_pop2_gen6_0.1100.0530_40", header=T, dec = ".")
F_P2_G6_R41 <- read.table("freq_Str_pop2_gen6_0.1100.0530_41", header=T, dec = ".")
F_P2_G6_R42 <- read.table("freq_Str_pop2_gen6_0.1100.0530_42", header=T, dec = ".")
F_P2_G6_R43 <- read.table("freq_Str_pop2_gen6_0.1100.0530_43", header=T, dec = ".")
F_P2_G6_R44 <- read.table("freq_Str_pop2_gen6_0.1100.0530_44", header=T, dec = ".")
F_P2_G6_R45 <- read.table("freq_Str_pop2_gen6_0.1100.0530_45", header=T, dec = ".")
F_P2_G6_R46 <- read.table("freq_Str_pop2_gen6_0.1100.0530_46", header=T, dec = ".")
F_P2_G6_R47 <- read.table("freq_Str_pop2_gen6_0.1100.0530_47", header=T, dec = ".")
F_P2_G6_R48 <- read.table("freq_Str_pop2_gen6_0.1100.0530_48", header=T, dec = ".")
F_P2_G6_R49 <- read.table("freq_Str_pop2_gen6_0.1100.0530_49", header=T, dec = ".")
F_P2_G6_R50 <- read.table("freq_Str_pop2_gen6_0.1100.0530_50", header=T, dec = ".")
F_P2_G6_R51 <- read.table("freq_Str_pop2_gen6_0.1100.0530_51", header=T, dec = ".")
F_P2_G6_R52 <- read.table("freq_Str_pop2_gen6_0.1100.0530_52", header=T, dec = ".")
F_P2_G6_R53 <- read.table("freq_Str_pop2_gen6_0.1100.0530_53", header=T, dec = ".")
F_P2_G6_R54 <- read.table("freq_Str_pop2_gen6_0.1100.0530_54", header=T, dec = ".")
F_P2_G6_R55 <- read.table("freq_Str_pop2_gen6_0.1100.0530_55", header=T, dec = ".")
F_P2_G6_R56 <- read.table("freq_Str_pop2_gen6_0.1100.0530_56", header=T, dec = ".")
F_P2_G6_R57 <- read.table("freq_Str_pop2_gen6_0.1100.0530_57", header=T, dec = ".")
F_P2_G6_R58 <- read.table("freq_Str_pop2_gen6_0.1100.0530_58", header=T, dec = ".")
F_P2_G6_R59 <- read.table("freq_Str_pop2_gen6_0.1100.0530_59", header=T, dec = ".")
F_P2_G6_R60 <- read.table("freq_Str_pop2_gen6_0.1100.0530_60", header=T, dec = ".")
F_P2_G6_R61 <- read.table("freq_Str_pop2_gen6_0.1100.0530_61", header=T, dec = ".")
F_P2_G6_R62 <- read.table("freq_Str_pop2_gen6_0.1100.0530_62", header=T, dec = ".")
F_P2_G6_R63 <- read.table("freq_Str_pop2_gen6_0.1100.0530_63", header=T, dec = ".")
F_P2_G6_R64 <- read.table("freq_Str_pop2_gen6_0.1100.0530_64", header=T, dec = ".")
F_P2_G6_R65 <- read.table("freq_Str_pop2_gen6_0.1100.0530_65", header=T, dec = ".")
F_P2_G6_R66 <- read.table("freq_Str_pop2_gen6_0.1100.0530_66", header=T, dec = ".")
F_P2_G6_R67 <- read.table("freq_Str_pop2_gen6_0.1100.0530_67", header=T, dec = ".")
F_P2_G6_R68 <- read.table("freq_Str_pop2_gen6_0.1100.0530_68", header=T, dec = ".")
F_P2_G6_R69 <- read.table("freq_Str_pop2_gen6_0.1100.0530_69", header=T, dec = ".")
F_P2_G6_R70 <- read.table("freq_Str_pop2_gen6_0.1100.0530_70", header=T, dec = ".")
F_P2_G6_R71 <- read.table("freq_Str_pop2_gen6_0.1100.0530_71", header=T, dec = ".")
F_P2_G6_R72 <- read.table("freq_Str_pop2_gen6_0.1100.0530_72", header=T, dec = ".")
F_P2_G6_R73 <- read.table("freq_Str_pop2_gen6_0.1100.0530_73", header=T, dec = ".")
F_P2_G6_R74 <- read.table("freq_Str_pop2_gen6_0.1100.0530_74", header=T, dec = ".")
F_P2_G6_R75 <- read.table("freq_Str_pop2_gen6_0.1100.0530_75", header=T, dec = ".")
F_P2_G6_R76 <- read.table("freq_Str_pop2_gen6_0.1100.0530_76", header=T, dec = ".")
F_P2_G6_R77 <- read.table("freq_Str_pop2_gen6_0.1100.0530_77", header=T, dec = ".")
F_P2_G6_R78 <- read.table("freq_Str_pop2_gen6_0.1100.0530_78", header=T, dec = ".")
F_P2_G6_R79 <- read.table("freq_Str_pop2_gen6_0.1100.0530_79", header=T, dec = ".")
F_P2_G6_R80 <- read.table("freq_Str_pop2_gen6_0.1100.0530_80", header=T, dec = ".")
F_P2_G6_R81 <- read.table("freq_Str_pop2_gen6_0.1100.0530_81", header=T, dec = ".")
F_P2_G6_R82 <- read.table("freq_Str_pop2_gen6_0.1100.0530_82", header=T, dec = ".")
F_P2_G6_R83 <- read.table("freq_Str_pop2_gen6_0.1100.0530_83", header=T, dec = ".")
F_P2_G6_R84 <- read.table("freq_Str_pop2_gen6_0.1100.0530_84", header=T, dec = ".")
F_P2_G6_R85 <- read.table("freq_Str_pop2_gen6_0.1100.0530_85", header=T, dec = ".")
F_P2_G6_R86 <- read.table("freq_Str_pop2_gen6_0.1100.0530_86", header=T, dec = ".")
F_P2_G6_R87 <- read.table("freq_Str_pop2_gen6_0.1100.0530_87", header=T, dec = ".")
F_P2_G6_R88 <- read.table("freq_Str_pop2_gen6_0.1100.0530_88", header=T, dec = ".")
F_P2_G6_R89 <- read.table("freq_Str_pop2_gen6_0.1100.0530_89", header=T, dec = ".")
F_P2_G6_R90 <- read.table("freq_Str_pop2_gen6_0.1100.0530_90", header=T, dec = ".")
F_P2_G6_R91 <- read.table("freq_Str_pop2_gen6_0.1100.0530_91", header=T, dec = ".")
F_P2_G6_R92 <- read.table("freq_Str_pop2_gen6_0.1100.0530_92", header=T, dec = ".")
F_P2_G6_R93 <- read.table("freq_Str_pop2_gen6_0.1100.0530_93", header=T, dec = ".")
F_P2_G6_R94 <- read.table("freq_Str_pop2_gen6_0.1100.0530_94", header=T, dec = ".")
F_P2_G6_R95 <- read.table("freq_Str_pop2_gen6_0.1100.0530_95", header=T, dec = ".")
F_P2_G6_R96 <- read.table("freq_Str_pop2_gen6_0.1100.0530_96", header=T, dec = ".")
F_P2_G6_R97 <- read.table("freq_Str_pop2_gen6_0.1100.0530_97", header=T, dec = ".")
F_P2_G6_R98 <- read.table("freq_Str_pop2_gen6_0.1100.0530_98", header=T, dec = ".")
F_P2_G6_R99 <- read.table("freq_Str_pop2_gen6_0.1100.0530_99", header=T, dec = ".")
F_P2_G6_R100 <- read.table("freq_Str_pop2_gen6_0.1100.0530_100", header=T, dec = ".")

# frequencies Structure generation 10 pop 2 ----
F_P2_G10_R1 <- read.table("freq_Str_pop2_gen10_0.1100.0530_1", header=T, dec = ".")
F_P2_G10_R2 <- read.table("freq_Str_pop2_gen10_0.1100.0530_2", header=T, dec = ".")
F_P2_G10_R3 <- read.table("freq_Str_pop2_gen10_0.1100.0530_3", header=T, dec = ".")
F_P2_G10_R4 <- read.table("freq_Str_pop2_gen10_0.1100.0530_4", header=T, dec = ".")
F_P2_G10_R5 <- read.table("freq_Str_pop2_gen10_0.1100.0530_5", header=T, dec = ".")
F_P2_G10_R6 <- read.table("freq_Str_pop2_gen10_0.1100.0530_6", header=T, dec = ".")
F_P2_G10_R7 <- read.table("freq_Str_pop2_gen10_0.1100.0530_7", header=T, dec = ".")
F_P2_G10_R8 <- read.table("freq_Str_pop2_gen10_0.1100.0530_8", header=T, dec = ".")
F_P2_G10_R9 <- read.table("freq_Str_pop2_gen10_0.1100.0530_9", header=T, dec = ".")
F_P2_G10_R10 <- read.table("freq_Str_pop2_gen10_0.1100.0530_10", header=T, dec = ".")
F_P2_G10_R11 <- read.table("freq_Str_pop2_gen10_0.1100.0530_11", header=T, dec = ".")
F_P2_G10_R12 <- read.table("freq_Str_pop2_gen10_0.1100.0530_12", header=T, dec = ".")
F_P2_G10_R13 <- read.table("freq_Str_pop2_gen10_0.1100.0530_13", header=T, dec = ".")
F_P2_G10_R14 <- read.table("freq_Str_pop2_gen10_0.1100.0530_14", header=T, dec = ".")
F_P2_G10_R15 <- read.table("freq_Str_pop2_gen10_0.1100.0530_15", header=T, dec = ".")
F_P2_G10_R16 <- read.table("freq_Str_pop2_gen10_0.1100.0530_16", header=T, dec = ".")
F_P2_G10_R17 <- read.table("freq_Str_pop2_gen10_0.1100.0530_17", header=T, dec = ".")
F_P2_G10_R18 <- read.table("freq_Str_pop2_gen10_0.1100.0530_18", header=T, dec = ".")
F_P2_G10_R19 <- read.table("freq_Str_pop2_gen10_0.1100.0530_19", header=T, dec = ".")
F_P2_G10_R20 <- read.table("freq_Str_pop2_gen10_0.1100.0530_20", header=T, dec = ".")
F_P2_G10_R21 <- read.table("freq_Str_pop2_gen10_0.1100.0530_21", header=T, dec = ".")
F_P2_G10_R22 <- read.table("freq_Str_pop2_gen10_0.1100.0530_22", header=T, dec = ".")
F_P2_G10_R23 <- read.table("freq_Str_pop2_gen10_0.1100.0530_23", header=T, dec = ".")
F_P2_G10_R24 <- read.table("freq_Str_pop2_gen10_0.1100.0530_24", header=T, dec = ".")
F_P2_G10_R25 <- read.table("freq_Str_pop2_gen10_0.1100.0530_25", header=T, dec = ".")
F_P2_G10_R26 <- read.table("freq_Str_pop2_gen10_0.1100.0530_26", header=T, dec = ".")
F_P2_G10_R27 <- read.table("freq_Str_pop2_gen10_0.1100.0530_27", header=T, dec = ".")
F_P2_G10_R28 <- read.table("freq_Str_pop2_gen10_0.1100.0530_28", header=T, dec = ".")
F_P2_G10_R29 <- read.table("freq_Str_pop2_gen10_0.1100.0530_29", header=T, dec = ".")
F_P2_G10_R30 <- read.table("freq_Str_pop2_gen10_0.1100.0530_30", header=T, dec = ".")
F_P2_G10_R31 <- read.table("freq_Str_pop2_gen10_0.1100.0530_31", header=T, dec = ".")
F_P2_G10_R32 <- read.table("freq_Str_pop2_gen10_0.1100.0530_32", header=T, dec = ".")
F_P2_G10_R33 <- read.table("freq_Str_pop2_gen10_0.1100.0530_33", header=T, dec = ".")
F_P2_G10_R34 <- read.table("freq_Str_pop2_gen10_0.1100.0530_34", header=T, dec = ".")
F_P2_G10_R35 <- read.table("freq_Str_pop2_gen10_0.1100.0530_35", header=T, dec = ".")
F_P2_G10_R36 <- read.table("freq_Str_pop2_gen10_0.1100.0530_36", header=T, dec = ".")
F_P2_G10_R37 <- read.table("freq_Str_pop2_gen10_0.1100.0530_37", header=T, dec = ".")
F_P2_G10_R38 <- read.table("freq_Str_pop2_gen10_0.1100.0530_38", header=T, dec = ".")
F_P2_G10_R39 <- read.table("freq_Str_pop2_gen10_0.1100.0530_39", header=T, dec = ".")
F_P2_G10_R40 <- read.table("freq_Str_pop2_gen10_0.1100.0530_40", header=T, dec = ".")
F_P2_G10_R41 <- read.table("freq_Str_pop2_gen10_0.1100.0530_41", header=T, dec = ".")
F_P2_G10_R42 <- read.table("freq_Str_pop2_gen10_0.1100.0530_42", header=T, dec = ".")
F_P2_G10_R43 <- read.table("freq_Str_pop2_gen10_0.1100.0530_43", header=T, dec = ".")
F_P2_G10_R44 <- read.table("freq_Str_pop2_gen10_0.1100.0530_44", header=T, dec = ".")
F_P2_G10_R45 <- read.table("freq_Str_pop2_gen10_0.1100.0530_45", header=T, dec = ".")
F_P2_G10_R46 <- read.table("freq_Str_pop2_gen10_0.1100.0530_46", header=T, dec = ".")
F_P2_G10_R47 <- read.table("freq_Str_pop2_gen10_0.1100.0530_47", header=T, dec = ".")
F_P2_G10_R48 <- read.table("freq_Str_pop2_gen10_0.1100.0530_48", header=T, dec = ".")
F_P2_G10_R49 <- read.table("freq_Str_pop2_gen10_0.1100.0530_49", header=T, dec = ".")
F_P2_G10_R50 <- read.table("freq_Str_pop2_gen10_0.1100.0530_50", header=T, dec = ".")
F_P2_G10_R51 <- read.table("freq_Str_pop2_gen10_0.1100.0530_51", header=T, dec = ".")
F_P2_G10_R52 <- read.table("freq_Str_pop2_gen10_0.1100.0530_52", header=T, dec = ".")
F_P2_G10_R53 <- read.table("freq_Str_pop2_gen10_0.1100.0530_53", header=T, dec = ".")
F_P2_G10_R54 <- read.table("freq_Str_pop2_gen10_0.1100.0530_54", header=T, dec = ".")
F_P2_G10_R55 <- read.table("freq_Str_pop2_gen10_0.1100.0530_55", header=T, dec = ".")
F_P2_G10_R56 <- read.table("freq_Str_pop2_gen10_0.1100.0530_56", header=T, dec = ".")
F_P2_G10_R57 <- read.table("freq_Str_pop2_gen10_0.1100.0530_57", header=T, dec = ".")
F_P2_G10_R58 <- read.table("freq_Str_pop2_gen10_0.1100.0530_58", header=T, dec = ".")
F_P2_G10_R59 <- read.table("freq_Str_pop2_gen10_0.1100.0530_59", header=T, dec = ".")
F_P2_G10_R60 <- read.table("freq_Str_pop2_gen10_0.1100.0530_60", header=T, dec = ".")
F_P2_G10_R61 <- read.table("freq_Str_pop2_gen10_0.1100.0530_61", header=T, dec = ".")
F_P2_G10_R62 <- read.table("freq_Str_pop2_gen10_0.1100.0530_62", header=T, dec = ".")
F_P2_G10_R63 <- read.table("freq_Str_pop2_gen10_0.1100.0530_63", header=T, dec = ".")
F_P2_G10_R64 <- read.table("freq_Str_pop2_gen10_0.1100.0530_64", header=T, dec = ".")
F_P2_G10_R65 <- read.table("freq_Str_pop2_gen10_0.1100.0530_65", header=T, dec = ".")
F_P2_G10_R66 <- read.table("freq_Str_pop2_gen10_0.1100.0530_66", header=T, dec = ".")
F_P2_G10_R67 <- read.table("freq_Str_pop2_gen10_0.1100.0530_67", header=T, dec = ".")
F_P2_G10_R68 <- read.table("freq_Str_pop2_gen10_0.1100.0530_68", header=T, dec = ".")
F_P2_G10_R69 <- read.table("freq_Str_pop2_gen10_0.1100.0530_69", header=T, dec = ".")
F_P2_G10_R70 <- read.table("freq_Str_pop2_gen10_0.1100.0530_70", header=T, dec = ".")
F_P2_G10_R71 <- read.table("freq_Str_pop2_gen10_0.1100.0530_71", header=T, dec = ".")
F_P2_G10_R72 <- read.table("freq_Str_pop2_gen10_0.1100.0530_72", header=T, dec = ".")
F_P2_G10_R73 <- read.table("freq_Str_pop2_gen10_0.1100.0530_73", header=T, dec = ".")
F_P2_G10_R74 <- read.table("freq_Str_pop2_gen10_0.1100.0530_74", header=T, dec = ".")
F_P2_G10_R75 <- read.table("freq_Str_pop2_gen10_0.1100.0530_75", header=T, dec = ".")
F_P2_G10_R76 <- read.table("freq_Str_pop2_gen10_0.1100.0530_76", header=T, dec = ".")
F_P2_G10_R77 <- read.table("freq_Str_pop2_gen10_0.1100.0530_77", header=T, dec = ".")
F_P2_G10_R78 <- read.table("freq_Str_pop2_gen10_0.1100.0530_78", header=T, dec = ".")
F_P2_G10_R79 <- read.table("freq_Str_pop2_gen10_0.1100.0530_79", header=T, dec = ".")
F_P2_G10_R80 <- read.table("freq_Str_pop2_gen10_0.1100.0530_80", header=T, dec = ".")
F_P2_G10_R81 <- read.table("freq_Str_pop2_gen10_0.1100.0530_81", header=T, dec = ".")
F_P2_G10_R82 <- read.table("freq_Str_pop2_gen10_0.1100.0530_82", header=T, dec = ".")
F_P2_G10_R83 <- read.table("freq_Str_pop2_gen10_0.1100.0530_83", header=T, dec = ".")
F_P2_G10_R84 <- read.table("freq_Str_pop2_gen10_0.1100.0530_84", header=T, dec = ".")
F_P2_G10_R85 <- read.table("freq_Str_pop2_gen10_0.1100.0530_85", header=T, dec = ".")
F_P2_G10_R86 <- read.table("freq_Str_pop2_gen10_0.1100.0530_86", header=T, dec = ".")
F_P2_G10_R87 <- read.table("freq_Str_pop2_gen10_0.1100.0530_87", header=T, dec = ".")
F_P2_G10_R88 <- read.table("freq_Str_pop2_gen10_0.1100.0530_88", header=T, dec = ".")
F_P2_G10_R89 <- read.table("freq_Str_pop2_gen10_0.1100.0530_89", header=T, dec = ".")
F_P2_G10_R90 <- read.table("freq_Str_pop2_gen10_0.1100.0530_90", header=T, dec = ".")
F_P2_G10_R91 <- read.table("freq_Str_pop2_gen10_0.1100.0530_91", header=T, dec = ".")
F_P2_G10_R92 <- read.table("freq_Str_pop2_gen10_0.1100.0530_92", header=T, dec = ".")
F_P2_G10_R93 <- read.table("freq_Str_pop2_gen10_0.1100.0530_93", header=T, dec = ".")
F_P2_G10_R94 <- read.table("freq_Str_pop2_gen10_0.1100.0530_94", header=T, dec = ".")
F_P2_G10_R95 <- read.table("freq_Str_pop2_gen10_0.1100.0530_95", header=T, dec = ".")
F_P2_G10_R96 <- read.table("freq_Str_pop2_gen10_0.1100.0530_96", header=T, dec = ".")
F_P2_G10_R97 <- read.table("freq_Str_pop2_gen10_0.1100.0530_97", header=T, dec = ".")
F_P2_G10_R98 <- read.table("freq_Str_pop2_gen10_0.1100.0530_98", header=T, dec = ".")
F_P2_G10_R99 <- read.table("freq_Str_pop2_gen10_0.1100.0530_99", header=T, dec = ".")
F_P2_G10_R100 <- read.table("freq_Str_pop2_gen10_0.1100.0530_100", header=T, dec = ".")


# sum of squared differences between generation 0 and 0 pop1 ----
sum((F_P1_G0_R1 - FS_P1_G0_R1)^2) -> dif_p1_gen0_0_R1
sum((F_P1_G0_R2 - FS_P1_G0_R2)^2) -> dif_p1_gen0_0_R2
sum((F_P1_G0_R3 - FS_P1_G0_R3)^2) -> dif_p1_gen0_0_R3
sum((F_P1_G0_R4 - FS_P1_G0_R4)^2) -> dif_p1_gen0_0_R4
sum((F_P1_G0_R5 - FS_P1_G0_R5)^2) -> dif_p1_gen0_0_R5
sum((F_P1_G0_R6 - FS_P1_G0_R6)^2) -> dif_p1_gen0_0_R6
sum((F_P1_G0_R7 - FS_P1_G0_R7)^2) -> dif_p1_gen0_0_R7
sum((F_P1_G0_R8 - FS_P1_G0_R8)^2) -> dif_p1_gen0_0_R8
sum((F_P1_G0_R9 - FS_P1_G0_R9)^2) -> dif_p1_gen0_0_R9
sum((F_P1_G0_R10 - FS_P1_G0_R10)^2) -> dif_p1_gen0_0_R10
sum((F_P1_G0_R11 - FS_P1_G0_R11)^2) -> dif_p1_gen0_0_R11
sum((F_P1_G0_R12 - FS_P1_G0_R12)^2) -> dif_p1_gen0_0_R12
sum((F_P1_G0_R13 - FS_P1_G0_R13)^2) -> dif_p1_gen0_0_R13
sum((F_P1_G0_R14 - FS_P1_G0_R14)^2) -> dif_p1_gen0_0_R14
sum((F_P1_G0_R15 - FS_P1_G0_R15)^2) -> dif_p1_gen0_0_R15
sum((F_P1_G0_R16 - FS_P1_G0_R16)^2) -> dif_p1_gen0_0_R16
sum((F_P1_G0_R17 - FS_P1_G0_R17)^2) -> dif_p1_gen0_0_R17
sum((F_P1_G0_R18 - FS_P1_G0_R18)^2) -> dif_p1_gen0_0_R18
sum((F_P1_G0_R19 - FS_P1_G0_R19)^2) -> dif_p1_gen0_0_R19
sum((F_P1_G0_R20 - FS_P1_G0_R20)^2) -> dif_p1_gen0_0_R20
sum((F_P1_G0_R21 - FS_P1_G0_R21)^2) -> dif_p1_gen0_0_R21
sum((F_P1_G0_R22 - FS_P1_G0_R22)^2) -> dif_p1_gen0_0_R22
sum((F_P1_G0_R23 - FS_P1_G0_R23)^2) -> dif_p1_gen0_0_R23
sum((F_P1_G0_R24 - FS_P1_G0_R24)^2) -> dif_p1_gen0_0_R24
sum((F_P1_G0_R25 - FS_P1_G0_R25)^2) -> dif_p1_gen0_0_R25
sum((F_P1_G0_R26 - FS_P1_G0_R26)^2) -> dif_p1_gen0_0_R26
sum((F_P1_G0_R27 - FS_P1_G0_R27)^2) -> dif_p1_gen0_0_R27
sum((F_P1_G0_R28 - FS_P1_G0_R28)^2) -> dif_p1_gen0_0_R28
sum((F_P1_G0_R29 - FS_P1_G0_R29)^2) -> dif_p1_gen0_0_R29
sum((F_P1_G0_R30 - FS_P1_G0_R30)^2) -> dif_p1_gen0_0_R30
sum((F_P1_G0_R31 - FS_P1_G0_R31)^2) -> dif_p1_gen0_0_R31
sum((F_P1_G0_R32 - FS_P1_G0_R32)^2) -> dif_p1_gen0_0_R32
sum((F_P1_G0_R33 - FS_P1_G0_R33)^2) -> dif_p1_gen0_0_R33
sum((F_P1_G0_R34 - FS_P1_G0_R34)^2) -> dif_p1_gen0_0_R34
sum((F_P1_G0_R35 - FS_P1_G0_R35)^2) -> dif_p1_gen0_0_R35
sum((F_P1_G0_R36 - FS_P1_G0_R36)^2) -> dif_p1_gen0_0_R36
sum((F_P1_G0_R37 - FS_P1_G0_R37)^2) -> dif_p1_gen0_0_R37
sum((F_P1_G0_R38 - FS_P1_G0_R38)^2) -> dif_p1_gen0_0_R38
sum((F_P1_G0_R39 - FS_P1_G0_R39)^2) -> dif_p1_gen0_0_R39
sum((F_P1_G0_R40 - FS_P1_G0_R40)^2) -> dif_p1_gen0_0_R40
sum((F_P1_G0_R41 - FS_P1_G0_R41)^2) -> dif_p1_gen0_0_R41
sum((F_P1_G0_R42 - FS_P1_G0_R42)^2) -> dif_p1_gen0_0_R42
sum((F_P1_G0_R43 - FS_P1_G0_R43)^2) -> dif_p1_gen0_0_R43
sum((F_P1_G0_R44 - FS_P1_G0_R44)^2) -> dif_p1_gen0_0_R44
sum((F_P1_G0_R45 - FS_P1_G0_R45)^2) -> dif_p1_gen0_0_R45
sum((F_P1_G0_R46 - FS_P1_G0_R46)^2) -> dif_p1_gen0_0_R46
sum((F_P1_G0_R47 - FS_P1_G0_R47)^2) -> dif_p1_gen0_0_R47
sum((F_P1_G0_R48 - FS_P1_G0_R48)^2) -> dif_p1_gen0_0_R48
sum((F_P1_G0_R49 - FS_P1_G0_R49)^2) -> dif_p1_gen0_0_R49
sum((F_P1_G0_R50 - FS_P1_G0_R50)^2) -> dif_p1_gen0_0_R50
sum((F_P1_G0_R51 - FS_P1_G0_R51)^2) -> dif_p1_gen0_0_R51
sum((F_P1_G0_R52 - FS_P1_G0_R52)^2) -> dif_p1_gen0_0_R52
sum((F_P1_G0_R53 - FS_P1_G0_R53)^2) -> dif_p1_gen0_0_R53
sum((F_P1_G0_R54 - FS_P1_G0_R54)^2) -> dif_p1_gen0_0_R54
sum((F_P1_G0_R55 - FS_P1_G0_R55)^2) -> dif_p1_gen0_0_R55
sum((F_P1_G0_R56 - FS_P1_G0_R56)^2) -> dif_p1_gen0_0_R56
sum((F_P1_G0_R57 - FS_P1_G0_R57)^2) -> dif_p1_gen0_0_R57
sum((F_P1_G0_R58 - FS_P1_G0_R58)^2) -> dif_p1_gen0_0_R58
sum((F_P1_G0_R59 - FS_P1_G0_R59)^2) -> dif_p1_gen0_0_R59
sum((F_P1_G0_R60 - FS_P1_G0_R60)^2) -> dif_p1_gen0_0_R60
sum((F_P1_G0_R61 - FS_P1_G0_R61)^2) -> dif_p1_gen0_0_R61
sum((F_P1_G0_R62 - FS_P1_G0_R62)^2) -> dif_p1_gen0_0_R62
sum((F_P1_G0_R63 - FS_P1_G0_R63)^2) -> dif_p1_gen0_0_R63
sum((F_P1_G0_R64 - FS_P1_G0_R64)^2) -> dif_p1_gen0_0_R64 
sum((F_P1_G0_R65 - FS_P1_G0_R65)^2) -> dif_p1_gen0_0_R65
sum((F_P1_G0_R66 - FS_P1_G0_R66)^2) -> dif_p1_gen0_0_R66
sum((F_P1_G0_R67 - FS_P1_G0_R67)^2) -> dif_p1_gen0_0_R67
sum((F_P1_G0_R68 - FS_P1_G0_R68)^2) -> dif_p1_gen0_0_R68
sum((F_P1_G0_R69 - FS_P1_G0_R69)^2) -> dif_p1_gen0_0_R69
sum((F_P1_G0_R70 - FS_P1_G0_R70)^2) -> dif_p1_gen0_0_R70
sum((F_P1_G0_R71 - FS_P1_G0_R71)^2) -> dif_p1_gen0_0_R71
sum((F_P1_G0_R72 - FS_P1_G0_R72)^2) -> dif_p1_gen0_0_R72
sum((F_P1_G0_R73 - FS_P1_G0_R73)^2) -> dif_p1_gen0_0_R73
sum((F_P1_G0_R74 - FS_P1_G0_R74)^2) -> dif_p1_gen0_0_R74
sum((F_P1_G0_R75 - FS_P1_G0_R75)^2) -> dif_p1_gen0_0_R75
sum((F_P1_G0_R76 - FS_P1_G0_R76)^2) -> dif_p1_gen0_0_R76
sum((F_P1_G0_R77 - FS_P1_G0_R77)^2) -> dif_p1_gen0_0_R77
sum((F_P1_G0_R78 - FS_P1_G0_R78)^2) -> dif_p1_gen0_0_R78
sum((F_P1_G0_R79 - FS_P1_G0_R79)^2) -> dif_p1_gen0_0_R79
sum((F_P1_G0_R80 - FS_P1_G0_R80)^2) -> dif_p1_gen0_0_R80
sum((F_P1_G0_R81 - FS_P1_G0_R81)^2) -> dif_p1_gen0_0_R81
sum((F_P1_G0_R82 - FS_P1_G0_R82)^2) -> dif_p1_gen0_0_R82
sum((F_P1_G0_R83 - FS_P1_G0_R83)^2) -> dif_p1_gen0_0_R83
sum((F_P1_G0_R84 - FS_P1_G0_R84)^2) -> dif_p1_gen0_0_R84
sum((F_P1_G0_R85 - FS_P1_G0_R85)^2) -> dif_p1_gen0_0_R85
sum((F_P1_G0_R86 - FS_P1_G0_R86)^2) -> dif_p1_gen0_0_R86
sum((F_P1_G0_R87 - FS_P1_G0_R87)^2) -> dif_p1_gen0_0_R87
sum((F_P1_G0_R88 - FS_P1_G0_R88)^2) -> dif_p1_gen0_0_R88
sum((F_P1_G0_R89 - FS_P1_G0_R89)^2) -> dif_p1_gen0_0_R89
sum((F_P1_G0_R90 - FS_P1_G0_R90)^2) -> dif_p1_gen0_0_R90
sum((F_P1_G0_R91 - FS_P1_G0_R91)^2) -> dif_p1_gen0_0_R91
sum((F_P1_G0_R92 - FS_P1_G0_R92)^2) -> dif_p1_gen0_0_R92
sum((F_P1_G0_R93 - FS_P1_G0_R93)^2) -> dif_p1_gen0_0_R93
sum((F_P1_G0_R94 - FS_P1_G0_R94)^2) -> dif_p1_gen0_0_R94
sum((F_P1_G0_R95 - FS_P1_G0_R95)^2) -> dif_p1_gen0_0_R95
sum((F_P1_G0_R96 - FS_P1_G0_R96)^2) -> dif_p1_gen0_0_R96
sum((F_P1_G0_R97 - FS_P1_G0_R97)^2) -> dif_p1_gen0_0_R97
sum((F_P1_G0_R98 - FS_P1_G0_R98)^2) -> dif_p1_gen0_0_R98
sum((F_P1_G0_R99 - FS_P1_G0_R99)^2) -> dif_p1_gen0_0_R99
sum((F_P1_G0_R100 - FS_P1_G0_R100)^2) -> dif_p1_gen0_0_R100

dif_p1_gen0_0_R1 <- cbind(rep =1, sum = dif_p1_gen0_0_R1)
dif_p1_gen0_0_R2 <- cbind(rep =2, sum = dif_p1_gen0_0_R2)
dif_p1_gen0_0_R3 <- cbind(rep =3, sum = dif_p1_gen0_0_R3)
dif_p1_gen0_0_R4 <- cbind(rep =4, sum = dif_p1_gen0_0_R4)
dif_p1_gen0_0_R5 <- cbind(rep =5, sum = dif_p1_gen0_0_R5)
dif_p1_gen0_0_R6 <- cbind(rep =6, sum = dif_p1_gen0_0_R6)
dif_p1_gen0_0_R7 <- cbind(rep =7, sum = dif_p1_gen0_0_R7)
dif_p1_gen0_0_R8 <- cbind(rep =8, sum = dif_p1_gen0_0_R8)
dif_p1_gen0_0_R9 <- cbind(rep =9, sum = dif_p1_gen0_0_R9)
dif_p1_gen0_0_R10 <- cbind(rep =10, sum = dif_p1_gen0_0_R10)
dif_p1_gen0_0_R11 <- cbind(rep =11, sum = dif_p1_gen0_0_R11)
dif_p1_gen0_0_R12 <- cbind(rep =12, sum = dif_p1_gen0_0_R12)
dif_p1_gen0_0_R13 <- cbind(rep =13, sum = dif_p1_gen0_0_R13)
dif_p1_gen0_0_R14 <- cbind(rep =14, sum = dif_p1_gen0_0_R14)
dif_p1_gen0_0_R15 <- cbind(rep =15, sum = dif_p1_gen0_0_R15)
dif_p1_gen0_0_R16 <- cbind(rep =16, sum = dif_p1_gen0_0_R16)
dif_p1_gen0_0_R17 <- cbind(rep =17, sum = dif_p1_gen0_0_R17)
dif_p1_gen0_0_R18 <- cbind(rep =18, sum = dif_p1_gen0_0_R18)
dif_p1_gen0_0_R19 <- cbind(rep =19, sum = dif_p1_gen0_0_R19)
dif_p1_gen0_0_R20 <- cbind(rep =20, sum = dif_p1_gen0_0_R20)
dif_p1_gen0_0_R21 <- cbind(rep =21, sum = dif_p1_gen0_0_R21)
dif_p1_gen0_0_R22 <- cbind(rep =22, sum = dif_p1_gen0_0_R22)
dif_p1_gen0_0_R23 <- cbind(rep =23, sum = dif_p1_gen0_0_R23)
dif_p1_gen0_0_R24 <- cbind(rep =24, sum = dif_p1_gen0_0_R24)
dif_p1_gen0_0_R25 <- cbind(rep =25, sum = dif_p1_gen0_0_R25)
dif_p1_gen0_0_R26 <- cbind(rep =26, sum = dif_p1_gen0_0_R26)
dif_p1_gen0_0_R27 <- cbind(rep =27, sum = dif_p1_gen0_0_R27)
dif_p1_gen0_0_R28 <- cbind(rep =28, sum = dif_p1_gen0_0_R28)
dif_p1_gen0_0_R29 <- cbind(rep =29, sum = dif_p1_gen0_0_R29)
dif_p1_gen0_0_R30 <- cbind(rep =30, sum = dif_p1_gen0_0_R30)
dif_p1_gen0_0_R31 <- cbind(rep =31, sum = dif_p1_gen0_0_R31)
dif_p1_gen0_0_R32 <- cbind(rep =32, sum = dif_p1_gen0_0_R32)
dif_p1_gen0_0_R33 <- cbind(rep =33, sum = dif_p1_gen0_0_R33)
dif_p1_gen0_0_R34 <- cbind(rep =34, sum = dif_p1_gen0_0_R34)
dif_p1_gen0_0_R35 <- cbind(rep =35, sum = dif_p1_gen0_0_R35)
dif_p1_gen0_0_R36 <- cbind(rep =36, sum = dif_p1_gen0_0_R36)
dif_p1_gen0_0_R37 <- cbind(rep =37, sum = dif_p1_gen0_0_R37)
dif_p1_gen0_0_R38 <- cbind(rep =38, sum = dif_p1_gen0_0_R38)
dif_p1_gen0_0_R39 <- cbind(rep =39, sum = dif_p1_gen0_0_R39)
dif_p1_gen0_0_R40 <- cbind(rep =40, sum = dif_p1_gen0_0_R40)
dif_p1_gen0_0_R41 <- cbind(rep =41, sum = dif_p1_gen0_0_R41)
dif_p1_gen0_0_R42 <- cbind(rep =42, sum = dif_p1_gen0_0_R42)
dif_p1_gen0_0_R43 <- cbind(rep =43, sum = dif_p1_gen0_0_R43)
dif_p1_gen0_0_R44 <- cbind(rep =44, sum = dif_p1_gen0_0_R44)
dif_p1_gen0_0_R45 <- cbind(rep =45, sum = dif_p1_gen0_0_R45)
dif_p1_gen0_0_R46 <- cbind(rep =46, sum = dif_p1_gen0_0_R46)
dif_p1_gen0_0_R47 <- cbind(rep =47, sum = dif_p1_gen0_0_R47)
dif_p1_gen0_0_R48 <- cbind(rep =48, sum = dif_p1_gen0_0_R48)
dif_p1_gen0_0_R49 <- cbind(rep =49, sum = dif_p1_gen0_0_R49)
dif_p1_gen0_0_R50 <- cbind(rep =50, sum = dif_p1_gen0_0_R50)
dif_p1_gen0_0_R51 <- cbind(rep =51, sum = dif_p1_gen0_0_R51)
dif_p1_gen0_0_R52 <- cbind(rep =52, sum = dif_p1_gen0_0_R52)
dif_p1_gen0_0_R53 <- cbind(rep =53, sum = dif_p1_gen0_0_R53)
dif_p1_gen0_0_R54 <- cbind(rep =54, sum = dif_p1_gen0_0_R54)
dif_p1_gen0_0_R55 <- cbind(rep =55, sum = dif_p1_gen0_0_R55)
dif_p1_gen0_0_R56 <- cbind(rep =56, sum = dif_p1_gen0_0_R56)
dif_p1_gen0_0_R57 <- cbind(rep =57, sum = dif_p1_gen0_0_R57)
dif_p1_gen0_0_R58 <- cbind(rep =58, sum = dif_p1_gen0_0_R58)
dif_p1_gen0_0_R59 <- cbind(rep =59, sum = dif_p1_gen0_0_R59)
dif_p1_gen0_0_R60 <- cbind(rep =60, sum = dif_p1_gen0_0_R60)
dif_p1_gen0_0_R61 <- cbind(rep =61, sum = dif_p1_gen0_0_R61)
dif_p1_gen0_0_R62 <- cbind(rep =62, sum = dif_p1_gen0_0_R62)
dif_p1_gen0_0_R63 <- cbind(rep =63, sum = dif_p1_gen0_0_R63)
dif_p1_gen0_0_R64 <- cbind(rep =64, sum = dif_p1_gen0_0_R64)
dif_p1_gen0_0_R65 <- cbind(rep =65, sum = dif_p1_gen0_0_R65)
dif_p1_gen0_0_R66 <- cbind(rep =66, sum = dif_p1_gen0_0_R66)
dif_p1_gen0_0_R67 <- cbind(rep =67, sum = dif_p1_gen0_0_R67)
dif_p1_gen0_0_R68 <- cbind(rep =68, sum = dif_p1_gen0_0_R68)
dif_p1_gen0_0_R69 <- cbind(rep =69, sum = dif_p1_gen0_0_R69)
dif_p1_gen0_0_R70 <- cbind(rep =70, sum = dif_p1_gen0_0_R70)
dif_p1_gen0_0_R71 <- cbind(rep =71, sum = dif_p1_gen0_0_R71)
dif_p1_gen0_0_R72 <- cbind(rep =72, sum = dif_p1_gen0_0_R72)
dif_p1_gen0_0_R73 <- cbind(rep =73, sum = dif_p1_gen0_0_R73)
dif_p1_gen0_0_R74 <- cbind(rep =74, sum = dif_p1_gen0_0_R74)
dif_p1_gen0_0_R75 <- cbind(rep =75, sum = dif_p1_gen0_0_R75)
dif_p1_gen0_0_R76 <- cbind(rep =76, sum = dif_p1_gen0_0_R76)
dif_p1_gen0_0_R77 <- cbind(rep =77, sum = dif_p1_gen0_0_R77)
dif_p1_gen0_0_R78 <- cbind(rep =78, sum = dif_p1_gen0_0_R78)
dif_p1_gen0_0_R79 <- cbind(rep =79, sum = dif_p1_gen0_0_R79)
dif_p1_gen0_0_R80 <- cbind(rep =80, sum = dif_p1_gen0_0_R80)
dif_p1_gen0_0_R81 <- cbind(rep =81, sum = dif_p1_gen0_0_R81)
dif_p1_gen0_0_R82 <- cbind(rep =82, sum = dif_p1_gen0_0_R82)
dif_p1_gen0_0_R83 <- cbind(rep =83, sum = dif_p1_gen0_0_R83)
dif_p1_gen0_0_R84 <- cbind(rep =84, sum = dif_p1_gen0_0_R84)
dif_p1_gen0_0_R85 <- cbind(rep =85, sum = dif_p1_gen0_0_R85)
dif_p1_gen0_0_R86 <- cbind(rep =86, sum = dif_p1_gen0_0_R86)
dif_p1_gen0_0_R87 <- cbind(rep =87, sum = dif_p1_gen0_0_R87)
dif_p1_gen0_0_R88 <- cbind(rep =88, sum = dif_p1_gen0_0_R88)
dif_p1_gen0_0_R89 <- cbind(rep =89, sum = dif_p1_gen0_0_R89)
dif_p1_gen0_0_R90 <- cbind(rep =90, sum = dif_p1_gen0_0_R90)
dif_p1_gen0_0_R91 <- cbind(rep =91, sum = dif_p1_gen0_0_R91)
dif_p1_gen0_0_R92 <- cbind(rep =92, sum = dif_p1_gen0_0_R92)
dif_p1_gen0_0_R93 <- cbind(rep =93, sum = dif_p1_gen0_0_R93)
dif_p1_gen0_0_R94 <- cbind(rep =94, sum = dif_p1_gen0_0_R94)
dif_p1_gen0_0_R95 <- cbind(rep =95, sum = dif_p1_gen0_0_R95)
dif_p1_gen0_0_R96 <- cbind(rep =96, sum = dif_p1_gen0_0_R96)
dif_p1_gen0_0_R97 <- cbind(rep =97, sum = dif_p1_gen0_0_R97)
dif_p1_gen0_0_R98 <- cbind(rep =98, sum = dif_p1_gen0_0_R98)
dif_p1_gen0_0_R99 <- cbind(rep =99, sum = dif_p1_gen0_0_R99)
dif_p1_gen0_0_R100 <- cbind(rep =100, sum = dif_p1_gen0_0_R100)


dif_p1_gen0_0 <- rbind(dif_p1_gen0_0_R1, dif_p1_gen0_0_R2, dif_p1_gen0_0_R3, dif_p1_gen0_0_R4, dif_p1_gen0_0_R5, dif_p1_gen0_0_R6,
                       dif_p1_gen0_0_R7, dif_p1_gen0_0_R8, dif_p1_gen0_0_R9, dif_p1_gen0_0_R10, dif_p1_gen0_0_R11, dif_p1_gen0_0_R12,
                       dif_p1_gen0_0_R13, dif_p1_gen0_0_R14, dif_p1_gen0_0_R15, dif_p1_gen0_0_R16, dif_p1_gen0_0_R17, dif_p1_gen0_0_R18,
                       dif_p1_gen0_0_R19, dif_p1_gen0_0_R20, dif_p1_gen0_0_R21, dif_p1_gen0_0_R22, dif_p1_gen0_0_R23, dif_p1_gen0_0_R24,
                       dif_p1_gen0_0_R25, dif_p1_gen0_0_R26, dif_p1_gen0_0_R27, dif_p1_gen0_0_R28, dif_p1_gen0_0_R29, dif_p1_gen0_0_R30,
                       dif_p1_gen0_0_R31, dif_p1_gen0_0_R32, dif_p1_gen0_0_R33, dif_p1_gen0_0_R34, dif_p1_gen0_0_R35, dif_p1_gen0_0_R36,
                       dif_p1_gen0_0_R37, dif_p1_gen0_0_R38, dif_p1_gen0_0_R39, dif_p1_gen0_0_R40, dif_p1_gen0_0_R41, dif_p1_gen0_0_R42,
                       dif_p1_gen0_0_R43, dif_p1_gen0_0_R44, dif_p1_gen0_0_R45, dif_p1_gen0_0_R46, dif_p1_gen0_0_R47,
                       dif_p1_gen0_0_R48, dif_p1_gen0_0_R49, dif_p1_gen0_0_R50, dif_p1_gen0_0_R51, dif_p1_gen0_0_R52, dif_p1_gen0_0_R53,
                       dif_p1_gen0_0_R54, dif_p1_gen0_0_R55, dif_p1_gen0_0_R56, dif_p1_gen0_0_R57, dif_p1_gen0_0_R58, dif_p1_gen0_0_R59,
                       dif_p1_gen0_0_R60, dif_p1_gen0_0_R61, dif_p1_gen0_0_R62, dif_p1_gen0_0_R63, dif_p1_gen0_0_R64, dif_p1_gen0_0_R65,
                       dif_p1_gen0_0_R66, dif_p1_gen0_0_R67, dif_p1_gen0_0_R68, dif_p1_gen0_0_R69, dif_p1_gen0_0_R70, dif_p1_gen0_0_R71,
                       dif_p1_gen0_0_R72, dif_p1_gen0_0_R73, dif_p1_gen0_0_R74, dif_p1_gen0_0_R75, dif_p1_gen0_0_R76, dif_p1_gen0_0_R77,
                       dif_p1_gen0_0_R78, dif_p1_gen0_0_R79, dif_p1_gen0_0_R80, dif_p1_gen0_0_R81, dif_p1_gen0_0_R82, dif_p1_gen0_0_R83,
                       dif_p1_gen0_0_R84, dif_p1_gen0_0_R85, dif_p1_gen0_0_R86, dif_p1_gen0_0_R87, dif_p1_gen0_0_R88, dif_p1_gen0_0_R89,
                       dif_p1_gen0_0_R90, dif_p1_gen0_0_R91, dif_p1_gen0_0_R92, dif_p1_gen0_0_R93, dif_p1_gen0_0_R94, dif_p1_gen0_0_R95,
                       dif_p1_gen0_0_R96, dif_p1_gen0_0_R97, dif_p1_gen0_0_R98, dif_p1_gen0_0_R99, dif_p1_gen0_0_R100)   

dif_p1_gen0_0 <- cbind(dif_gen = 0, pop=1,dif_p1_gen0_0) 

# sum of squared differences between generation 0 and 3 pop1 ----
sum((F_P1_G0_R1 - F_P1_G3_R1)^2) -> dif_p1_gen0_3_R1
sum((F_P1_G0_R2 - F_P1_G3_R2)^2) -> dif_p1_gen0_3_R2 
sum((F_P1_G0_R3 - F_P1_G3_R3)^2) -> dif_p1_gen0_3_R3 
sum((F_P1_G0_R4 - F_P1_G3_R4)^2) -> dif_p1_gen0_3_R4
sum((F_P1_G0_R5 - F_P1_G3_R5)^2) -> dif_p1_gen0_3_R5 
sum((F_P1_G0_R6 - F_P1_G3_R6)^2) -> dif_p1_gen0_3_R6 
sum((F_P1_G0_R7 - F_P1_G3_R7)^2) -> dif_p1_gen0_3_R7
sum((F_P1_G0_R8 - F_P1_G3_R8)^2) -> dif_p1_gen0_3_R8 
sum((F_P1_G0_R9 - F_P1_G3_R9)^2) -> dif_p1_gen0_3_R9 
sum((F_P1_G0_R10 - F_P1_G3_R10)^2) -> dif_p1_gen0_3_R10
sum((F_P1_G0_R11 - F_P1_G3_R11)^2) -> dif_p1_gen0_3_R11 
sum((F_P1_G0_R12 - F_P1_G3_R12)^2) -> dif_p1_gen0_3_R12 
sum((F_P1_G0_R13 - F_P1_G3_R13)^2) -> dif_p1_gen0_3_R13
sum((F_P1_G0_R14 - F_P1_G3_R14)^2) -> dif_p1_gen0_3_R14 
sum((F_P1_G0_R15 - F_P1_G3_R15)^2) -> dif_p1_gen0_3_R15 
sum((F_P1_G0_R16 - F_P1_G3_R16)^2) -> dif_p1_gen0_3_R16
sum((F_P1_G0_R17 - F_P1_G3_R17)^2) -> dif_p1_gen0_3_R17 
sum((F_P1_G0_R18 - F_P1_G3_R18)^2) -> dif_p1_gen0_3_R18 
sum((F_P1_G0_R19 - F_P1_G3_R19)^2) -> dif_p1_gen0_3_R19
sum((F_P1_G0_R20 - F_P1_G3_R20)^2) -> dif_p1_gen0_3_R20 
sum((F_P1_G0_R21 - F_P1_G3_R21)^2) -> dif_p1_gen0_3_R21 
sum((F_P1_G0_R22 - F_P1_G3_R22)^2) -> dif_p1_gen0_3_R22 
sum((F_P1_G0_R23 - F_P1_G3_R23)^2) -> dif_p1_gen0_3_R23
sum((F_P1_G0_R24 - F_P1_G3_R24)^2) -> dif_p1_gen0_3_R24 
sum((F_P1_G0_R25 - F_P1_G3_R25)^2) -> dif_p1_gen0_3_R25 
sum((F_P1_G0_R26 - F_P1_G3_R26)^2) -> dif_p1_gen0_3_R26
sum((F_P1_G0_R27 - F_P1_G3_R27)^2) -> dif_p1_gen0_3_R27 
sum((F_P1_G0_R28 - F_P1_G3_R28)^2) -> dif_p1_gen0_3_R28 
sum((F_P1_G0_R29 - F_P1_G3_R29)^2) -> dif_p1_gen0_3_R29
sum((F_P1_G0_R30 - F_P1_G3_R30)^2) -> dif_p1_gen0_3_R30 
sum((F_P1_G0_R31 - F_P1_G3_R31)^2) -> dif_p1_gen0_3_R31 
sum((F_P1_G0_R32 - F_P1_G3_R32)^2) -> dif_p1_gen0_3_R32 
sum((F_P1_G0_R33 - F_P1_G3_R33)^2) -> dif_p1_gen0_3_R33
sum((F_P1_G0_R34 - F_P1_G3_R34)^2) -> dif_p1_gen0_3_R34 
sum((F_P1_G0_R35 - F_P1_G3_R35)^2) -> dif_p1_gen0_3_R35 
sum((F_P1_G0_R36 - F_P1_G3_R36)^2) -> dif_p1_gen0_3_R36
sum((F_P1_G0_R37 - F_P1_G3_R37)^2) -> dif_p1_gen0_3_R37 
sum((F_P1_G0_R38 - F_P1_G3_R38)^2) -> dif_p1_gen0_3_R38 
sum((F_P1_G0_R39 - F_P1_G3_R39)^2) -> dif_p1_gen0_3_R39
sum((F_P1_G0_R40 - F_P1_G3_R40)^2) -> dif_p1_gen0_3_R40 
sum((F_P1_G0_R41 - F_P1_G3_R41)^2) -> dif_p1_gen0_3_R41 
sum((F_P1_G0_R42 - F_P1_G3_R42)^2) -> dif_p1_gen0_3_R42 
sum((F_P1_G0_R43 - F_P1_G3_R43)^2) -> dif_p1_gen0_3_R43
sum((F_P1_G0_R44 - F_P1_G3_R44)^2) -> dif_p1_gen0_3_R44 
sum((F_P1_G0_R45 - F_P1_G3_R45)^2) -> dif_p1_gen0_3_R45 
sum((F_P1_G0_R46 - F_P1_G3_R46)^2) -> dif_p1_gen0_3_R46
sum((F_P1_G0_R47 - F_P1_G3_R47)^2) -> dif_p1_gen0_3_R47
sum((F_P1_G0_R48 - F_P1_G3_R48)^2) -> dif_p1_gen0_3_R48 
sum((F_P1_G0_R49 - F_P1_G3_R49)^2) -> dif_p1_gen0_3_R49
sum((F_P1_G0_R50 - F_P1_G3_R50)^2) -> dif_p1_gen0_3_R50 
sum((F_P1_G0_R51 - F_P1_G3_R51)^2) -> dif_p1_gen0_3_R51 
sum((F_P1_G0_R52 - F_P1_G3_R52)^2) -> dif_p1_gen0_3_R52 
sum((F_P1_G0_R53 - F_P1_G3_R53)^2) -> dif_p1_gen0_3_R53
sum((F_P1_G0_R54 - F_P1_G3_R54)^2) -> dif_p1_gen0_3_R54 
sum((F_P1_G0_R55 - F_P1_G3_R55)^2) -> dif_p1_gen0_3_R55 
sum((F_P1_G0_R56 - F_P1_G3_R56)^2) -> dif_p1_gen0_3_R56
sum((F_P1_G0_R57 - F_P1_G3_R57)^2) -> dif_p1_gen0_3_R57 
sum((F_P1_G0_R58 - F_P1_G3_R58)^2) -> dif_p1_gen0_3_R58 
sum((F_P1_G0_R59 - F_P1_G3_R59)^2) -> dif_p1_gen0_3_R59
sum((F_P1_G0_R60 - F_P1_G3_R60)^2) -> dif_p1_gen0_3_R60 
sum((F_P1_G0_R61 - F_P1_G3_R61)^2) -> dif_p1_gen0_3_R61 
sum((F_P1_G0_R62 - F_P1_G3_R62)^2) -> dif_p1_gen0_3_R62 
sum((F_P1_G0_R63 - F_P1_G3_R63)^2) -> dif_p1_gen0_3_R63
sum((F_P1_G0_R64 - F_P1_G3_R64)^2) -> dif_p1_gen0_3_R64 
sum((F_P1_G0_R65 - F_P1_G3_R65)^2) -> dif_p1_gen0_3_R65 
sum((F_P1_G0_R66 - F_P1_G3_R66)^2) -> dif_p1_gen0_3_R66
sum((F_P1_G0_R67 - F_P1_G3_R67)^2) -> dif_p1_gen0_3_R67 
sum((F_P1_G0_R68 - F_P1_G3_R68)^2) -> dif_p1_gen0_3_R68 
sum((F_P1_G0_R69 - F_P1_G3_R69)^2) -> dif_p1_gen0_3_R69
sum((F_P1_G0_R70 - F_P1_G3_R70)^2) -> dif_p1_gen0_3_R70 
sum((F_P1_G0_R71 - F_P1_G3_R71)^2) -> dif_p1_gen0_3_R71 
sum((F_P1_G0_R72 - F_P1_G3_R72)^2) -> dif_p1_gen0_3_R72 
sum((F_P1_G0_R73 - F_P1_G3_R73)^2) -> dif_p1_gen0_3_R73
sum((F_P1_G0_R74 - F_P1_G3_R74)^2) -> dif_p1_gen0_3_R74 
sum((F_P1_G0_R75 - F_P1_G3_R75)^2) -> dif_p1_gen0_3_R75 
sum((F_P1_G0_R76 - F_P1_G3_R76)^2) -> dif_p1_gen0_3_R76
sum((F_P1_G0_R77 - F_P1_G3_R77)^2) -> dif_p1_gen0_3_R77
sum((F_P1_G0_R78 - F_P1_G3_R78)^2) -> dif_p1_gen0_3_R78 
sum((F_P1_G0_R79 - F_P1_G3_R79)^2) -> dif_p1_gen0_3_R79
sum((F_P1_G0_R80 - F_P1_G3_R80)^2) -> dif_p1_gen0_3_R80 
sum((F_P1_G0_R81 - F_P1_G3_R81)^2) -> dif_p1_gen0_3_R81 
sum((F_P1_G0_R82 - F_P1_G3_R82)^2) -> dif_p1_gen0_3_R82 
sum((F_P1_G0_R83 - F_P1_G3_R83)^2) -> dif_p1_gen0_3_R83
sum((F_P1_G0_R84 - F_P1_G3_R84)^2) -> dif_p1_gen0_3_R84 
sum((F_P1_G0_R85 - F_P1_G3_R85)^2) -> dif_p1_gen0_3_R85 
sum((F_P1_G0_R86 - F_P1_G3_R86)^2) -> dif_p1_gen0_3_R86
sum((F_P1_G0_R87 - F_P1_G3_R87)^2) -> dif_p1_gen0_3_R87 
sum((F_P1_G0_R88 - F_P1_G3_R88)^2) -> dif_p1_gen0_3_R88 
sum((F_P1_G0_R89 - F_P1_G3_R89)^2) -> dif_p1_gen0_3_R89
sum((F_P1_G0_R90 - F_P1_G3_R90)^2) -> dif_p1_gen0_3_R90 
sum((F_P1_G0_R91 - F_P1_G3_R91)^2) -> dif_p1_gen0_3_R91 
sum((F_P1_G0_R92 - F_P1_G3_R92)^2) -> dif_p1_gen0_3_R92 
sum((F_P1_G0_R93 - F_P1_G3_R93)^2) -> dif_p1_gen0_3_R93
sum((F_P1_G0_R94 - F_P1_G3_R94)^2) -> dif_p1_gen0_3_R94 
sum((F_P1_G0_R95 - F_P1_G3_R95)^2) -> dif_p1_gen0_3_R95 
sum((F_P1_G0_R96 - F_P1_G3_R96)^2) -> dif_p1_gen0_3_R96
sum((F_P1_G0_R97 - F_P1_G3_R97)^2) -> dif_p1_gen0_3_R97 
sum((F_P1_G0_R98 - F_P1_G3_R98)^2) -> dif_p1_gen0_3_R98 
sum((F_P1_G0_R99 - F_P1_G3_R99)^2) -> dif_p1_gen0_3_R99
sum((F_P1_G0_R100 - F_P1_G3_R100)^2) -> dif_p1_gen0_3_R100 

dif_p1_gen0_3_R1 <- cbind(rep =1, sum = dif_p1_gen0_3_R1)
dif_p1_gen0_3_R2 <- cbind(rep =2, sum = dif_p1_gen0_3_R2)
dif_p1_gen0_3_R3 <- cbind(rep =3, sum = dif_p1_gen0_3_R3)
dif_p1_gen0_3_R4 <- cbind(rep =4, sum = dif_p1_gen0_3_R4)
dif_p1_gen0_3_R5 <- cbind(rep =5, sum = dif_p1_gen0_3_R5)
dif_p1_gen0_3_R6 <- cbind(rep =6, sum = dif_p1_gen0_3_R6)
dif_p1_gen0_3_R7 <- cbind(rep =7, sum = dif_p1_gen0_3_R7)
dif_p1_gen0_3_R8 <- cbind(rep =8, sum = dif_p1_gen0_3_R8)
dif_p1_gen0_3_R9 <- cbind(rep =9, sum = dif_p1_gen0_3_R9)
dif_p1_gen0_3_R10 <- cbind(rep =10, sum = dif_p1_gen0_3_R10)
dif_p1_gen0_3_R11 <- cbind(rep =11, sum = dif_p1_gen0_3_R11)
dif_p1_gen0_3_R12 <- cbind(rep =12, sum = dif_p1_gen0_3_R12)
dif_p1_gen0_3_R13 <- cbind(rep =13, sum = dif_p1_gen0_3_R13)
dif_p1_gen0_3_R14 <- cbind(rep =14, sum = dif_p1_gen0_3_R14)
dif_p1_gen0_3_R15 <- cbind(rep =15, sum = dif_p1_gen0_3_R15)
dif_p1_gen0_3_R16 <- cbind(rep =16, sum = dif_p1_gen0_3_R16)
dif_p1_gen0_3_R17 <- cbind(rep =17, sum = dif_p1_gen0_3_R17)
dif_p1_gen0_3_R18 <- cbind(rep =18, sum = dif_p1_gen0_3_R18)
dif_p1_gen0_3_R19 <- cbind(rep =19, sum = dif_p1_gen0_3_R19)
dif_p1_gen0_3_R20 <- cbind(rep =20, sum = dif_p1_gen0_3_R20)
dif_p1_gen0_3_R21 <- cbind(rep =21, sum = dif_p1_gen0_3_R21)
dif_p1_gen0_3_R22 <- cbind(rep =22, sum = dif_p1_gen0_3_R22)
dif_p1_gen0_3_R23 <- cbind(rep =23, sum = dif_p1_gen0_3_R23)
dif_p1_gen0_3_R24 <- cbind(rep =24, sum = dif_p1_gen0_3_R24)
dif_p1_gen0_3_R25 <- cbind(rep =25, sum = dif_p1_gen0_3_R25)
dif_p1_gen0_3_R26 <- cbind(rep =26, sum = dif_p1_gen0_3_R26)
dif_p1_gen0_3_R27 <- cbind(rep =27, sum = dif_p1_gen0_3_R27)
dif_p1_gen0_3_R28 <- cbind(rep =28, sum = dif_p1_gen0_3_R28)
dif_p1_gen0_3_R29 <- cbind(rep =29, sum = dif_p1_gen0_3_R29)
dif_p1_gen0_3_R30 <- cbind(rep =30, sum = dif_p1_gen0_3_R30)
dif_p1_gen0_3_R31 <- cbind(rep =31, sum = dif_p1_gen0_3_R31)
dif_p1_gen0_3_R32 <- cbind(rep =32, sum = dif_p1_gen0_3_R32)
dif_p1_gen0_3_R33 <- cbind(rep =33, sum = dif_p1_gen0_3_R33)
dif_p1_gen0_3_R34 <- cbind(rep =34, sum = dif_p1_gen0_3_R34)
dif_p1_gen0_3_R35 <- cbind(rep =35, sum = dif_p1_gen0_3_R35)
dif_p1_gen0_3_R36 <- cbind(rep =36, sum = dif_p1_gen0_3_R36)
dif_p1_gen0_3_R37 <- cbind(rep =37, sum = dif_p1_gen0_3_R37)
dif_p1_gen0_3_R38 <- cbind(rep =38, sum = dif_p1_gen0_3_R38)
dif_p1_gen0_3_R39 <- cbind(rep =39, sum = dif_p1_gen0_3_R39)
dif_p1_gen0_3_R40 <- cbind(rep =40, sum = dif_p1_gen0_3_R40)
dif_p1_gen0_3_R41 <- cbind(rep =41, sum = dif_p1_gen0_3_R41)
dif_p1_gen0_3_R42 <- cbind(rep =42, sum = dif_p1_gen0_3_R42)
dif_p1_gen0_3_R43 <- cbind(rep =43, sum = dif_p1_gen0_3_R43)
dif_p1_gen0_3_R44 <- cbind(rep =44, sum = dif_p1_gen0_3_R44)
dif_p1_gen0_3_R45 <- cbind(rep =45, sum = dif_p1_gen0_3_R45)
dif_p1_gen0_3_R46 <- cbind(rep =46, sum = dif_p1_gen0_3_R46)
dif_p1_gen0_3_R47 <- cbind(rep =47, sum = dif_p1_gen0_3_R47)
dif_p1_gen0_3_R48 <- cbind(rep =48, sum = dif_p1_gen0_3_R48)
dif_p1_gen0_3_R49 <- cbind(rep =49, sum = dif_p1_gen0_3_R49)
dif_p1_gen0_3_R50 <- cbind(rep =50, sum = dif_p1_gen0_3_R50)
dif_p1_gen0_3_R51 <- cbind(rep =51, sum = dif_p1_gen0_3_R51)
dif_p1_gen0_3_R52 <- cbind(rep =52, sum = dif_p1_gen0_3_R52)
dif_p1_gen0_3_R53 <- cbind(rep =53, sum = dif_p1_gen0_3_R53)
dif_p1_gen0_3_R54 <- cbind(rep =54, sum = dif_p1_gen0_3_R54)
dif_p1_gen0_3_R55 <- cbind(rep =55, sum = dif_p1_gen0_3_R55)
dif_p1_gen0_3_R56 <- cbind(rep =56, sum = dif_p1_gen0_3_R56)
dif_p1_gen0_3_R57 <- cbind(rep =57, sum = dif_p1_gen0_3_R57)
dif_p1_gen0_3_R58 <- cbind(rep =58, sum = dif_p1_gen0_3_R58)
dif_p1_gen0_3_R59 <- cbind(rep =59, sum = dif_p1_gen0_3_R59)
dif_p1_gen0_3_R60 <- cbind(rep =60, sum = dif_p1_gen0_3_R60)
dif_p1_gen0_3_R61 <- cbind(rep =61, sum = dif_p1_gen0_3_R61)
dif_p1_gen0_3_R62 <- cbind(rep =62, sum = dif_p1_gen0_3_R62)
dif_p1_gen0_3_R63 <- cbind(rep =63, sum = dif_p1_gen0_3_R63)
dif_p1_gen0_3_R64 <- cbind(rep =64, sum = dif_p1_gen0_3_R64)
dif_p1_gen0_3_R65 <- cbind(rep =65, sum = dif_p1_gen0_3_R65)
dif_p1_gen0_3_R66 <- cbind(rep =66, sum = dif_p1_gen0_3_R66)
dif_p1_gen0_3_R67 <- cbind(rep =67, sum = dif_p1_gen0_3_R67)
dif_p1_gen0_3_R68 <- cbind(rep =68, sum = dif_p1_gen0_3_R68)
dif_p1_gen0_3_R69 <- cbind(rep =69, sum = dif_p1_gen0_3_R69)
dif_p1_gen0_3_R70 <- cbind(rep =70, sum = dif_p1_gen0_3_R70)
dif_p1_gen0_3_R71 <- cbind(rep =71, sum = dif_p1_gen0_3_R71)
dif_p1_gen0_3_R72 <- cbind(rep =72, sum = dif_p1_gen0_3_R72)
dif_p1_gen0_3_R73 <- cbind(rep =73, sum = dif_p1_gen0_3_R73)
dif_p1_gen0_3_R74 <- cbind(rep =74, sum = dif_p1_gen0_3_R74)
dif_p1_gen0_3_R75 <- cbind(rep =75, sum = dif_p1_gen0_3_R75)
dif_p1_gen0_3_R76 <- cbind(rep =76, sum = dif_p1_gen0_3_R76)
dif_p1_gen0_3_R77 <- cbind(rep =77, sum = dif_p1_gen0_3_R77)
dif_p1_gen0_3_R78 <- cbind(rep =78, sum = dif_p1_gen0_3_R78)
dif_p1_gen0_3_R79 <- cbind(rep =79, sum = dif_p1_gen0_3_R79)
dif_p1_gen0_3_R80 <- cbind(rep =80, sum = dif_p1_gen0_3_R80)
dif_p1_gen0_3_R81 <- cbind(rep =81, sum = dif_p1_gen0_3_R81)
dif_p1_gen0_3_R82 <- cbind(rep =82, sum = dif_p1_gen0_3_R82)
dif_p1_gen0_3_R83 <- cbind(rep =83, sum = dif_p1_gen0_3_R83)
dif_p1_gen0_3_R84 <- cbind(rep =84, sum = dif_p1_gen0_3_R84)
dif_p1_gen0_3_R85 <- cbind(rep =85, sum = dif_p1_gen0_3_R85)
dif_p1_gen0_3_R86 <- cbind(rep =86, sum = dif_p1_gen0_3_R86)
dif_p1_gen0_3_R87 <- cbind(rep =87, sum = dif_p1_gen0_3_R87)
dif_p1_gen0_3_R88 <- cbind(rep =88, sum = dif_p1_gen0_3_R88)
dif_p1_gen0_3_R89 <- cbind(rep =89, sum = dif_p1_gen0_3_R89)
dif_p1_gen0_3_R90 <- cbind(rep =90, sum = dif_p1_gen0_3_R90)
dif_p1_gen0_3_R91 <- cbind(rep =91, sum = dif_p1_gen0_3_R91)
dif_p1_gen0_3_R92 <- cbind(rep =92, sum = dif_p1_gen0_3_R92)
dif_p1_gen0_3_R93 <- cbind(rep =93, sum = dif_p1_gen0_3_R93)
dif_p1_gen0_3_R94 <- cbind(rep =94, sum = dif_p1_gen0_3_R94)
dif_p1_gen0_3_R95 <- cbind(rep =95, sum = dif_p1_gen0_3_R95)
dif_p1_gen0_3_R96 <- cbind(rep =96, sum = dif_p1_gen0_3_R96)
dif_p1_gen0_3_R97 <- cbind(rep =97, sum = dif_p1_gen0_3_R97)
dif_p1_gen0_3_R98 <- cbind(rep =98, sum = dif_p1_gen0_3_R98)
dif_p1_gen0_3_R99 <- cbind(rep =99, sum = dif_p1_gen0_3_R99)
dif_p1_gen0_3_R100 <- cbind(rep =100, sum = dif_p1_gen0_3_R100)



dif_p1_gen0_3 <- rbind(dif_p1_gen0_3_R1, dif_p1_gen0_3_R2, dif_p1_gen0_3_R3, dif_p1_gen0_3_R4, dif_p1_gen0_3_R5, dif_p1_gen0_3_R6,
                       dif_p1_gen0_3_R7, dif_p1_gen0_3_R8, dif_p1_gen0_3_R9, dif_p1_gen0_3_R10, dif_p1_gen0_3_R11, dif_p1_gen0_3_R12,
                       dif_p1_gen0_3_R13, dif_p1_gen0_3_R14, dif_p1_gen0_3_R15, dif_p1_gen0_3_R16, dif_p1_gen0_3_R17, dif_p1_gen0_3_R18,
                       dif_p1_gen0_3_R19, dif_p1_gen0_3_R20, dif_p1_gen0_3_R21, dif_p1_gen0_3_R22, dif_p1_gen0_3_R23, dif_p1_gen0_3_R24,
                       dif_p1_gen0_3_R25, dif_p1_gen0_3_R26, dif_p1_gen0_3_R27, dif_p1_gen0_3_R28, dif_p1_gen0_3_R29, dif_p1_gen0_3_R30,
                       dif_p1_gen0_3_R31, dif_p1_gen0_3_R32, dif_p1_gen0_3_R33, dif_p1_gen0_3_R34, dif_p1_gen0_3_R35, dif_p1_gen0_3_R36,
                       dif_p1_gen0_3_R37, dif_p1_gen0_3_R38, dif_p1_gen0_3_R39, dif_p1_gen0_3_R40, dif_p1_gen0_3_R41, dif_p1_gen0_3_R42,
                       dif_p1_gen0_3_R43, dif_p1_gen0_3_R44, dif_p1_gen0_3_R45, dif_p1_gen0_3_R46, dif_p1_gen0_3_R47,
                       dif_p1_gen0_3_R48, dif_p1_gen0_3_R49, dif_p1_gen0_3_R50, dif_p1_gen0_3_R51, dif_p1_gen0_3_R52, dif_p1_gen0_3_R53,
                       dif_p1_gen0_3_R54, dif_p1_gen0_3_R55, dif_p1_gen0_3_R56, dif_p1_gen0_3_R57, dif_p1_gen0_3_R58, dif_p1_gen0_3_R59,
                       dif_p1_gen0_3_R60, dif_p1_gen0_3_R61, dif_p1_gen0_3_R62, dif_p1_gen0_3_R63, dif_p1_gen0_3_R64, dif_p1_gen0_3_R65,
                       dif_p1_gen0_3_R66, dif_p1_gen0_3_R67, dif_p1_gen0_3_R68, dif_p1_gen0_3_R69, dif_p1_gen0_3_R70, dif_p1_gen0_3_R71,
                       dif_p1_gen0_3_R72, dif_p1_gen0_3_R73, dif_p1_gen0_3_R74, dif_p1_gen0_3_R75, dif_p1_gen0_3_R76, dif_p1_gen0_3_R77,
                       dif_p1_gen0_3_R78, dif_p1_gen0_3_R79, dif_p1_gen0_3_R80, dif_p1_gen0_3_R81, dif_p1_gen0_3_R82, dif_p1_gen0_3_R83,
                       dif_p1_gen0_3_R84, dif_p1_gen0_3_R85, dif_p1_gen0_3_R86, dif_p1_gen0_3_R87, dif_p1_gen0_3_R88, dif_p1_gen0_3_R89,
                       dif_p1_gen0_3_R90, dif_p1_gen0_3_R91, dif_p1_gen0_3_R92, dif_p1_gen0_3_R93, dif_p1_gen0_3_R94, dif_p1_gen0_3_R95,
                       dif_p1_gen0_3_R96, dif_p1_gen0_3_R97, dif_p1_gen0_3_R98, dif_p1_gen0_3_R99, dif_p1_gen0_3_R100)  

dif_p1_gen0_3 <- cbind(dif_gen = 3, pop=1,dif_p1_gen0_3)

# sum of squared differences between generation 0 and 6 pop1 ----
sum((F_P1_G0_R1 - F_P1_G6_R1)^2) -> dif_p1_gen0_6_R1
sum((F_P1_G0_R2 - F_P1_G6_R2)^2) -> dif_p1_gen0_6_R2 
sum((F_P1_G0_R3 - F_P1_G6_R3)^2) -> dif_p1_gen0_6_R3 
sum((F_P1_G0_R4 - F_P1_G6_R4)^2) -> dif_p1_gen0_6_R4
sum((F_P1_G0_R5 - F_P1_G6_R5)^2) -> dif_p1_gen0_6_R5 
sum((F_P1_G0_R6 - F_P1_G6_R6)^2) -> dif_p1_gen0_6_R6 
sum((F_P1_G0_R7 - F_P1_G6_R7)^2) -> dif_p1_gen0_6_R7
sum((F_P1_G0_R8 - F_P1_G6_R8)^2) -> dif_p1_gen0_6_R8 
sum((F_P1_G0_R9 - F_P1_G6_R9)^2) -> dif_p1_gen0_6_R9 
sum((F_P1_G0_R10 - F_P1_G6_R10)^2) -> dif_p1_gen0_6_R10
sum((F_P1_G0_R11 - F_P1_G6_R11)^2) -> dif_p1_gen0_6_R11 
sum((F_P1_G0_R12 - F_P1_G6_R12)^2) -> dif_p1_gen0_6_R12 
sum((F_P1_G0_R13 - F_P1_G6_R13)^2) -> dif_p1_gen0_6_R13
sum((F_P1_G0_R14 - F_P1_G6_R14)^2) -> dif_p1_gen0_6_R14 
sum((F_P1_G0_R15 - F_P1_G6_R15)^2) -> dif_p1_gen0_6_R15 
sum((F_P1_G0_R16 - F_P1_G6_R16)^2) -> dif_p1_gen0_6_R16
sum((F_P1_G0_R17 - F_P1_G6_R17)^2) -> dif_p1_gen0_6_R17 
sum((F_P1_G0_R18 - F_P1_G6_R18)^2) -> dif_p1_gen0_6_R18 
sum((F_P1_G0_R19 - F_P1_G6_R19)^2) -> dif_p1_gen0_6_R19
sum((F_P1_G0_R20 - F_P1_G6_R20)^2) -> dif_p1_gen0_6_R20 
sum((F_P1_G0_R21 - F_P1_G6_R21)^2) -> dif_p1_gen0_6_R21 
sum((F_P1_G0_R22 - F_P1_G6_R22)^2) -> dif_p1_gen0_6_R22 
sum((F_P1_G0_R23 - F_P1_G6_R23)^2) -> dif_p1_gen0_6_R23
sum((F_P1_G0_R24 - F_P1_G6_R24)^2) -> dif_p1_gen0_6_R24 
sum((F_P1_G0_R25 - F_P1_G6_R25)^2) -> dif_p1_gen0_6_R25 
sum((F_P1_G0_R26 - F_P1_G6_R26)^2) -> dif_p1_gen0_6_R26
sum((F_P1_G0_R27 - F_P1_G6_R27)^2) -> dif_p1_gen0_6_R27 
sum((F_P1_G0_R28 - F_P1_G6_R28)^2) -> dif_p1_gen0_6_R28 
sum((F_P1_G0_R29 - F_P1_G6_R29)^2) -> dif_p1_gen0_6_R29
sum((F_P1_G0_R30 - F_P1_G6_R30)^2) -> dif_p1_gen0_6_R30 
sum((F_P1_G0_R31 - F_P1_G6_R31)^2) -> dif_p1_gen0_6_R31 
sum((F_P1_G0_R32 - F_P1_G6_R32)^2) -> dif_p1_gen0_6_R32 
sum((F_P1_G0_R33 - F_P1_G6_R33)^2) -> dif_p1_gen0_6_R33
sum((F_P1_G0_R34 - F_P1_G6_R34)^2) -> dif_p1_gen0_6_R34 
sum((F_P1_G0_R35 - F_P1_G6_R35)^2) -> dif_p1_gen0_6_R35 
sum((F_P1_G0_R36 - F_P1_G6_R36)^2) -> dif_p1_gen0_6_R36
sum((F_P1_G0_R37 - F_P1_G6_R37)^2) -> dif_p1_gen0_6_R37 
sum((F_P1_G0_R38 - F_P1_G6_R38)^2) -> dif_p1_gen0_6_R38 
sum((F_P1_G0_R39 - F_P1_G6_R39)^2) -> dif_p1_gen0_6_R39
sum((F_P1_G0_R40 - F_P1_G6_R40)^2) -> dif_p1_gen0_6_R40 
sum((F_P1_G0_R41 - F_P1_G6_R41)^2) -> dif_p1_gen0_6_R41 
sum((F_P1_G0_R42 - F_P1_G6_R42)^2) -> dif_p1_gen0_6_R42 
sum((F_P1_G0_R43 - F_P1_G6_R43)^2) -> dif_p1_gen0_6_R43
sum((F_P1_G0_R44 - F_P1_G6_R44)^2) -> dif_p1_gen0_6_R44 
sum((F_P1_G0_R45 - F_P1_G6_R45)^2) -> dif_p1_gen0_6_R45 
sum((F_P1_G0_R46 - F_P1_G6_R46)^2) -> dif_p1_gen0_6_R46
sum((F_P1_G0_R47 - F_P1_G6_R47)^2) -> dif_p1_gen0_6_R47 
sum((F_P1_G0_R48 - F_P1_G6_R48)^2) -> dif_p1_gen0_6_R48 
sum((F_P1_G0_R49 - F_P1_G6_R49)^2) -> dif_p1_gen0_6_R49
sum((F_P1_G0_R50 - F_P1_G6_R50)^2) -> dif_p1_gen0_6_R50 
sum((F_P1_G0_R51 - F_P1_G6_R51)^2) -> dif_p1_gen0_6_R51 
sum((F_P1_G0_R52 - F_P1_G6_R52)^2) -> dif_p1_gen0_6_R52 
sum((F_P1_G0_R53 - F_P1_G6_R53)^2) -> dif_p1_gen0_6_R53
sum((F_P1_G0_R54 - F_P1_G6_R54)^2) -> dif_p1_gen0_6_R54 
sum((F_P1_G0_R55 - F_P1_G6_R55)^2) -> dif_p1_gen0_6_R55 
sum((F_P1_G0_R56 - F_P1_G6_R56)^2) -> dif_p1_gen0_6_R56
sum((F_P1_G0_R57 - F_P1_G6_R57)^2) -> dif_p1_gen0_6_R57 
sum((F_P1_G0_R58 - F_P1_G6_R58)^2) -> dif_p1_gen0_6_R58 
sum((F_P1_G0_R59 - F_P1_G6_R59)^2) -> dif_p1_gen0_6_R59
sum((F_P1_G0_R60 - F_P1_G6_R60)^2) -> dif_p1_gen0_6_R60 
sum((F_P1_G0_R61 - F_P1_G6_R61)^2) -> dif_p1_gen0_6_R61 
sum((F_P1_G0_R62 - F_P1_G6_R62)^2) -> dif_p1_gen0_6_R62 
sum((F_P1_G0_R63 - F_P1_G6_R63)^2) -> dif_p1_gen0_6_R63
sum((F_P1_G0_R64 - F_P1_G6_R64)^2) -> dif_p1_gen0_6_R64 
sum((F_P1_G0_R65 - F_P1_G6_R65)^2) -> dif_p1_gen0_6_R65 
sum((F_P1_G0_R66 - F_P1_G6_R66)^2) -> dif_p1_gen0_6_R66
sum((F_P1_G0_R67 - F_P1_G6_R67)^2) -> dif_p1_gen0_6_R67 
sum((F_P1_G0_R68 - F_P1_G6_R68)^2) -> dif_p1_gen0_6_R68 
sum((F_P1_G0_R69 - F_P1_G6_R69)^2) -> dif_p1_gen0_6_R69
sum((F_P1_G0_R70 - F_P1_G6_R70)^2) -> dif_p1_gen0_6_R70 
sum((F_P1_G0_R71 - F_P1_G6_R71)^2) -> dif_p1_gen0_6_R71 
sum((F_P1_G0_R72 - F_P1_G6_R72)^2) -> dif_p1_gen0_6_R72 
sum((F_P1_G0_R73 - F_P1_G6_R73)^2) -> dif_p1_gen0_6_R73
sum((F_P1_G0_R74 - F_P1_G6_R74)^2) -> dif_p1_gen0_6_R74 
sum((F_P1_G0_R75 - F_P1_G6_R75)^2) -> dif_p1_gen0_6_R75 
sum((F_P1_G0_R76 - F_P1_G6_R76)^2) -> dif_p1_gen0_6_R76
sum((F_P1_G0_R77 - F_P1_G6_R77)^2) -> dif_p1_gen0_6_R77 
sum((F_P1_G0_R78 - F_P1_G6_R78)^2) -> dif_p1_gen0_6_R78 
sum((F_P1_G0_R79 - F_P1_G6_R79)^2) -> dif_p1_gen0_6_R79
sum((F_P1_G0_R80 - F_P1_G6_R80)^2) -> dif_p1_gen0_6_R80 
sum((F_P1_G0_R81 - F_P1_G6_R81)^2) -> dif_p1_gen0_6_R81 
sum((F_P1_G0_R82 - F_P1_G6_R82)^2) -> dif_p1_gen0_6_R82 
sum((F_P1_G0_R83 - F_P1_G6_R83)^2) -> dif_p1_gen0_6_R83
sum((F_P1_G0_R84 - F_P1_G6_R84)^2) -> dif_p1_gen0_6_R84 
sum((F_P1_G0_R85 - F_P1_G6_R85)^2) -> dif_p1_gen0_6_R85 
sum((F_P1_G0_R86 - F_P1_G6_R86)^2) -> dif_p1_gen0_6_R86
sum((F_P1_G0_R87 - F_P1_G6_R87)^2) -> dif_p1_gen0_6_R87 
sum((F_P1_G0_R88 - F_P1_G6_R88)^2) -> dif_p1_gen0_6_R88 
sum((F_P1_G0_R89 - F_P1_G6_R89)^2) -> dif_p1_gen0_6_R89
sum((F_P1_G0_R90 - F_P1_G6_R90)^2) -> dif_p1_gen0_6_R90 
sum((F_P1_G0_R91 - F_P1_G6_R91)^2) -> dif_p1_gen0_6_R91 
sum((F_P1_G0_R92 - F_P1_G6_R92)^2) -> dif_p1_gen0_6_R92 
sum((F_P1_G0_R93 - F_P1_G6_R93)^2) -> dif_p1_gen0_6_R93
sum((F_P1_G0_R94 - F_P1_G6_R94)^2) -> dif_p1_gen0_6_R94 
sum((F_P1_G0_R95 - F_P1_G6_R95)^2) -> dif_p1_gen0_6_R95 
sum((F_P1_G0_R96 - F_P1_G6_R96)^2) -> dif_p1_gen0_6_R96
sum((F_P1_G0_R97 - F_P1_G6_R97)^2) -> dif_p1_gen0_6_R97 
sum((F_P1_G0_R98 - F_P1_G6_R98)^2) -> dif_p1_gen0_6_R98 
sum((F_P1_G0_R99 - F_P1_G6_R99)^2) -> dif_p1_gen0_6_R99
sum((F_P1_G0_R100 - F_P1_G6_R100)^2) -> dif_p1_gen0_6_R100

dif_p1_gen0_6_R1 <- cbind(rep =1, sum = dif_p1_gen0_6_R1)
dif_p1_gen0_6_R2 <- cbind(rep =2, sum = dif_p1_gen0_6_R2)
dif_p1_gen0_6_R3 <- cbind(rep =3, sum = dif_p1_gen0_6_R3)
dif_p1_gen0_6_R4 <- cbind(rep =4, sum = dif_p1_gen0_6_R4)
dif_p1_gen0_6_R5 <- cbind(rep =5, sum = dif_p1_gen0_6_R5)
dif_p1_gen0_6_R6 <- cbind(rep =6, sum = dif_p1_gen0_6_R6)
dif_p1_gen0_6_R7 <- cbind(rep =7, sum = dif_p1_gen0_6_R7)
dif_p1_gen0_6_R8 <- cbind(rep =8, sum = dif_p1_gen0_6_R8)
dif_p1_gen0_6_R9 <- cbind(rep =9, sum = dif_p1_gen0_6_R9)
dif_p1_gen0_6_R10 <- cbind(rep =10, sum = dif_p1_gen0_6_R10)
dif_p1_gen0_6_R11 <- cbind(rep =11, sum = dif_p1_gen0_6_R11)
dif_p1_gen0_6_R12 <- cbind(rep =12, sum = dif_p1_gen0_6_R12)
dif_p1_gen0_6_R13 <- cbind(rep =13, sum = dif_p1_gen0_6_R13)
dif_p1_gen0_6_R14 <- cbind(rep =14, sum = dif_p1_gen0_6_R14)
dif_p1_gen0_6_R15 <- cbind(rep =15, sum = dif_p1_gen0_6_R15)
dif_p1_gen0_6_R16 <- cbind(rep =16, sum = dif_p1_gen0_6_R16)
dif_p1_gen0_6_R17 <- cbind(rep =17, sum = dif_p1_gen0_6_R17)
dif_p1_gen0_6_R18 <- cbind(rep =18, sum = dif_p1_gen0_6_R18)
dif_p1_gen0_6_R19 <- cbind(rep =19, sum = dif_p1_gen0_6_R19)
dif_p1_gen0_6_R20 <- cbind(rep =20, sum = dif_p1_gen0_6_R20)
dif_p1_gen0_6_R21 <- cbind(rep =21, sum = dif_p1_gen0_6_R21)
dif_p1_gen0_6_R22 <- cbind(rep =22, sum = dif_p1_gen0_6_R22)
dif_p1_gen0_6_R23 <- cbind(rep =23, sum = dif_p1_gen0_6_R23)
dif_p1_gen0_6_R24 <- cbind(rep =24, sum = dif_p1_gen0_6_R24)
dif_p1_gen0_6_R25 <- cbind(rep =25, sum = dif_p1_gen0_6_R25)
dif_p1_gen0_6_R26 <- cbind(rep =26, sum = dif_p1_gen0_6_R26)
dif_p1_gen0_6_R27 <- cbind(rep =27, sum = dif_p1_gen0_6_R27)
dif_p1_gen0_6_R28 <- cbind(rep =28, sum = dif_p1_gen0_6_R28)
dif_p1_gen0_6_R29 <- cbind(rep =29, sum = dif_p1_gen0_6_R29)
dif_p1_gen0_6_R30 <- cbind(rep =30, sum = dif_p1_gen0_6_R30)
dif_p1_gen0_6_R31 <- cbind(rep =31, sum = dif_p1_gen0_6_R31)
dif_p1_gen0_6_R32 <- cbind(rep =32, sum = dif_p1_gen0_6_R32)
dif_p1_gen0_6_R33 <- cbind(rep =33, sum = dif_p1_gen0_6_R33)
dif_p1_gen0_6_R34 <- cbind(rep =34, sum = dif_p1_gen0_6_R34)
dif_p1_gen0_6_R35 <- cbind(rep =35, sum = dif_p1_gen0_6_R35)
dif_p1_gen0_6_R36 <- cbind(rep =36, sum = dif_p1_gen0_6_R36)
dif_p1_gen0_6_R37 <- cbind(rep =37, sum = dif_p1_gen0_6_R37)
dif_p1_gen0_6_R38 <- cbind(rep =38, sum = dif_p1_gen0_6_R38)
dif_p1_gen0_6_R39 <- cbind(rep =39, sum = dif_p1_gen0_6_R39)
dif_p1_gen0_6_R40 <- cbind(rep =40, sum = dif_p1_gen0_6_R40)
dif_p1_gen0_6_R41 <- cbind(rep =41, sum = dif_p1_gen0_6_R41)
dif_p1_gen0_6_R42 <- cbind(rep =42, sum = dif_p1_gen0_6_R42)
dif_p1_gen0_6_R43 <- cbind(rep =43, sum = dif_p1_gen0_6_R43)
dif_p1_gen0_6_R44 <- cbind(rep =44, sum = dif_p1_gen0_6_R44)
dif_p1_gen0_6_R45 <- cbind(rep =45, sum = dif_p1_gen0_6_R45)
dif_p1_gen0_6_R46 <- cbind(rep =46, sum = dif_p1_gen0_6_R46)
dif_p1_gen0_6_R47 <- cbind(rep =47, sum = dif_p1_gen0_6_R47)
dif_p1_gen0_6_R48 <- cbind(rep =48, sum = dif_p1_gen0_6_R48)
dif_p1_gen0_6_R49 <- cbind(rep =49, sum = dif_p1_gen0_6_R49)
dif_p1_gen0_6_R50 <- cbind(rep =50, sum = dif_p1_gen0_6_R50)
dif_p1_gen0_6_R51 <- cbind(rep =51, sum = dif_p1_gen0_6_R51)
dif_p1_gen0_6_R52 <- cbind(rep =52, sum = dif_p1_gen0_6_R52)
dif_p1_gen0_6_R53 <- cbind(rep =53, sum = dif_p1_gen0_6_R53)
dif_p1_gen0_6_R54 <- cbind(rep =54, sum = dif_p1_gen0_6_R54)
dif_p1_gen0_6_R55 <- cbind(rep =55, sum = dif_p1_gen0_6_R55)
dif_p1_gen0_6_R56 <- cbind(rep =56, sum = dif_p1_gen0_6_R56)
dif_p1_gen0_6_R57 <- cbind(rep =57, sum = dif_p1_gen0_6_R57)
dif_p1_gen0_6_R58 <- cbind(rep =58, sum = dif_p1_gen0_6_R58)
dif_p1_gen0_6_R59 <- cbind(rep =59, sum = dif_p1_gen0_6_R59)
dif_p1_gen0_6_R60 <- cbind(rep =60, sum = dif_p1_gen0_6_R60)
dif_p1_gen0_6_R61 <- cbind(rep =61, sum = dif_p1_gen0_6_R61)
dif_p1_gen0_6_R62 <- cbind(rep =62, sum = dif_p1_gen0_6_R62)
dif_p1_gen0_6_R63 <- cbind(rep =63, sum = dif_p1_gen0_6_R63)
dif_p1_gen0_6_R64 <- cbind(rep =64, sum = dif_p1_gen0_6_R64)
dif_p1_gen0_6_R65 <- cbind(rep =65, sum = dif_p1_gen0_6_R65)
dif_p1_gen0_6_R66 <- cbind(rep =66, sum = dif_p1_gen0_6_R66)
dif_p1_gen0_6_R67 <- cbind(rep =67, sum = dif_p1_gen0_6_R67)
dif_p1_gen0_6_R68 <- cbind(rep =68, sum = dif_p1_gen0_6_R68)
dif_p1_gen0_6_R69 <- cbind(rep =69, sum = dif_p1_gen0_6_R69)
dif_p1_gen0_6_R70 <- cbind(rep =70, sum = dif_p1_gen0_6_R70)
dif_p1_gen0_6_R71 <- cbind(rep =71, sum = dif_p1_gen0_6_R71)
dif_p1_gen0_6_R72 <- cbind(rep =72, sum = dif_p1_gen0_6_R72)
dif_p1_gen0_6_R73 <- cbind(rep =73, sum = dif_p1_gen0_6_R73)
dif_p1_gen0_6_R74 <- cbind(rep =74, sum = dif_p1_gen0_6_R74)
dif_p1_gen0_6_R75 <- cbind(rep =75, sum = dif_p1_gen0_6_R75)
dif_p1_gen0_6_R76 <- cbind(rep =76, sum = dif_p1_gen0_6_R76)
dif_p1_gen0_6_R77 <- cbind(rep =77, sum = dif_p1_gen0_6_R77)
dif_p1_gen0_6_R78 <- cbind(rep =78, sum = dif_p1_gen0_6_R78)
dif_p1_gen0_6_R79 <- cbind(rep =79, sum = dif_p1_gen0_6_R79)
dif_p1_gen0_6_R80 <- cbind(rep =80, sum = dif_p1_gen0_6_R80)
dif_p1_gen0_6_R81 <- cbind(rep =81, sum = dif_p1_gen0_6_R81)
dif_p1_gen0_6_R82 <- cbind(rep =82, sum = dif_p1_gen0_6_R82)
dif_p1_gen0_6_R83 <- cbind(rep =83, sum = dif_p1_gen0_6_R83)
dif_p1_gen0_6_R84 <- cbind(rep =84, sum = dif_p1_gen0_6_R84)
dif_p1_gen0_6_R85 <- cbind(rep =85, sum = dif_p1_gen0_6_R85)
dif_p1_gen0_6_R86 <- cbind(rep =86, sum = dif_p1_gen0_6_R86)
dif_p1_gen0_6_R87 <- cbind(rep =87, sum = dif_p1_gen0_6_R87)
dif_p1_gen0_6_R88 <- cbind(rep =88, sum = dif_p1_gen0_6_R88)
dif_p1_gen0_6_R89 <- cbind(rep =89, sum = dif_p1_gen0_6_R89)
dif_p1_gen0_6_R90 <- cbind(rep =90, sum = dif_p1_gen0_6_R90)
dif_p1_gen0_6_R91 <- cbind(rep =91, sum = dif_p1_gen0_6_R91)
dif_p1_gen0_6_R92 <- cbind(rep =92, sum = dif_p1_gen0_6_R92)
dif_p1_gen0_6_R93 <- cbind(rep =93, sum = dif_p1_gen0_6_R93)
dif_p1_gen0_6_R94 <- cbind(rep =94, sum = dif_p1_gen0_6_R94)
dif_p1_gen0_6_R95 <- cbind(rep =95, sum = dif_p1_gen0_6_R95)
dif_p1_gen0_6_R96 <- cbind(rep =96, sum = dif_p1_gen0_6_R96)
dif_p1_gen0_6_R97 <- cbind(rep =97, sum = dif_p1_gen0_6_R97)
dif_p1_gen0_6_R98 <- cbind(rep =98, sum = dif_p1_gen0_6_R98)
dif_p1_gen0_6_R99 <- cbind(rep =99, sum = dif_p1_gen0_6_R99)
dif_p1_gen0_6_R100 <- cbind(rep =100, sum = dif_p1_gen0_6_R100)


dif_p1_gen0_6 <- rbind(dif_p1_gen0_6_R1, dif_p1_gen0_6_R2, dif_p1_gen0_6_R3, dif_p1_gen0_6_R4, dif_p1_gen0_6_R5, dif_p1_gen0_6_R6,
                       dif_p1_gen0_6_R7, dif_p1_gen0_6_R8, dif_p1_gen0_6_R9, dif_p1_gen0_6_R10, dif_p1_gen0_6_R11, dif_p1_gen0_6_R12,
                       dif_p1_gen0_6_R13, dif_p1_gen0_6_R14, dif_p1_gen0_6_R15, dif_p1_gen0_6_R16, dif_p1_gen0_6_R17, dif_p1_gen0_6_R18,
                       dif_p1_gen0_6_R19, dif_p1_gen0_6_R20, dif_p1_gen0_6_R21, dif_p1_gen0_6_R22, dif_p1_gen0_6_R23, dif_p1_gen0_6_R24,
                       dif_p1_gen0_6_R25, dif_p1_gen0_6_R26, dif_p1_gen0_6_R27, dif_p1_gen0_6_R28, dif_p1_gen0_6_R29, dif_p1_gen0_6_R30,
                       dif_p1_gen0_6_R31, dif_p1_gen0_6_R32, dif_p1_gen0_6_R33, dif_p1_gen0_6_R34, dif_p1_gen0_6_R35, dif_p1_gen0_6_R36,
                       dif_p1_gen0_6_R37, dif_p1_gen0_6_R38, dif_p1_gen0_6_R39, dif_p1_gen0_6_R40, dif_p1_gen0_6_R41, dif_p1_gen0_6_R42,
                       dif_p1_gen0_6_R43, dif_p1_gen0_6_R44, dif_p1_gen0_6_R45, dif_p1_gen0_6_R46, dif_p1_gen0_6_R47,
                       dif_p1_gen0_6_R48, dif_p1_gen0_6_R49, dif_p1_gen0_6_R50, dif_p1_gen0_6_R51, dif_p1_gen0_6_R52, dif_p1_gen0_6_R53,
                       dif_p1_gen0_6_R54, dif_p1_gen0_6_R55, dif_p1_gen0_6_R56, dif_p1_gen0_6_R57, dif_p1_gen0_6_R58, dif_p1_gen0_6_R59,
                       dif_p1_gen0_6_R60, dif_p1_gen0_6_R61, dif_p1_gen0_6_R62, dif_p1_gen0_6_R63, dif_p1_gen0_6_R64, dif_p1_gen0_6_R65,
                       dif_p1_gen0_6_R66, dif_p1_gen0_6_R67, dif_p1_gen0_6_R68, dif_p1_gen0_6_R69, dif_p1_gen0_6_R70, dif_p1_gen0_6_R71,
                       dif_p1_gen0_6_R72, dif_p1_gen0_6_R73, dif_p1_gen0_6_R74, dif_p1_gen0_6_R75, dif_p1_gen0_6_R76, dif_p1_gen0_6_R77,
                       dif_p1_gen0_6_R78, dif_p1_gen0_6_R79, dif_p1_gen0_6_R80, dif_p1_gen0_6_R81, dif_p1_gen0_6_R82, dif_p1_gen0_6_R83,
                       dif_p1_gen0_6_R84, dif_p1_gen0_6_R85, dif_p1_gen0_6_R86, dif_p1_gen0_6_R87, dif_p1_gen0_6_R88, dif_p1_gen0_6_R89,
                       dif_p1_gen0_6_R90, dif_p1_gen0_6_R91, dif_p1_gen0_6_R92, dif_p1_gen0_6_R93, dif_p1_gen0_6_R94, dif_p1_gen0_6_R95,
                       dif_p1_gen0_6_R96, dif_p1_gen0_6_R97, dif_p1_gen0_6_R98, dif_p1_gen0_6_R99, dif_p1_gen0_6_R100)  

dif_p1_gen0_6 <- cbind(dif_gen = 6, pop=1, dif_p1_gen0_6)


# sum of squared differences between generation 0 and 10 pop1 ----
sum((F_P1_G0_R1 - F_P1_G10_R1)^2) -> dif_p1_gen0_10_R1
sum((F_P1_G0_R2 - F_P1_G10_R2)^2) -> dif_p1_gen0_10_R2 
sum((F_P1_G0_R3 - F_P1_G10_R3)^2) -> dif_p1_gen0_10_R3 
sum((F_P1_G0_R4 - F_P1_G10_R4)^2) -> dif_p1_gen0_10_R4
sum((F_P1_G0_R5 - F_P1_G10_R5)^2) -> dif_p1_gen0_10_R5 
sum((F_P1_G0_R6 - F_P1_G10_R6)^2) -> dif_p1_gen0_10_R6 
sum((F_P1_G0_R7 - F_P1_G10_R7)^2) -> dif_p1_gen0_10_R7
sum((F_P1_G0_R8 - F_P1_G10_R8)^2) -> dif_p1_gen0_10_R8 
sum((F_P1_G0_R9 - F_P1_G10_R9)^2) -> dif_p1_gen0_10_R9 
sum((F_P1_G0_R10 - F_P1_G10_R10)^2) -> dif_p1_gen0_10_R10
sum((F_P1_G0_R11 - F_P1_G10_R11)^2) -> dif_p1_gen0_10_R11 
sum((F_P1_G0_R12 - F_P1_G10_R12)^2) -> dif_p1_gen0_10_R12 
sum((F_P1_G0_R13 - F_P1_G10_R13)^2) -> dif_p1_gen0_10_R13
sum((F_P1_G0_R14 - F_P1_G10_R14)^2) -> dif_p1_gen0_10_R14 
sum((F_P1_G0_R15 - F_P1_G10_R15)^2) -> dif_p1_gen0_10_R15 
sum((F_P1_G0_R16 - F_P1_G10_R16)^2) -> dif_p1_gen0_10_R16
sum((F_P1_G0_R17 - F_P1_G10_R17)^2) -> dif_p1_gen0_10_R17 
sum((F_P1_G0_R18 - F_P1_G10_R18)^2) -> dif_p1_gen0_10_R18 
sum((F_P1_G0_R19 - F_P1_G10_R19)^2) -> dif_p1_gen0_10_R19
sum((F_P1_G0_R20 - F_P1_G10_R20)^2) -> dif_p1_gen0_10_R20 
sum((F_P1_G0_R21 - F_P1_G10_R21)^2) -> dif_p1_gen0_10_R21 
sum((F_P1_G0_R22 - F_P1_G10_R22)^2) -> dif_p1_gen0_10_R22 
sum((F_P1_G0_R23 - F_P1_G10_R23)^2) -> dif_p1_gen0_10_R23
sum((F_P1_G0_R24 - F_P1_G10_R24)^2) -> dif_p1_gen0_10_R24 
sum((F_P1_G0_R25 - F_P1_G10_R25)^2) -> dif_p1_gen0_10_R25 
sum((F_P1_G0_R26 - F_P1_G10_R26)^2) -> dif_p1_gen0_10_R26
sum((F_P1_G0_R27 - F_P1_G10_R27)^2) -> dif_p1_gen0_10_R27 
sum((F_P1_G0_R28 - F_P1_G10_R28)^2) -> dif_p1_gen0_10_R28 
sum((F_P1_G0_R29 - F_P1_G10_R29)^2) -> dif_p1_gen0_10_R29
sum((F_P1_G0_R30 - F_P1_G10_R30)^2) -> dif_p1_gen0_10_R30 
sum((F_P1_G0_R31 - F_P1_G10_R31)^2) -> dif_p1_gen0_10_R31 
sum((F_P1_G0_R32 - F_P1_G10_R32)^2) -> dif_p1_gen0_10_R32 
sum((F_P1_G0_R33 - F_P1_G10_R33)^2) -> dif_p1_gen0_10_R33
sum((F_P1_G0_R34 - F_P1_G10_R34)^2) -> dif_p1_gen0_10_R34 
sum((F_P1_G0_R35 - F_P1_G10_R35)^2) -> dif_p1_gen0_10_R35 
sum((F_P1_G0_R36 - F_P1_G10_R36)^2) -> dif_p1_gen0_10_R36
sum((F_P1_G0_R37 - F_P1_G10_R37)^2) -> dif_p1_gen0_10_R37 
sum((F_P1_G0_R38 - F_P1_G10_R38)^2) -> dif_p1_gen0_10_R38 
sum((F_P1_G0_R39 - F_P1_G10_R39)^2) -> dif_p1_gen0_10_R39
sum((F_P1_G0_R40 - F_P1_G10_R40)^2) -> dif_p1_gen0_10_R40 
sum((F_P1_G0_R41 - F_P1_G10_R41)^2) -> dif_p1_gen0_10_R41 
sum((F_P1_G0_R42 - F_P1_G10_R42)^2) -> dif_p1_gen0_10_R42 
sum((F_P1_G0_R43 - F_P1_G10_R43)^2) -> dif_p1_gen0_10_R43
sum((F_P1_G0_R44 - F_P1_G10_R44)^2) -> dif_p1_gen0_10_R44 
sum((F_P1_G0_R45 - F_P1_G10_R45)^2) -> dif_p1_gen0_10_R45 
sum((F_P1_G0_R46 - F_P1_G10_R46)^2) -> dif_p1_gen0_10_R46
sum((F_P1_G0_R47 - F_P1_G10_R47)^2) -> dif_p1_gen0_10_R47 
sum((F_P1_G0_R48 - F_P1_G10_R48)^2) -> dif_p1_gen0_10_R48 
sum((F_P1_G0_R49 - F_P1_G10_R49)^2) -> dif_p1_gen0_10_R49
sum((F_P1_G0_R50 - F_P1_G10_R50)^2) -> dif_p1_gen0_10_R50 
sum((F_P1_G0_R51 - F_P1_G10_R51)^2) -> dif_p1_gen0_10_R51 
sum((F_P1_G0_R52 - F_P1_G10_R52)^2) -> dif_p1_gen0_10_R52 
sum((F_P1_G0_R53 - F_P1_G10_R53)^2) -> dif_p1_gen0_10_R53
sum((F_P1_G0_R54 - F_P1_G10_R54)^2) -> dif_p1_gen0_10_R54 
sum((F_P1_G0_R55 - F_P1_G10_R55)^2) -> dif_p1_gen0_10_R55 
sum((F_P1_G0_R56 - F_P1_G10_R56)^2) -> dif_p1_gen0_10_R56
sum((F_P1_G0_R57 - F_P1_G10_R57)^2) -> dif_p1_gen0_10_R57 
sum((F_P1_G0_R58 - F_P1_G10_R58)^2) -> dif_p1_gen0_10_R58 
sum((F_P1_G0_R59 - F_P1_G10_R59)^2) -> dif_p1_gen0_10_R59
sum((F_P1_G0_R60 - F_P1_G10_R60)^2) -> dif_p1_gen0_10_R60 
sum((F_P1_G0_R61 - F_P1_G10_R61)^2) -> dif_p1_gen0_10_R61 
sum((F_P1_G0_R62 - F_P1_G10_R62)^2) -> dif_p1_gen0_10_R62 
sum((F_P1_G0_R63 - F_P1_G10_R63)^2) -> dif_p1_gen0_10_R63
sum((F_P1_G0_R64 - F_P1_G10_R64)^2) -> dif_p1_gen0_10_R64 
sum((F_P1_G0_R65 - F_P1_G10_R65)^2) -> dif_p1_gen0_10_R65 
sum((F_P1_G0_R66 - F_P1_G10_R66)^2) -> dif_p1_gen0_10_R66
sum((F_P1_G0_R67 - F_P1_G10_R67)^2) -> dif_p1_gen0_10_R67 
sum((F_P1_G0_R68 - F_P1_G10_R68)^2) -> dif_p1_gen0_10_R68 
sum((F_P1_G0_R69 - F_P1_G10_R69)^2) -> dif_p1_gen0_10_R69
sum((F_P1_G0_R70 - F_P1_G10_R70)^2) -> dif_p1_gen0_10_R70 
sum((F_P1_G0_R71 - F_P1_G10_R71)^2) -> dif_p1_gen0_10_R71 
sum((F_P1_G0_R72 - F_P1_G10_R72)^2) -> dif_p1_gen0_10_R72 
sum((F_P1_G0_R73 - F_P1_G10_R73)^2) -> dif_p1_gen0_10_R73
sum((F_P1_G0_R74 - F_P1_G10_R74)^2) -> dif_p1_gen0_10_R74 
sum((F_P1_G0_R75 - F_P1_G10_R75)^2) -> dif_p1_gen0_10_R75 
sum((F_P1_G0_R76 - F_P1_G10_R76)^2) -> dif_p1_gen0_10_R76
sum((F_P1_G0_R77 - F_P1_G10_R77)^2) -> dif_p1_gen0_10_R77 
sum((F_P1_G0_R78 - F_P1_G10_R78)^2) -> dif_p1_gen0_10_R78 
sum((F_P1_G0_R79 - F_P1_G10_R79)^2) -> dif_p1_gen0_10_R79
sum((F_P1_G0_R80 - F_P1_G10_R80)^2) -> dif_p1_gen0_10_R80 
sum((F_P1_G0_R81 - F_P1_G10_R81)^2) -> dif_p1_gen0_10_R81 
sum((F_P1_G0_R82 - F_P1_G10_R82)^2) -> dif_p1_gen0_10_R82 
sum((F_P1_G0_R83 - F_P1_G10_R83)^2) -> dif_p1_gen0_10_R83
sum((F_P1_G0_R84 - F_P1_G10_R84)^2) -> dif_p1_gen0_10_R84 
sum((F_P1_G0_R85 - F_P1_G10_R85)^2) -> dif_p1_gen0_10_R85 
sum((F_P1_G0_R86 - F_P1_G10_R86)^2) -> dif_p1_gen0_10_R86
sum((F_P1_G0_R87 - F_P1_G10_R87)^2) -> dif_p1_gen0_10_R87 
sum((F_P1_G0_R88 - F_P1_G10_R88)^2) -> dif_p1_gen0_10_R88 
sum((F_P1_G0_R89 - F_P1_G10_R89)^2) -> dif_p1_gen0_10_R89
sum((F_P1_G0_R90 - F_P1_G10_R90)^2) -> dif_p1_gen0_10_R90 
sum((F_P1_G0_R91 - F_P1_G10_R91)^2) -> dif_p1_gen0_10_R91 
sum((F_P1_G0_R92 - F_P1_G10_R92)^2) -> dif_p1_gen0_10_R92 
sum((F_P1_G0_R93 - F_P1_G10_R93)^2) -> dif_p1_gen0_10_R93
sum((F_P1_G0_R94 - F_P1_G10_R94)^2) -> dif_p1_gen0_10_R94 
sum((F_P1_G0_R95 - F_P1_G10_R95)^2) -> dif_p1_gen0_10_R95 
sum((F_P1_G0_R96 - F_P1_G10_R96)^2) -> dif_p1_gen0_10_R96
sum((F_P1_G0_R97 - F_P1_G10_R97)^2) -> dif_p1_gen0_10_R97 
sum((F_P1_G0_R98 - F_P1_G10_R98)^2) -> dif_p1_gen0_10_R98 
sum((F_P1_G0_R99 - F_P1_G10_R99)^2) -> dif_p1_gen0_10_R99
sum((F_P1_G0_R100 - F_P1_G10_R100)^2) -> dif_p1_gen0_10_R100 

dif_p1_gen0_10_R1 <- cbind(rep =1, sum = dif_p1_gen0_10_R1)
dif_p1_gen0_10_R2 <- cbind(rep =2, sum = dif_p1_gen0_10_R2)
dif_p1_gen0_10_R3 <- cbind(rep =3, sum = dif_p1_gen0_10_R3)
dif_p1_gen0_10_R4 <- cbind(rep =4, sum = dif_p1_gen0_10_R4)
dif_p1_gen0_10_R5 <- cbind(rep =5, sum = dif_p1_gen0_10_R5)
dif_p1_gen0_10_R6 <- cbind(rep =6, sum = dif_p1_gen0_10_R6)
dif_p1_gen0_10_R7 <- cbind(rep =7, sum = dif_p1_gen0_10_R7)
dif_p1_gen0_10_R8 <- cbind(rep =8, sum = dif_p1_gen0_10_R8)
dif_p1_gen0_10_R9 <- cbind(rep =9, sum = dif_p1_gen0_10_R9)
dif_p1_gen0_10_R10 <- cbind(rep =10, sum = dif_p1_gen0_10_R10)
dif_p1_gen0_10_R11 <- cbind(rep =11, sum = dif_p1_gen0_10_R11)
dif_p1_gen0_10_R12 <- cbind(rep =12, sum = dif_p1_gen0_10_R12)
dif_p1_gen0_10_R13 <- cbind(rep =13, sum = dif_p1_gen0_10_R13)
dif_p1_gen0_10_R14 <- cbind(rep =14, sum = dif_p1_gen0_10_R14)
dif_p1_gen0_10_R15 <- cbind(rep =15, sum = dif_p1_gen0_10_R15)
dif_p1_gen0_10_R16 <- cbind(rep =16, sum = dif_p1_gen0_10_R16)
dif_p1_gen0_10_R17 <- cbind(rep =17, sum = dif_p1_gen0_10_R17)
dif_p1_gen0_10_R18 <- cbind(rep =18, sum = dif_p1_gen0_10_R18)
dif_p1_gen0_10_R19 <- cbind(rep =19, sum = dif_p1_gen0_10_R19)
dif_p1_gen0_10_R20 <- cbind(rep =20, sum = dif_p1_gen0_10_R20)
dif_p1_gen0_10_R21 <- cbind(rep =21, sum = dif_p1_gen0_10_R21)
dif_p1_gen0_10_R22 <- cbind(rep =22, sum = dif_p1_gen0_10_R22)
dif_p1_gen0_10_R23 <- cbind(rep =23, sum = dif_p1_gen0_10_R23)
dif_p1_gen0_10_R24 <- cbind(rep =24, sum = dif_p1_gen0_10_R24)
dif_p1_gen0_10_R25 <- cbind(rep =25, sum = dif_p1_gen0_10_R25)
dif_p1_gen0_10_R26 <- cbind(rep =26, sum = dif_p1_gen0_10_R26)
dif_p1_gen0_10_R27 <- cbind(rep =27, sum = dif_p1_gen0_10_R27)
dif_p1_gen0_10_R28 <- cbind(rep =28, sum = dif_p1_gen0_10_R28)
dif_p1_gen0_10_R29 <- cbind(rep =29, sum = dif_p1_gen0_10_R29)
dif_p1_gen0_10_R30 <- cbind(rep =30, sum = dif_p1_gen0_10_R30)
dif_p1_gen0_10_R31 <- cbind(rep =31, sum = dif_p1_gen0_10_R31)
dif_p1_gen0_10_R32 <- cbind(rep =32, sum = dif_p1_gen0_10_R32)
dif_p1_gen0_10_R33 <- cbind(rep =33, sum = dif_p1_gen0_10_R33)
dif_p1_gen0_10_R34 <- cbind(rep =34, sum = dif_p1_gen0_10_R34)
dif_p1_gen0_10_R35 <- cbind(rep =35, sum = dif_p1_gen0_10_R35)
dif_p1_gen0_10_R36 <- cbind(rep =36, sum = dif_p1_gen0_10_R36)
dif_p1_gen0_10_R37 <- cbind(rep =37, sum = dif_p1_gen0_10_R37)
dif_p1_gen0_10_R38 <- cbind(rep =38, sum = dif_p1_gen0_10_R38)
dif_p1_gen0_10_R39 <- cbind(rep =39, sum = dif_p1_gen0_10_R39)
dif_p1_gen0_10_R40 <- cbind(rep =40, sum = dif_p1_gen0_10_R40)
dif_p1_gen0_10_R41 <- cbind(rep =41, sum = dif_p1_gen0_10_R41)
dif_p1_gen0_10_R42 <- cbind(rep =42, sum = dif_p1_gen0_10_R42)
dif_p1_gen0_10_R43 <- cbind(rep =43, sum = dif_p1_gen0_10_R43)
dif_p1_gen0_10_R44 <- cbind(rep =44, sum = dif_p1_gen0_10_R44)
dif_p1_gen0_10_R45 <- cbind(rep =45, sum = dif_p1_gen0_10_R45)
dif_p1_gen0_10_R46 <- cbind(rep =46, sum = dif_p1_gen0_10_R46)
dif_p1_gen0_10_R47 <- cbind(rep =47, sum = dif_p1_gen0_10_R47)
dif_p1_gen0_10_R48 <- cbind(rep =48, sum = dif_p1_gen0_10_R48)
dif_p1_gen0_10_R49 <- cbind(rep =49, sum = dif_p1_gen0_10_R49)
dif_p1_gen0_10_R50 <- cbind(rep =50, sum = dif_p1_gen0_10_R50)
dif_p1_gen0_10_R51 <- cbind(rep =51, sum = dif_p1_gen0_10_R51)
dif_p1_gen0_10_R52 <- cbind(rep =52, sum = dif_p1_gen0_10_R52)
dif_p1_gen0_10_R53 <- cbind(rep =53, sum = dif_p1_gen0_10_R53)
dif_p1_gen0_10_R54 <- cbind(rep =54, sum = dif_p1_gen0_10_R54)
dif_p1_gen0_10_R55 <- cbind(rep =55, sum = dif_p1_gen0_10_R55)
dif_p1_gen0_10_R56 <- cbind(rep =56, sum = dif_p1_gen0_10_R56)
dif_p1_gen0_10_R57 <- cbind(rep =57, sum = dif_p1_gen0_10_R57)
dif_p1_gen0_10_R58 <- cbind(rep =58, sum = dif_p1_gen0_10_R58)
dif_p1_gen0_10_R59 <- cbind(rep =59, sum = dif_p1_gen0_10_R59)
dif_p1_gen0_10_R60 <- cbind(rep =60, sum = dif_p1_gen0_10_R60)
dif_p1_gen0_10_R61 <- cbind(rep =61, sum = dif_p1_gen0_10_R61)
dif_p1_gen0_10_R62 <- cbind(rep =62, sum = dif_p1_gen0_10_R62)
dif_p1_gen0_10_R63 <- cbind(rep =63, sum = dif_p1_gen0_10_R63)
dif_p1_gen0_10_R64 <- cbind(rep =64, sum = dif_p1_gen0_10_R64)
dif_p1_gen0_10_R65 <- cbind(rep =65, sum = dif_p1_gen0_10_R65)
dif_p1_gen0_10_R66 <- cbind(rep =66, sum = dif_p1_gen0_10_R66)
dif_p1_gen0_10_R67 <- cbind(rep =67, sum = dif_p1_gen0_10_R67)
dif_p1_gen0_10_R68 <- cbind(rep =68, sum = dif_p1_gen0_10_R68)
dif_p1_gen0_10_R69 <- cbind(rep =69, sum = dif_p1_gen0_10_R69)
dif_p1_gen0_10_R70 <- cbind(rep =70, sum = dif_p1_gen0_10_R70)
dif_p1_gen0_10_R71 <- cbind(rep =71, sum = dif_p1_gen0_10_R71)
dif_p1_gen0_10_R72 <- cbind(rep =72, sum = dif_p1_gen0_10_R72)
dif_p1_gen0_10_R73 <- cbind(rep =73, sum = dif_p1_gen0_10_R73)
dif_p1_gen0_10_R74 <- cbind(rep =74, sum = dif_p1_gen0_10_R74)
dif_p1_gen0_10_R75 <- cbind(rep =75, sum = dif_p1_gen0_10_R75)
dif_p1_gen0_10_R76 <- cbind(rep =76, sum = dif_p1_gen0_10_R76)
dif_p1_gen0_10_R77 <- cbind(rep =77, sum = dif_p1_gen0_10_R77)
dif_p1_gen0_10_R78 <- cbind(rep =78, sum = dif_p1_gen0_10_R78)
dif_p1_gen0_10_R79 <- cbind(rep =79, sum = dif_p1_gen0_10_R79)
dif_p1_gen0_10_R80 <- cbind(rep =80, sum = dif_p1_gen0_10_R80)
dif_p1_gen0_10_R81 <- cbind(rep =81, sum = dif_p1_gen0_10_R81)
dif_p1_gen0_10_R82 <- cbind(rep =82, sum = dif_p1_gen0_10_R82)
dif_p1_gen0_10_R83 <- cbind(rep =83, sum = dif_p1_gen0_10_R83)
dif_p1_gen0_10_R84 <- cbind(rep =84, sum = dif_p1_gen0_10_R84)
dif_p1_gen0_10_R85 <- cbind(rep =85, sum = dif_p1_gen0_10_R85)
dif_p1_gen0_10_R86 <- cbind(rep =86, sum = dif_p1_gen0_10_R86)
dif_p1_gen0_10_R87 <- cbind(rep =87, sum = dif_p1_gen0_10_R87)
dif_p1_gen0_10_R88 <- cbind(rep =88, sum = dif_p1_gen0_10_R88)
dif_p1_gen0_10_R89 <- cbind(rep =89, sum = dif_p1_gen0_10_R89)
dif_p1_gen0_10_R90 <- cbind(rep =90, sum = dif_p1_gen0_10_R90)
dif_p1_gen0_10_R91 <- cbind(rep =91, sum = dif_p1_gen0_10_R91)
dif_p1_gen0_10_R92 <- cbind(rep =92, sum = dif_p1_gen0_10_R92)
dif_p1_gen0_10_R93 <- cbind(rep =93, sum = dif_p1_gen0_10_R93)
dif_p1_gen0_10_R94 <- cbind(rep =94, sum = dif_p1_gen0_10_R94)
dif_p1_gen0_10_R95 <- cbind(rep =95, sum = dif_p1_gen0_10_R95)
dif_p1_gen0_10_R96 <- cbind(rep =96, sum = dif_p1_gen0_10_R96)
dif_p1_gen0_10_R97 <- cbind(rep =97, sum = dif_p1_gen0_10_R97)
dif_p1_gen0_10_R98 <- cbind(rep =98, sum = dif_p1_gen0_10_R98)
dif_p1_gen0_10_R99 <- cbind(rep =99, sum = dif_p1_gen0_10_R99)
dif_p1_gen0_10_R100 <- cbind(rep =100, sum = dif_p1_gen0_10_R100)


dif_p1_gen0_10 <- rbind(dif_p1_gen0_10_R1, dif_p1_gen0_10_R2, dif_p1_gen0_10_R3, dif_p1_gen0_10_R4, dif_p1_gen0_10_R5, dif_p1_gen0_10_R6,
                        dif_p1_gen0_10_R7, dif_p1_gen0_10_R8, dif_p1_gen0_10_R9, dif_p1_gen0_10_R10, dif_p1_gen0_10_R11, dif_p1_gen0_10_R12,
                        dif_p1_gen0_10_R13, dif_p1_gen0_10_R14, dif_p1_gen0_10_R15, dif_p1_gen0_10_R16, dif_p1_gen0_10_R17, dif_p1_gen0_10_R18,
                        dif_p1_gen0_10_R19, dif_p1_gen0_10_R20, dif_p1_gen0_10_R21, dif_p1_gen0_10_R22, dif_p1_gen0_10_R23, dif_p1_gen0_10_R24,
                        dif_p1_gen0_10_R25, dif_p1_gen0_10_R26, dif_p1_gen0_10_R27, dif_p1_gen0_10_R28, dif_p1_gen0_10_R29, dif_p1_gen0_10_R30,
                        dif_p1_gen0_10_R31, dif_p1_gen0_10_R32, dif_p1_gen0_10_R33, dif_p1_gen0_10_R34, dif_p1_gen0_10_R35, dif_p1_gen0_10_R36,
                        dif_p1_gen0_10_R37, dif_p1_gen0_10_R38, dif_p1_gen0_10_R39, dif_p1_gen0_10_R40, dif_p1_gen0_10_R41, dif_p1_gen0_10_R42,
                        dif_p1_gen0_10_R43, dif_p1_gen0_10_R44, dif_p1_gen0_10_R45, dif_p1_gen0_10_R46, dif_p1_gen0_10_R47,
                        dif_p1_gen0_10_R48, dif_p1_gen0_10_R49, dif_p1_gen0_10_R50, dif_p1_gen0_10_R51, dif_p1_gen0_10_R52, dif_p1_gen0_10_R53,
                        dif_p1_gen0_10_R54, dif_p1_gen0_10_R55, dif_p1_gen0_10_R56, dif_p1_gen0_10_R57, dif_p1_gen0_10_R58, dif_p1_gen0_10_R59,
                        dif_p1_gen0_10_R60, dif_p1_gen0_10_R61, dif_p1_gen0_10_R62, dif_p1_gen0_10_R63, dif_p1_gen0_10_R64, dif_p1_gen0_10_R65,
                        dif_p1_gen0_10_R66, dif_p1_gen0_10_R67, dif_p1_gen0_10_R68, dif_p1_gen0_10_R69, dif_p1_gen0_10_R70, dif_p1_gen0_10_R71,
                        dif_p1_gen0_10_R72, dif_p1_gen0_10_R73, dif_p1_gen0_10_R74, dif_p1_gen0_10_R75, dif_p1_gen0_10_R76, dif_p1_gen0_10_R77,
                        dif_p1_gen0_10_R78, dif_p1_gen0_10_R79, dif_p1_gen0_10_R80, dif_p1_gen0_10_R81, dif_p1_gen0_10_R82, dif_p1_gen0_10_R83,
                        dif_p1_gen0_10_R84, dif_p1_gen0_10_R85, dif_p1_gen0_10_R86, dif_p1_gen0_10_R87, dif_p1_gen0_10_R88, dif_p1_gen0_10_R89,
                        dif_p1_gen0_10_R90, dif_p1_gen0_10_R91, dif_p1_gen0_10_R92, dif_p1_gen0_10_R93, dif_p1_gen0_10_R94, dif_p1_gen0_10_R95,
                        dif_p1_gen0_10_R96, dif_p1_gen0_10_R97, dif_p1_gen0_10_R98, dif_p1_gen0_10_R99, dif_p1_gen0_10_R100)

dif_p1_gen0_10 <- cbind(dif_gen = 10, pop=1, dif_p1_gen0_10)


dif_p1 <- rbind(dif_p1_gen0_0, dif_p1_gen0_3, dif_p1_gen0_6, dif_p1_gen0_10)

dif_p1 <- as.data.frame(dif_p1)
dif_p1$sum <- (dif_p1$sum)/30
dif_p1$dif_gen <- as.factor(dif_p1$dif_gen)
dif_p1$pop <- as.factor(dif_p1$pop)

ggplot(aes(y = sum, x = dif_gen, fill = pop), data = dif_p1) + geom_boxplot() + labs(title="allele frequencies") + 
  xlab('generation') + ylab('distance')

# sum of squared differences between generation 0 and 0 pop2 ----
sum((F_P2_G0_R1 - FS_P2_G0_R1)^2) -> dif_p2_gen0_0_R1
sum((F_P2_G0_R2 - FS_P2_G0_R2)^2) -> dif_p2_gen0_0_R2 
sum((F_P2_G0_R3 - FS_P2_G0_R3)^2) -> dif_p2_gen0_0_R3 
sum((F_P2_G0_R4 - FS_P2_G0_R4)^2) -> dif_p2_gen0_0_R4
sum((F_P2_G0_R5 - FS_P2_G0_R5)^2) -> dif_p2_gen0_0_R5 
sum((F_P2_G0_R6 - FS_P2_G0_R6)^2) -> dif_p2_gen0_0_R6 
sum((F_P2_G0_R7 - FS_P2_G0_R7)^2) -> dif_p2_gen0_0_R7
sum((F_P2_G0_R8 - FS_P2_G0_R8)^2) -> dif_p2_gen0_0_R8 
sum((F_P2_G0_R9 - FS_P2_G0_R9)^2) -> dif_p2_gen0_0_R9 
sum((F_P2_G0_R10 - FS_P2_G0_R10)^2) -> dif_p2_gen0_0_R10
sum((F_P2_G0_R11 - FS_P2_G0_R11)^2) -> dif_p2_gen0_0_R11 
sum((F_P2_G0_R12 - FS_P2_G0_R12)^2) -> dif_p2_gen0_0_R12 
sum((F_P2_G0_R13 - FS_P2_G0_R13)^2) -> dif_p2_gen0_0_R13
sum((F_P2_G0_R14 - FS_P2_G0_R14)^2) -> dif_p2_gen0_0_R14 
sum((F_P2_G0_R15 - FS_P2_G0_R15)^2) -> dif_p2_gen0_0_R15 
sum((F_P2_G0_R16 - FS_P2_G0_R16)^2) -> dif_p2_gen0_0_R16
sum((F_P2_G0_R17 - FS_P2_G0_R17)^2) -> dif_p2_gen0_0_R17 
sum((F_P2_G0_R18 - FS_P2_G0_R18)^2) -> dif_p2_gen0_0_R18 
sum((F_P2_G0_R19 - FS_P2_G0_R19)^2) -> dif_p2_gen0_0_R19
sum((F_P2_G0_R20 - FS_P2_G0_R20)^2) -> dif_p2_gen0_0_R20 
sum((F_P2_G0_R21 - FS_P2_G0_R21)^2) -> dif_p2_gen0_0_R21 
sum((F_P2_G0_R22 - FS_P2_G0_R22)^2) -> dif_p2_gen0_0_R22 
sum((F_P2_G0_R23 - FS_P2_G0_R23)^2) -> dif_p2_gen0_0_R23
sum((F_P2_G0_R24 - FS_P2_G0_R24)^2) -> dif_p2_gen0_0_R24 
sum((F_P2_G0_R25 - FS_P2_G0_R25)^2) -> dif_p2_gen0_0_R25 
sum((F_P2_G0_R26 - FS_P2_G0_R26)^2) -> dif_p2_gen0_0_R26
sum((F_P2_G0_R27 - FS_P2_G0_R27)^2) -> dif_p2_gen0_0_R27 
sum((F_P2_G0_R28 - FS_P2_G0_R28)^2) -> dif_p2_gen0_0_R28 
sum((F_P2_G0_R29 - FS_P2_G0_R29)^2) -> dif_p2_gen0_0_R29
sum((F_P2_G0_R30 - FS_P2_G0_R30)^2) -> dif_p2_gen0_0_R30 
sum((F_P2_G0_R31 - FS_P2_G0_R31)^2) -> dif_p2_gen0_0_R31 
sum((F_P2_G0_R32 - FS_P2_G0_R32)^2) -> dif_p2_gen0_0_R32 
sum((F_P2_G0_R33 - FS_P2_G0_R33)^2) -> dif_p2_gen0_0_R33
sum((F_P2_G0_R34 - FS_P2_G0_R34)^2) -> dif_p2_gen0_0_R34 
sum((F_P2_G0_R35 - FS_P2_G0_R35)^2) -> dif_p2_gen0_0_R35 
sum((F_P2_G0_R36 - FS_P2_G0_R36)^2) -> dif_p2_gen0_0_R36
sum((F_P2_G0_R37 - FS_P2_G0_R37)^2) -> dif_p2_gen0_0_R37 
sum((F_P2_G0_R38 - FS_P2_G0_R38)^2) -> dif_p2_gen0_0_R38 
sum((F_P2_G0_R39 - FS_P2_G0_R39)^2) -> dif_p2_gen0_0_R39
sum((F_P2_G0_R40 - FS_P2_G0_R40)^2) -> dif_p2_gen0_0_R40 
sum((F_P2_G0_R41 - FS_P2_G0_R41)^2) -> dif_p2_gen0_0_R41 
sum((F_P2_G0_R42 - FS_P2_G0_R42)^2) -> dif_p2_gen0_0_R42 
sum((F_P2_G0_R43 - FS_P2_G0_R43)^2) -> dif_p2_gen0_0_R43
sum((F_P2_G0_R44 - FS_P2_G0_R44)^2) -> dif_p2_gen0_0_R44 
sum((F_P2_G0_R45 - FS_P2_G0_R45)^2) -> dif_p2_gen0_0_R45 
sum((F_P2_G0_R46 - FS_P2_G0_R46)^2) -> dif_p2_gen0_0_R46
sum((F_P2_G0_R47 - FS_P2_G0_R47)^2) -> dif_p2_gen0_0_R47 
sum((F_P2_G0_R48 - FS_P2_G0_R48)^2) -> dif_p2_gen0_0_R48 
sum((F_P2_G0_R49 - FS_P2_G0_R49)^2) -> dif_p2_gen0_0_R49
sum((F_P2_G0_R50 - FS_P2_G0_R50)^2) -> dif_p2_gen0_0_R50 
sum((F_P2_G0_R51 - FS_P2_G0_R51)^2) -> dif_p2_gen0_0_R51 
sum((F_P2_G0_R52 - FS_P2_G0_R52)^2) -> dif_p2_gen0_0_R52 
sum((F_P2_G0_R53 - FS_P2_G0_R53)^2) -> dif_p2_gen0_0_R53
sum((F_P2_G0_R54 - FS_P2_G0_R54)^2) -> dif_p2_gen0_0_R54 
sum((F_P2_G0_R55 - FS_P2_G0_R55)^2) -> dif_p2_gen0_0_R55 
sum((F_P2_G0_R56 - FS_P2_G0_R56)^2) -> dif_p2_gen0_0_R56
sum((F_P2_G0_R57 - FS_P2_G0_R57)^2) -> dif_p2_gen0_0_R57 
sum((F_P2_G0_R58 - FS_P2_G0_R58)^2) -> dif_p2_gen0_0_R58 
sum((F_P2_G0_R59 - FS_P2_G0_R59)^2) -> dif_p2_gen0_0_R59
sum((F_P2_G0_R60 - FS_P2_G0_R60)^2) -> dif_p2_gen0_0_R60 
sum((F_P2_G0_R61 - FS_P2_G0_R61)^2) -> dif_p2_gen0_0_R61 
sum((F_P2_G0_R62 - FS_P2_G0_R62)^2) -> dif_p2_gen0_0_R62 
sum((F_P2_G0_R63 - FS_P2_G0_R63)^2) -> dif_p2_gen0_0_R63
sum((F_P2_G0_R64 - FS_P2_G0_R64)^2) -> dif_p2_gen0_0_R64 
sum((F_P2_G0_R65 - FS_P2_G0_R65)^2) -> dif_p2_gen0_0_R65 
sum((F_P2_G0_R66 - FS_P2_G0_R66)^2) -> dif_p2_gen0_0_R66
sum((F_P2_G0_R67 - FS_P2_G0_R67)^2) -> dif_p2_gen0_0_R67 
sum((F_P2_G0_R68 - FS_P2_G0_R68)^2) -> dif_p2_gen0_0_R68 
sum((F_P2_G0_R69 - FS_P2_G0_R69)^2) -> dif_p2_gen0_0_R69
sum((F_P2_G0_R70 - FS_P2_G0_R70)^2) -> dif_p2_gen0_0_R70 
sum((F_P2_G0_R71 - FS_P2_G0_R71)^2) -> dif_p2_gen0_0_R71 
sum((F_P2_G0_R72 - FS_P2_G0_R72)^2) -> dif_p2_gen0_0_R72 
sum((F_P2_G0_R73 - FS_P2_G0_R73)^2) -> dif_p2_gen0_0_R73
sum((F_P2_G0_R74 - FS_P2_G0_R74)^2) -> dif_p2_gen0_0_R74 
sum((F_P2_G0_R75 - FS_P2_G0_R75)^2) -> dif_p2_gen0_0_R75 
sum((F_P2_G0_R76 - FS_P2_G0_R76)^2) -> dif_p2_gen0_0_R76
sum((F_P2_G0_R77 - FS_P2_G0_R77)^2) -> dif_p2_gen0_0_R77 
sum((F_P2_G0_R78 - FS_P2_G0_R78)^2) -> dif_p2_gen0_0_R78 
sum((F_P2_G0_R79 - FS_P2_G0_R79)^2) -> dif_p2_gen0_0_R79
sum((F_P2_G0_R80 - FS_P2_G0_R80)^2) -> dif_p2_gen0_0_R80 
sum((F_P2_G0_R81 - FS_P2_G0_R81)^2) -> dif_p2_gen0_0_R81 
sum((F_P2_G0_R82 - FS_P2_G0_R82)^2) -> dif_p2_gen0_0_R82 
sum((F_P2_G0_R83 - FS_P2_G0_R83)^2) -> dif_p2_gen0_0_R83
sum((F_P2_G0_R84 - FS_P2_G0_R84)^2) -> dif_p2_gen0_0_R84 
sum((F_P2_G0_R85 - FS_P2_G0_R85)^2) -> dif_p2_gen0_0_R85 
sum((F_P2_G0_R86 - FS_P2_G0_R86)^2) -> dif_p2_gen0_0_R86
sum((F_P2_G0_R87 - FS_P2_G0_R87)^2) -> dif_p2_gen0_0_R87 
sum((F_P2_G0_R88 - FS_P2_G0_R88)^2) -> dif_p2_gen0_0_R88 
sum((F_P2_G0_R89 - FS_P2_G0_R89)^2) -> dif_p2_gen0_0_R89
sum((F_P2_G0_R90 - FS_P2_G0_R90)^2) -> dif_p2_gen0_0_R90 
sum((F_P2_G0_R91 - FS_P2_G0_R91)^2) -> dif_p2_gen0_0_R91 
sum((F_P2_G0_R92 - FS_P2_G0_R92)^2) -> dif_p2_gen0_0_R92 
sum((F_P2_G0_R93 - FS_P2_G0_R93)^2) -> dif_p2_gen0_0_R93
sum((F_P2_G0_R94 - FS_P2_G0_R94)^2) -> dif_p2_gen0_0_R94 
sum((F_P2_G0_R95 - FS_P2_G0_R95)^2) -> dif_p2_gen0_0_R95 
sum((F_P2_G0_R96 - FS_P2_G0_R96)^2) -> dif_p2_gen0_0_R96
sum((F_P2_G0_R97 - FS_P2_G0_R97)^2) -> dif_p2_gen0_0_R97 
sum((F_P2_G0_R98 - FS_P2_G0_R98)^2) -> dif_p2_gen0_0_R98 
sum((F_P2_G0_R99 - FS_P2_G0_R99)^2) -> dif_p2_gen0_0_R99
sum((F_P2_G0_R100 - FS_P2_G0_R100)^2) -> dif_p2_gen0_0_R100 

dif_p2_gen0_0_R1 <- cbind(rep =1, sum = dif_p2_gen0_0_R1)
dif_p2_gen0_0_R2 <- cbind(rep =2, sum = dif_p2_gen0_0_R2)
dif_p2_gen0_0_R3 <- cbind(rep =3, sum = dif_p2_gen0_0_R3)
dif_p2_gen0_0_R4 <- cbind(rep =4, sum = dif_p2_gen0_0_R4)
dif_p2_gen0_0_R5 <- cbind(rep =5, sum = dif_p2_gen0_0_R5)
dif_p2_gen0_0_R6 <- cbind(rep =6, sum = dif_p2_gen0_0_R6)
dif_p2_gen0_0_R7 <- cbind(rep =7, sum = dif_p2_gen0_0_R7)
dif_p2_gen0_0_R8 <- cbind(rep =8, sum = dif_p2_gen0_0_R8)
dif_p2_gen0_0_R9 <- cbind(rep =9, sum = dif_p2_gen0_0_R9)
dif_p2_gen0_0_R10 <- cbind(rep =10, sum = dif_p2_gen0_0_R10)
dif_p2_gen0_0_R11 <- cbind(rep =11, sum = dif_p2_gen0_0_R11)
dif_p2_gen0_0_R12 <- cbind(rep =12, sum = dif_p2_gen0_0_R12)
dif_p2_gen0_0_R13 <- cbind(rep =13, sum = dif_p2_gen0_0_R13)
dif_p2_gen0_0_R14 <- cbind(rep =14, sum = dif_p2_gen0_0_R14)
dif_p2_gen0_0_R15 <- cbind(rep =15, sum = dif_p2_gen0_0_R15)
dif_p2_gen0_0_R16 <- cbind(rep =16, sum = dif_p2_gen0_0_R16)
dif_p2_gen0_0_R17 <- cbind(rep =17, sum = dif_p2_gen0_0_R17)
dif_p2_gen0_0_R18 <- cbind(rep =18, sum = dif_p2_gen0_0_R18)
dif_p2_gen0_0_R19 <- cbind(rep =19, sum = dif_p2_gen0_0_R19)
dif_p2_gen0_0_R20 <- cbind(rep =20, sum = dif_p2_gen0_0_R20)
dif_p2_gen0_0_R21 <- cbind(rep =21, sum = dif_p2_gen0_0_R21)
dif_p2_gen0_0_R22 <- cbind(rep =22, sum = dif_p2_gen0_0_R22)
dif_p2_gen0_0_R23 <- cbind(rep =23, sum = dif_p2_gen0_0_R23)
dif_p2_gen0_0_R24 <- cbind(rep =24, sum = dif_p2_gen0_0_R24)
dif_p2_gen0_0_R25 <- cbind(rep =25, sum = dif_p2_gen0_0_R25)
dif_p2_gen0_0_R26 <- cbind(rep =26, sum = dif_p2_gen0_0_R26)
dif_p2_gen0_0_R27 <- cbind(rep =27, sum = dif_p2_gen0_0_R27)
dif_p2_gen0_0_R28 <- cbind(rep =28, sum = dif_p2_gen0_0_R28)
dif_p2_gen0_0_R29 <- cbind(rep =29, sum = dif_p2_gen0_0_R29)
dif_p2_gen0_0_R30 <- cbind(rep =30, sum = dif_p2_gen0_0_R30)
dif_p2_gen0_0_R31 <- cbind(rep =31, sum = dif_p2_gen0_0_R31)
dif_p2_gen0_0_R32 <- cbind(rep =32, sum = dif_p2_gen0_0_R32)
dif_p2_gen0_0_R33 <- cbind(rep =33, sum = dif_p2_gen0_0_R33)
dif_p2_gen0_0_R34 <- cbind(rep =34, sum = dif_p2_gen0_0_R34)
dif_p2_gen0_0_R35 <- cbind(rep =35, sum = dif_p2_gen0_0_R35)
dif_p2_gen0_0_R36 <- cbind(rep =36, sum = dif_p2_gen0_0_R36)
dif_p2_gen0_0_R37 <- cbind(rep =37, sum = dif_p2_gen0_0_R37)
dif_p2_gen0_0_R38 <- cbind(rep =38, sum = dif_p2_gen0_0_R38)
dif_p2_gen0_0_R39 <- cbind(rep =39, sum = dif_p2_gen0_0_R39)
dif_p2_gen0_0_R40 <- cbind(rep =40, sum = dif_p2_gen0_0_R40)
dif_p2_gen0_0_R41 <- cbind(rep =41, sum = dif_p2_gen0_0_R41)
dif_p2_gen0_0_R42 <- cbind(rep =42, sum = dif_p2_gen0_0_R42)
dif_p2_gen0_0_R43 <- cbind(rep =43, sum = dif_p2_gen0_0_R43)
dif_p2_gen0_0_R44 <- cbind(rep =44, sum = dif_p2_gen0_0_R44)
dif_p2_gen0_0_R45 <- cbind(rep =45, sum = dif_p2_gen0_0_R45)
dif_p2_gen0_0_R46 <- cbind(rep =46, sum = dif_p2_gen0_0_R46)
dif_p2_gen0_0_R47 <- cbind(rep =47, sum = dif_p2_gen0_0_R47)
dif_p2_gen0_0_R48 <- cbind(rep =48, sum = dif_p2_gen0_0_R48)
dif_p2_gen0_0_R49 <- cbind(rep =49, sum = dif_p2_gen0_0_R49)
dif_p2_gen0_0_R50 <- cbind(rep =50, sum = dif_p2_gen0_0_R50)
dif_p2_gen0_0_R51 <- cbind(rep =51, sum = dif_p2_gen0_0_R51)
dif_p2_gen0_0_R52 <- cbind(rep =52, sum = dif_p2_gen0_0_R52)
dif_p2_gen0_0_R53 <- cbind(rep =53, sum = dif_p2_gen0_0_R53)
dif_p2_gen0_0_R54 <- cbind(rep =54, sum = dif_p2_gen0_0_R54)
dif_p2_gen0_0_R55 <- cbind(rep =55, sum = dif_p2_gen0_0_R55)
dif_p2_gen0_0_R56 <- cbind(rep =56, sum = dif_p2_gen0_0_R56)
dif_p2_gen0_0_R57 <- cbind(rep =57, sum = dif_p2_gen0_0_R57)
dif_p2_gen0_0_R58 <- cbind(rep =58, sum = dif_p2_gen0_0_R58)
dif_p2_gen0_0_R59 <- cbind(rep =59, sum = dif_p2_gen0_0_R59)
dif_p2_gen0_0_R60 <- cbind(rep =60, sum = dif_p2_gen0_0_R60)
dif_p2_gen0_0_R61 <- cbind(rep =61, sum = dif_p2_gen0_0_R61)
dif_p2_gen0_0_R62 <- cbind(rep =62, sum = dif_p2_gen0_0_R62)
dif_p2_gen0_0_R63 <- cbind(rep =63, sum = dif_p2_gen0_0_R63)
dif_p2_gen0_0_R64 <- cbind(rep =64, sum = dif_p2_gen0_0_R64)
dif_p2_gen0_0_R65 <- cbind(rep =65, sum = dif_p2_gen0_0_R65)
dif_p2_gen0_0_R66 <- cbind(rep =66, sum = dif_p2_gen0_0_R66)
dif_p2_gen0_0_R67 <- cbind(rep =67, sum = dif_p2_gen0_0_R67)
dif_p2_gen0_0_R68 <- cbind(rep =68, sum = dif_p2_gen0_0_R68)
dif_p2_gen0_0_R69 <- cbind(rep =69, sum = dif_p2_gen0_0_R69)
dif_p2_gen0_0_R70 <- cbind(rep =70, sum = dif_p2_gen0_0_R70)
dif_p2_gen0_0_R71 <- cbind(rep =71, sum = dif_p2_gen0_0_R71)
dif_p2_gen0_0_R72 <- cbind(rep =72, sum = dif_p2_gen0_0_R72)
dif_p2_gen0_0_R73 <- cbind(rep =73, sum = dif_p2_gen0_0_R73)
dif_p2_gen0_0_R74 <- cbind(rep =74, sum = dif_p2_gen0_0_R74)
dif_p2_gen0_0_R75 <- cbind(rep =75, sum = dif_p2_gen0_0_R75)
dif_p2_gen0_0_R76 <- cbind(rep =76, sum = dif_p2_gen0_0_R76)
dif_p2_gen0_0_R77 <- cbind(rep =77, sum = dif_p2_gen0_0_R77)
dif_p2_gen0_0_R78 <- cbind(rep =78, sum = dif_p2_gen0_0_R78)
dif_p2_gen0_0_R79 <- cbind(rep =79, sum = dif_p2_gen0_0_R79)
dif_p2_gen0_0_R80 <- cbind(rep =80, sum = dif_p2_gen0_0_R80)
dif_p2_gen0_0_R81 <- cbind(rep =81, sum = dif_p2_gen0_0_R81)
dif_p2_gen0_0_R82 <- cbind(rep =82, sum = dif_p2_gen0_0_R82)
dif_p2_gen0_0_R83 <- cbind(rep =83, sum = dif_p2_gen0_0_R83)
dif_p2_gen0_0_R84 <- cbind(rep =84, sum = dif_p2_gen0_0_R84)
dif_p2_gen0_0_R85 <- cbind(rep =85, sum = dif_p2_gen0_0_R85)
dif_p2_gen0_0_R86 <- cbind(rep =86, sum = dif_p2_gen0_0_R86)
dif_p2_gen0_0_R87 <- cbind(rep =87, sum = dif_p2_gen0_0_R87)
dif_p2_gen0_0_R88 <- cbind(rep =88, sum = dif_p2_gen0_0_R88)
dif_p2_gen0_0_R89 <- cbind(rep =89, sum = dif_p2_gen0_0_R89)
dif_p2_gen0_0_R90 <- cbind(rep =90, sum = dif_p2_gen0_0_R90)
dif_p2_gen0_0_R91 <- cbind(rep =91, sum = dif_p2_gen0_0_R91)
dif_p2_gen0_0_R92 <- cbind(rep =92, sum = dif_p2_gen0_0_R92)
dif_p2_gen0_0_R93 <- cbind(rep =93, sum = dif_p2_gen0_0_R93)
dif_p2_gen0_0_R94 <- cbind(rep =94, sum = dif_p2_gen0_0_R94)
dif_p2_gen0_0_R95 <- cbind(rep =95, sum = dif_p2_gen0_0_R95)
dif_p2_gen0_0_R96 <- cbind(rep =96, sum = dif_p2_gen0_0_R96)
dif_p2_gen0_0_R97 <- cbind(rep =97, sum = dif_p2_gen0_0_R97)
dif_p2_gen0_0_R98 <- cbind(rep =98, sum = dif_p2_gen0_0_R98)
dif_p2_gen0_0_R99 <- cbind(rep =99, sum = dif_p2_gen0_0_R99)
dif_p2_gen0_0_R100 <- cbind(rep =100, sum = dif_p2_gen0_0_R100)



dif_p2_gen0_0 <- rbind(dif_p2_gen0_0_R1, dif_p2_gen0_0_R2, dif_p2_gen0_0_R3, dif_p2_gen0_0_R4, dif_p2_gen0_0_R5, dif_p2_gen0_0_R6,
                       dif_p2_gen0_0_R7, dif_p2_gen0_0_R8, dif_p2_gen0_0_R9, dif_p2_gen0_0_R10, dif_p2_gen0_0_R11, dif_p2_gen0_0_R12,
                       dif_p2_gen0_0_R13, dif_p2_gen0_0_R14, dif_p2_gen0_0_R15, dif_p2_gen0_0_R16, dif_p2_gen0_0_R17, dif_p2_gen0_0_R18,
                       dif_p2_gen0_0_R19, dif_p2_gen0_0_R20, dif_p2_gen0_0_R21, dif_p2_gen0_0_R22, dif_p2_gen0_0_R23, dif_p2_gen0_0_R24,
                       dif_p2_gen0_0_R25, dif_p2_gen0_0_R26, dif_p2_gen0_0_R27, dif_p2_gen0_0_R28, dif_p2_gen0_0_R29, dif_p2_gen0_0_R30,
                       dif_p2_gen0_0_R31, dif_p2_gen0_0_R32, dif_p2_gen0_0_R33, dif_p2_gen0_0_R34, dif_p2_gen0_0_R35, dif_p2_gen0_0_R36,
                       dif_p2_gen0_0_R37, dif_p2_gen0_0_R38, dif_p2_gen0_0_R39, dif_p2_gen0_0_R40, dif_p2_gen0_0_R41, dif_p2_gen0_0_R42,
                       dif_p2_gen0_0_R43, dif_p2_gen0_0_R44, dif_p2_gen0_0_R45, dif_p2_gen0_0_R46, dif_p2_gen0_0_R47,
                       dif_p2_gen0_0_R48, dif_p2_gen0_0_R49, dif_p2_gen0_0_R50, dif_p2_gen0_0_R51, dif_p2_gen0_0_R52, dif_p2_gen0_0_R53,
                       dif_p2_gen0_0_R54, dif_p2_gen0_0_R55, dif_p2_gen0_0_R56, dif_p2_gen0_0_R57, dif_p2_gen0_0_R58, dif_p2_gen0_0_R59,
                       dif_p2_gen0_0_R60, dif_p2_gen0_0_R61, dif_p2_gen0_0_R62, dif_p2_gen0_0_R63, dif_p2_gen0_0_R64, dif_p2_gen0_0_R65,
                       dif_p2_gen0_0_R66, dif_p2_gen0_0_R67, dif_p2_gen0_0_R68, dif_p2_gen0_0_R69, dif_p2_gen0_0_R70, dif_p2_gen0_0_R71,
                       dif_p2_gen0_0_R72, dif_p2_gen0_0_R73, dif_p2_gen0_0_R74, dif_p2_gen0_0_R75, dif_p2_gen0_0_R76, dif_p2_gen0_0_R77,
                       dif_p2_gen0_0_R78, dif_p2_gen0_0_R79, dif_p2_gen0_0_R80, dif_p2_gen0_0_R81, dif_p2_gen0_0_R82, dif_p2_gen0_0_R83,
                       dif_p2_gen0_0_R84, dif_p2_gen0_0_R85, dif_p2_gen0_0_R86, dif_p2_gen0_0_R87, dif_p2_gen0_0_R88, dif_p2_gen0_0_R89,
                       dif_p2_gen0_0_R90, dif_p2_gen0_0_R91, dif_p2_gen0_0_R92, dif_p2_gen0_0_R93, dif_p2_gen0_0_R94, dif_p2_gen0_0_R95,
                       dif_p2_gen0_0_R96, dif_p2_gen0_0_R97, dif_p2_gen0_0_R98, dif_p2_gen0_0_R99, dif_p2_gen0_0_R100) 


dif_p2_gen0_0 <- cbind(dif_gen = 0, pop=2, dif_p2_gen0_0)

# sum of squared differences between generation 0 and 3 pop2 ----
sum((F_P2_G0_R1 - F_P2_G3_R1)^2) -> dif_p2_gen0_3_R1
sum((F_P2_G0_R2 - F_P2_G3_R2)^2) -> dif_p2_gen0_3_R2 
sum((F_P2_G0_R3 - F_P2_G3_R3)^2) -> dif_p2_gen0_3_R3 
sum((F_P2_G0_R4 - F_P2_G3_R4)^2) -> dif_p2_gen0_3_R4
sum((F_P2_G0_R5 - F_P2_G3_R5)^2) -> dif_p2_gen0_3_R5 
sum((F_P2_G0_R6 - F_P2_G3_R6)^2) -> dif_p2_gen0_3_R6 
sum((F_P2_G0_R7 - F_P2_G3_R7)^2) -> dif_p2_gen0_3_R7
sum((F_P2_G0_R8 - F_P2_G3_R8)^2) -> dif_p2_gen0_3_R8 
sum((F_P2_G0_R9 - F_P2_G3_R9)^2) -> dif_p2_gen0_3_R9 
sum((F_P2_G0_R10 - F_P2_G3_R10)^2) -> dif_p2_gen0_3_R10
sum((F_P2_G0_R11 - F_P2_G3_R11)^2) -> dif_p2_gen0_3_R11 
sum((F_P2_G0_R12 - F_P2_G3_R12)^2) -> dif_p2_gen0_3_R12 
sum((F_P2_G0_R13 - F_P2_G3_R13)^2) -> dif_p2_gen0_3_R13
sum((F_P2_G0_R14 - F_P2_G3_R14)^2) -> dif_p2_gen0_3_R14 
sum((F_P2_G0_R15 - F_P2_G3_R15)^2) -> dif_p2_gen0_3_R15 
sum((F_P2_G0_R16 - F_P2_G3_R16)^2) -> dif_p2_gen0_3_R16
sum((F_P2_G0_R17 - F_P2_G3_R17)^2) -> dif_p2_gen0_3_R17 
sum((F_P2_G0_R18 - F_P2_G3_R18)^2) -> dif_p2_gen0_3_R18 
sum((F_P2_G0_R19 - F_P2_G3_R19)^2) -> dif_p2_gen0_3_R19
sum((F_P2_G0_R20 - F_P2_G3_R20)^2) -> dif_p2_gen0_3_R20 
sum((F_P2_G0_R21 - F_P2_G3_R21)^2) -> dif_p2_gen0_3_R21 
sum((F_P2_G0_R22 - F_P2_G3_R22)^2) -> dif_p2_gen0_3_R22 
sum((F_P2_G0_R23 - F_P2_G3_R23)^2) -> dif_p2_gen0_3_R23
sum((F_P2_G0_R24 - F_P2_G3_R24)^2) -> dif_p2_gen0_3_R24 
sum((F_P2_G0_R25 - F_P2_G3_R25)^2) -> dif_p2_gen0_3_R25 
sum((F_P2_G0_R26 - F_P2_G3_R26)^2) -> dif_p2_gen0_3_R26
sum((F_P2_G0_R27 - F_P2_G3_R27)^2) -> dif_p2_gen0_3_R27 
sum((F_P2_G0_R28 - F_P2_G3_R28)^2) -> dif_p2_gen0_3_R28 
sum((F_P2_G0_R29 - F_P2_G3_R29)^2) -> dif_p2_gen0_3_R29
sum((F_P2_G0_R30 - F_P2_G3_R30)^2) -> dif_p2_gen0_3_R30 
sum((F_P2_G0_R31 - F_P2_G3_R31)^2) -> dif_p2_gen0_3_R31 
sum((F_P2_G0_R32 - F_P2_G3_R32)^2) -> dif_p2_gen0_3_R32 
sum((F_P2_G0_R33 - F_P2_G3_R33)^2) -> dif_p2_gen0_3_R33
sum((F_P2_G0_R34 - F_P2_G3_R34)^2) -> dif_p2_gen0_3_R34 
sum((F_P2_G0_R35 - F_P2_G3_R35)^2) -> dif_p2_gen0_3_R35 
sum((F_P2_G0_R36 - F_P2_G3_R36)^2) -> dif_p2_gen0_3_R36
sum((F_P2_G0_R37 - F_P2_G3_R37)^2) -> dif_p2_gen0_3_R37 
sum((F_P2_G0_R38 - F_P2_G3_R38)^2) -> dif_p2_gen0_3_R38 
sum((F_P2_G0_R39 - F_P2_G3_R39)^2) -> dif_p2_gen0_3_R39
sum((F_P2_G0_R40 - F_P2_G3_R40)^2) -> dif_p2_gen0_3_R40 
sum((F_P2_G0_R41 - F_P2_G3_R41)^2) -> dif_p2_gen0_3_R41 
sum((F_P2_G0_R42 - F_P2_G3_R42)^2) -> dif_p2_gen0_3_R42 
sum((F_P2_G0_R43 - F_P2_G3_R43)^2) -> dif_p2_gen0_3_R43
sum((F_P2_G0_R44 - F_P2_G3_R44)^2) -> dif_p2_gen0_3_R44 
sum((F_P2_G0_R45 - F_P2_G3_R45)^2) -> dif_p2_gen0_3_R45 
sum((F_P2_G0_R46 - F_P2_G3_R46)^2) -> dif_p2_gen0_3_R46
sum((F_P2_G0_R47 - F_P2_G3_R47)^2) -> dif_p2_gen0_3_R47 
sum((F_P2_G0_R48 - F_P2_G3_R48)^2) -> dif_p2_gen0_3_R48 
sum((F_P2_G0_R49 - F_P2_G3_R49)^2) -> dif_p2_gen0_3_R49
sum((F_P2_G0_R50 - F_P2_G3_R50)^2) -> dif_p2_gen0_3_R50 
sum((F_P2_G0_R51 - F_P2_G3_R51)^2) -> dif_p2_gen0_3_R51 
sum((F_P2_G0_R52 - F_P2_G3_R52)^2) -> dif_p2_gen0_3_R52 
sum((F_P2_G0_R53 - F_P2_G3_R53)^2) -> dif_p2_gen0_3_R53
sum((F_P2_G0_R54 - F_P2_G3_R54)^2) -> dif_p2_gen0_3_R54 
sum((F_P2_G0_R55 - F_P2_G3_R55)^2) -> dif_p2_gen0_3_R55 
sum((F_P2_G0_R56 - F_P2_G3_R56)^2) -> dif_p2_gen0_3_R56
sum((F_P2_G0_R57 - F_P2_G3_R57)^2) -> dif_p2_gen0_3_R57 
sum((F_P2_G0_R58 - F_P2_G3_R58)^2) -> dif_p2_gen0_3_R58 
sum((F_P2_G0_R59 - F_P2_G3_R59)^2) -> dif_p2_gen0_3_R59
sum((F_P2_G0_R60 - F_P2_G3_R60)^2) -> dif_p2_gen0_3_R60 
sum((F_P2_G0_R61 - F_P2_G3_R61)^2) -> dif_p2_gen0_3_R61 
sum((F_P2_G0_R62 - F_P2_G3_R62)^2) -> dif_p2_gen0_3_R62 
sum((F_P2_G0_R63 - F_P2_G3_R63)^2) -> dif_p2_gen0_3_R63
sum((F_P2_G0_R64 - F_P2_G3_R64)^2) -> dif_p2_gen0_3_R64 
sum((F_P2_G0_R65 - F_P2_G3_R65)^2) -> dif_p2_gen0_3_R65 
sum((F_P2_G0_R66 - F_P2_G3_R66)^2) -> dif_p2_gen0_3_R66
sum((F_P2_G0_R67 - F_P2_G3_R67)^2) -> dif_p2_gen0_3_R67 
sum((F_P2_G0_R68 - F_P2_G3_R68)^2) -> dif_p2_gen0_3_R68 
sum((F_P2_G0_R69 - F_P2_G3_R69)^2) -> dif_p2_gen0_3_R69
sum((F_P2_G0_R70 - F_P2_G3_R70)^2) -> dif_p2_gen0_3_R70 
sum((F_P2_G0_R71 - F_P2_G3_R71)^2) -> dif_p2_gen0_3_R71 
sum((F_P2_G0_R72 - F_P2_G3_R72)^2) -> dif_p2_gen0_3_R72 
sum((F_P2_G0_R73 - F_P2_G3_R73)^2) -> dif_p2_gen0_3_R73
sum((F_P2_G0_R74 - F_P2_G3_R74)^2) -> dif_p2_gen0_3_R74 
sum((F_P2_G0_R75 - F_P2_G3_R75)^2) -> dif_p2_gen0_3_R75 
sum((F_P2_G0_R76 - F_P2_G3_R76)^2) -> dif_p2_gen0_3_R76
sum((F_P2_G0_R77 - F_P2_G3_R77)^2) -> dif_p2_gen0_3_R77 
sum((F_P2_G0_R78 - F_P2_G3_R78)^2) -> dif_p2_gen0_3_R78 
sum((F_P2_G0_R79 - F_P2_G3_R79)^2) -> dif_p2_gen0_3_R79
sum((F_P2_G0_R80 - F_P2_G3_R80)^2) -> dif_p2_gen0_3_R80 
sum((F_P2_G0_R81 - F_P2_G3_R81)^2) -> dif_p2_gen0_3_R81 
sum((F_P2_G0_R82 - F_P2_G3_R82)^2) -> dif_p2_gen0_3_R82 
sum((F_P2_G0_R83 - F_P2_G3_R83)^2) -> dif_p2_gen0_3_R83
sum((F_P2_G0_R84 - F_P2_G3_R84)^2) -> dif_p2_gen0_3_R84 
sum((F_P2_G0_R85 - F_P2_G3_R85)^2) -> dif_p2_gen0_3_R85 
sum((F_P2_G0_R86 - F_P2_G3_R86)^2) -> dif_p2_gen0_3_R86
sum((F_P2_G0_R87 - F_P2_G3_R87)^2) -> dif_p2_gen0_3_R87 
sum((F_P2_G0_R88 - F_P2_G3_R88)^2) -> dif_p2_gen0_3_R88 
sum((F_P2_G0_R89 - F_P2_G3_R89)^2) -> dif_p2_gen0_3_R89
sum((F_P2_G0_R90 - F_P2_G3_R90)^2) -> dif_p2_gen0_3_R90 
sum((F_P2_G0_R91 - F_P2_G3_R91)^2) -> dif_p2_gen0_3_R91 
sum((F_P2_G0_R92 - F_P2_G3_R92)^2) -> dif_p2_gen0_3_R92 
sum((F_P2_G0_R93 - F_P2_G3_R93)^2) -> dif_p2_gen0_3_R93
sum((F_P2_G0_R94 - F_P2_G3_R94)^2) -> dif_p2_gen0_3_R94 
sum((F_P2_G0_R95 - F_P2_G3_R95)^2) -> dif_p2_gen0_3_R95 
sum((F_P2_G0_R96 - F_P2_G3_R96)^2) -> dif_p2_gen0_3_R96
sum((F_P2_G0_R97 - F_P2_G3_R97)^2) -> dif_p2_gen0_3_R97 
sum((F_P2_G0_R98 - F_P2_G3_R98)^2) -> dif_p2_gen0_3_R98 
sum((F_P2_G0_R99 - F_P2_G3_R99)^2) -> dif_p2_gen0_3_R99
sum((F_P2_G0_R100 - F_P2_G3_R100)^2) -> dif_p2_gen0_3_R100 

dif_p2_gen0_3_R1 <- cbind(rep =1, sum = dif_p2_gen0_3_R1)
dif_p2_gen0_3_R2 <- cbind(rep =2, sum = dif_p2_gen0_3_R2)
dif_p2_gen0_3_R3 <- cbind(rep =3, sum = dif_p2_gen0_3_R3)
dif_p2_gen0_3_R4 <- cbind(rep =4, sum = dif_p2_gen0_3_R4)
dif_p2_gen0_3_R5 <- cbind(rep =5, sum = dif_p2_gen0_3_R5)
dif_p2_gen0_3_R6 <- cbind(rep =6, sum = dif_p2_gen0_3_R6)
dif_p2_gen0_3_R7 <- cbind(rep =7, sum = dif_p2_gen0_3_R7)
dif_p2_gen0_3_R8 <- cbind(rep =8, sum = dif_p2_gen0_3_R8)
dif_p2_gen0_3_R9 <- cbind(rep =9, sum = dif_p2_gen0_3_R9)
dif_p2_gen0_3_R10 <- cbind(rep =10, sum = dif_p2_gen0_3_R10)
dif_p2_gen0_3_R11 <- cbind(rep =11, sum = dif_p2_gen0_3_R11)
dif_p2_gen0_3_R12 <- cbind(rep =12, sum = dif_p2_gen0_3_R12)
dif_p2_gen0_3_R13 <- cbind(rep =13, sum = dif_p2_gen0_3_R13)
dif_p2_gen0_3_R14 <- cbind(rep =14, sum = dif_p2_gen0_3_R14)
dif_p2_gen0_3_R15 <- cbind(rep =15, sum = dif_p2_gen0_3_R15)
dif_p2_gen0_3_R16 <- cbind(rep =16, sum = dif_p2_gen0_3_R16)
dif_p2_gen0_3_R17 <- cbind(rep =17, sum = dif_p2_gen0_3_R17)
dif_p2_gen0_3_R18 <- cbind(rep =18, sum = dif_p2_gen0_3_R18)
dif_p2_gen0_3_R19 <- cbind(rep =19, sum = dif_p2_gen0_3_R19)
dif_p2_gen0_3_R20 <- cbind(rep =20, sum = dif_p2_gen0_3_R20)
dif_p2_gen0_3_R21 <- cbind(rep =21, sum = dif_p2_gen0_3_R21)
dif_p2_gen0_3_R22 <- cbind(rep =22, sum = dif_p2_gen0_3_R22)
dif_p2_gen0_3_R23 <- cbind(rep =23, sum = dif_p2_gen0_3_R23)
dif_p2_gen0_3_R24 <- cbind(rep =24, sum = dif_p2_gen0_3_R24)
dif_p2_gen0_3_R25 <- cbind(rep =25, sum = dif_p2_gen0_3_R25)
dif_p2_gen0_3_R26 <- cbind(rep =26, sum = dif_p2_gen0_3_R26)
dif_p2_gen0_3_R27 <- cbind(rep =27, sum = dif_p2_gen0_3_R27)
dif_p2_gen0_3_R28 <- cbind(rep =28, sum = dif_p2_gen0_3_R28)
dif_p2_gen0_3_R29 <- cbind(rep =29, sum = dif_p2_gen0_3_R29)
dif_p2_gen0_3_R30 <- cbind(rep =30, sum = dif_p2_gen0_3_R30)
dif_p2_gen0_3_R31 <- cbind(rep =31, sum = dif_p2_gen0_3_R31)
dif_p2_gen0_3_R32 <- cbind(rep =32, sum = dif_p2_gen0_3_R32)
dif_p2_gen0_3_R33 <- cbind(rep =33, sum = dif_p2_gen0_3_R33)
dif_p2_gen0_3_R34 <- cbind(rep =34, sum = dif_p2_gen0_3_R34)
dif_p2_gen0_3_R35 <- cbind(rep =35, sum = dif_p2_gen0_3_R35)
dif_p2_gen0_3_R36 <- cbind(rep =36, sum = dif_p2_gen0_3_R36)
dif_p2_gen0_3_R37 <- cbind(rep =37, sum = dif_p2_gen0_3_R37)
dif_p2_gen0_3_R38 <- cbind(rep =38, sum = dif_p2_gen0_3_R38)
dif_p2_gen0_3_R39 <- cbind(rep =39, sum = dif_p2_gen0_3_R39)
dif_p2_gen0_3_R40 <- cbind(rep =40, sum = dif_p2_gen0_3_R40)
dif_p2_gen0_3_R41 <- cbind(rep =41, sum = dif_p2_gen0_3_R41)
dif_p2_gen0_3_R42 <- cbind(rep =42, sum = dif_p2_gen0_3_R42)
dif_p2_gen0_3_R43 <- cbind(rep =43, sum = dif_p2_gen0_3_R43)
dif_p2_gen0_3_R44 <- cbind(rep =44, sum = dif_p2_gen0_3_R44)
dif_p2_gen0_3_R45 <- cbind(rep =45, sum = dif_p2_gen0_3_R45)
dif_p2_gen0_3_R46 <- cbind(rep =46, sum = dif_p2_gen0_3_R46)
dif_p2_gen0_3_R47 <- cbind(rep =47, sum = dif_p2_gen0_3_R47)
dif_p2_gen0_3_R48 <- cbind(rep =48, sum = dif_p2_gen0_3_R48)
dif_p2_gen0_3_R49 <- cbind(rep =49, sum = dif_p2_gen0_3_R49)
dif_p2_gen0_3_R50 <- cbind(rep =50, sum = dif_p2_gen0_3_R50)
dif_p2_gen0_3_R51 <- cbind(rep =51, sum = dif_p2_gen0_3_R51)
dif_p2_gen0_3_R52 <- cbind(rep =52, sum = dif_p2_gen0_3_R52)
dif_p2_gen0_3_R53 <- cbind(rep =53, sum = dif_p2_gen0_3_R53)
dif_p2_gen0_3_R54 <- cbind(rep =54, sum = dif_p2_gen0_3_R54)
dif_p2_gen0_3_R55 <- cbind(rep =55, sum = dif_p2_gen0_3_R55)
dif_p2_gen0_3_R56 <- cbind(rep =56, sum = dif_p2_gen0_3_R56)
dif_p2_gen0_3_R57 <- cbind(rep =57, sum = dif_p2_gen0_3_R57)
dif_p2_gen0_3_R58 <- cbind(rep =58, sum = dif_p2_gen0_3_R58)
dif_p2_gen0_3_R59 <- cbind(rep =59, sum = dif_p2_gen0_3_R59)
dif_p2_gen0_3_R60 <- cbind(rep =60, sum = dif_p2_gen0_3_R60)
dif_p2_gen0_3_R61 <- cbind(rep =61, sum = dif_p2_gen0_3_R61)
dif_p2_gen0_3_R62 <- cbind(rep =62, sum = dif_p2_gen0_3_R62)
dif_p2_gen0_3_R63 <- cbind(rep =63, sum = dif_p2_gen0_3_R63)
dif_p2_gen0_3_R64 <- cbind(rep =64, sum = dif_p2_gen0_3_R64)
dif_p2_gen0_3_R65 <- cbind(rep =65, sum = dif_p2_gen0_3_R65)
dif_p2_gen0_3_R66 <- cbind(rep =66, sum = dif_p2_gen0_3_R66)
dif_p2_gen0_3_R67 <- cbind(rep =67, sum = dif_p2_gen0_3_R67)
dif_p2_gen0_3_R68 <- cbind(rep =68, sum = dif_p2_gen0_3_R68)
dif_p2_gen0_3_R69 <- cbind(rep =69, sum = dif_p2_gen0_3_R69)
dif_p2_gen0_3_R70 <- cbind(rep =70, sum = dif_p2_gen0_3_R70)
dif_p2_gen0_3_R71 <- cbind(rep =71, sum = dif_p2_gen0_3_R71)
dif_p2_gen0_3_R72 <- cbind(rep =72, sum = dif_p2_gen0_3_R72)
dif_p2_gen0_3_R73 <- cbind(rep =73, sum = dif_p2_gen0_3_R73)
dif_p2_gen0_3_R74 <- cbind(rep =74, sum = dif_p2_gen0_3_R74)
dif_p2_gen0_3_R75 <- cbind(rep =75, sum = dif_p2_gen0_3_R75)
dif_p2_gen0_3_R76 <- cbind(rep =76, sum = dif_p2_gen0_3_R76)
dif_p2_gen0_3_R77 <- cbind(rep =77, sum = dif_p2_gen0_3_R77)
dif_p2_gen0_3_R78 <- cbind(rep =78, sum = dif_p2_gen0_3_R78)
dif_p2_gen0_3_R79 <- cbind(rep =79, sum = dif_p2_gen0_3_R79)
dif_p2_gen0_3_R80 <- cbind(rep =80, sum = dif_p2_gen0_3_R80)
dif_p2_gen0_3_R81 <- cbind(rep =81, sum = dif_p2_gen0_3_R81)
dif_p2_gen0_3_R82 <- cbind(rep =82, sum = dif_p2_gen0_3_R82)
dif_p2_gen0_3_R83 <- cbind(rep =83, sum = dif_p2_gen0_3_R83)
dif_p2_gen0_3_R84 <- cbind(rep =84, sum = dif_p2_gen0_3_R84)
dif_p2_gen0_3_R85 <- cbind(rep =85, sum = dif_p2_gen0_3_R85)
dif_p2_gen0_3_R86 <- cbind(rep =86, sum = dif_p2_gen0_3_R86)
dif_p2_gen0_3_R87 <- cbind(rep =87, sum = dif_p2_gen0_3_R87)
dif_p2_gen0_3_R88 <- cbind(rep =88, sum = dif_p2_gen0_3_R88)
dif_p2_gen0_3_R89 <- cbind(rep =89, sum = dif_p2_gen0_3_R89)
dif_p2_gen0_3_R90 <- cbind(rep =90, sum = dif_p2_gen0_3_R90)
dif_p2_gen0_3_R91 <- cbind(rep =91, sum = dif_p2_gen0_3_R91)
dif_p2_gen0_3_R92 <- cbind(rep =92, sum = dif_p2_gen0_3_R92)
dif_p2_gen0_3_R93 <- cbind(rep =93, sum = dif_p2_gen0_3_R93)
dif_p2_gen0_3_R94 <- cbind(rep =94, sum = dif_p2_gen0_3_R94)
dif_p2_gen0_3_R95 <- cbind(rep =95, sum = dif_p2_gen0_3_R95)
dif_p2_gen0_3_R96 <- cbind(rep =96, sum = dif_p2_gen0_3_R96)
dif_p2_gen0_3_R97 <- cbind(rep =97, sum = dif_p2_gen0_3_R97)
dif_p2_gen0_3_R98 <- cbind(rep =98, sum = dif_p2_gen0_3_R98)
dif_p2_gen0_3_R99 <- cbind(rep =99, sum = dif_p2_gen0_3_R99)
dif_p2_gen0_3_R100 <- cbind(rep =100, sum = dif_p2_gen0_3_R100)



dif_p2_gen0_3 <- rbind(dif_p2_gen0_3_R1, dif_p2_gen0_3_R2, dif_p2_gen0_3_R3, dif_p2_gen0_3_R4, dif_p2_gen0_3_R5, dif_p2_gen0_3_R6,
                       dif_p2_gen0_3_R7, dif_p2_gen0_3_R8, dif_p2_gen0_3_R9, dif_p2_gen0_3_R10, dif_p2_gen0_3_R11, dif_p2_gen0_3_R12,
                       dif_p2_gen0_3_R13, dif_p2_gen0_3_R14, dif_p2_gen0_3_R15, dif_p2_gen0_3_R16, dif_p2_gen0_3_R17, dif_p2_gen0_3_R18,
                       dif_p2_gen0_3_R19, dif_p2_gen0_3_R20, dif_p2_gen0_3_R21, dif_p2_gen0_3_R22, dif_p2_gen0_3_R23, dif_p2_gen0_3_R24,
                       dif_p2_gen0_3_R25, dif_p2_gen0_3_R26, dif_p2_gen0_3_R27, dif_p2_gen0_3_R28, dif_p2_gen0_3_R29, dif_p2_gen0_3_R30,
                       dif_p2_gen0_3_R31, dif_p2_gen0_3_R32, dif_p2_gen0_3_R33, dif_p2_gen0_3_R34, dif_p2_gen0_3_R35, dif_p2_gen0_3_R36,
                       dif_p2_gen0_3_R37, dif_p2_gen0_3_R38, dif_p2_gen0_3_R39, dif_p2_gen0_3_R40, dif_p2_gen0_3_R41, dif_p2_gen0_3_R42,
                       dif_p2_gen0_3_R43, dif_p2_gen0_3_R44, dif_p2_gen0_3_R45, dif_p2_gen0_3_R46, dif_p2_gen0_3_R47,
                       dif_p2_gen0_3_R48, dif_p2_gen0_3_R49, dif_p2_gen0_3_R50, dif_p2_gen0_3_R51, dif_p2_gen0_3_R52, dif_p2_gen0_3_R53,
                       dif_p2_gen0_3_R54, dif_p2_gen0_3_R55, dif_p2_gen0_3_R56, dif_p2_gen0_3_R57, dif_p2_gen0_3_R58, dif_p2_gen0_3_R59,
                       dif_p2_gen0_3_R60, dif_p2_gen0_3_R61, dif_p2_gen0_3_R62, dif_p2_gen0_3_R63, dif_p2_gen0_3_R64, dif_p2_gen0_3_R65,
                       dif_p2_gen0_3_R66, dif_p2_gen0_3_R67, dif_p2_gen0_3_R68, dif_p2_gen0_3_R69, dif_p2_gen0_3_R70, dif_p2_gen0_3_R71,
                       dif_p2_gen0_3_R72, dif_p2_gen0_3_R73, dif_p2_gen0_3_R74, dif_p2_gen0_3_R75, dif_p2_gen0_3_R76, dif_p2_gen0_3_R77,
                       dif_p2_gen0_3_R78, dif_p2_gen0_3_R79, dif_p2_gen0_3_R80, dif_p2_gen0_3_R81, dif_p2_gen0_3_R82, dif_p2_gen0_3_R83,
                       dif_p2_gen0_3_R84, dif_p2_gen0_3_R85, dif_p2_gen0_3_R86, dif_p2_gen0_3_R87, dif_p2_gen0_3_R88, dif_p2_gen0_3_R89,
                       dif_p2_gen0_3_R90, dif_p2_gen0_3_R91, dif_p2_gen0_3_R92, dif_p2_gen0_3_R93, dif_p2_gen0_3_R94, dif_p2_gen0_3_R95,
                       dif_p2_gen0_3_R96, dif_p2_gen0_3_R97, dif_p2_gen0_3_R98, dif_p2_gen0_3_R99, dif_p2_gen0_3_R100)

dif_p2_gen0_3 <- cbind(dif_gen = 3, pop=2, dif_p2_gen0_3)

# sum of squared differences between generation 0 and 6 pop2 ----
sum((F_P2_G0_R1 - F_P2_G6_R1)^2) -> dif_p2_gen0_6_R1
sum((F_P2_G0_R2 - F_P2_G6_R2)^2) -> dif_p2_gen0_6_R2 
sum((F_P2_G0_R3 - F_P2_G6_R3)^2) -> dif_p2_gen0_6_R3 
sum((F_P2_G0_R4 - F_P2_G6_R4)^2) -> dif_p2_gen0_6_R4
sum((F_P2_G0_R5 - F_P2_G6_R5)^2) -> dif_p2_gen0_6_R5 
sum((F_P2_G0_R6 - F_P2_G6_R6)^2) -> dif_p2_gen0_6_R6 
sum((F_P2_G0_R7 - F_P2_G6_R7)^2) -> dif_p2_gen0_6_R7
sum((F_P2_G0_R8 - F_P2_G6_R8)^2) -> dif_p2_gen0_6_R8 
sum((F_P2_G0_R9 - F_P2_G6_R9)^2) -> dif_p2_gen0_6_R9 
sum((F_P2_G0_R10 - F_P2_G6_R10)^2) -> dif_p2_gen0_6_R10
sum((F_P2_G0_R11 - F_P2_G6_R11)^2) -> dif_p2_gen0_6_R11 
sum((F_P2_G0_R12 - F_P2_G6_R12)^2) -> dif_p2_gen0_6_R12 
sum((F_P2_G0_R13 - F_P2_G6_R13)^2) -> dif_p2_gen0_6_R13
sum((F_P2_G0_R14 - F_P2_G6_R14)^2) -> dif_p2_gen0_6_R14 
sum((F_P2_G0_R15 - F_P2_G6_R15)^2) -> dif_p2_gen0_6_R15 
sum((F_P2_G0_R16 - F_P2_G6_R16)^2) -> dif_p2_gen0_6_R16
sum((F_P2_G0_R17 - F_P2_G6_R17)^2) -> dif_p2_gen0_6_R17 
sum((F_P2_G0_R18 - F_P2_G6_R18)^2) -> dif_p2_gen0_6_R18 
sum((F_P2_G0_R19 - F_P2_G6_R19)^2) -> dif_p2_gen0_6_R19
sum((F_P2_G0_R20 - F_P2_G6_R20)^2) -> dif_p2_gen0_6_R20 
sum((F_P2_G0_R21 - F_P2_G6_R21)^2) -> dif_p2_gen0_6_R21 
sum((F_P2_G0_R22 - F_P2_G6_R22)^2) -> dif_p2_gen0_6_R22 
sum((F_P2_G0_R23 - F_P2_G6_R23)^2) -> dif_p2_gen0_6_R23
sum((F_P2_G0_R24 - F_P2_G6_R24)^2) -> dif_p2_gen0_6_R24 
sum((F_P2_G0_R25 - F_P2_G6_R25)^2) -> dif_p2_gen0_6_R25 
sum((F_P2_G0_R26 - F_P2_G6_R26)^2) -> dif_p2_gen0_6_R26
sum((F_P2_G0_R27 - F_P2_G6_R27)^2) -> dif_p2_gen0_6_R27 
sum((F_P2_G0_R28 - F_P2_G6_R28)^2) -> dif_p2_gen0_6_R28 
sum((F_P2_G0_R29 - F_P2_G6_R29)^2) -> dif_p2_gen0_6_R29
sum((F_P2_G0_R30 - F_P2_G6_R30)^2) -> dif_p2_gen0_6_R30 
sum((F_P2_G0_R31 - F_P2_G6_R31)^2) -> dif_p2_gen0_6_R31 
sum((F_P2_G0_R32 - F_P2_G6_R32)^2) -> dif_p2_gen0_6_R32 
sum((F_P2_G0_R33 - F_P2_G6_R33)^2) -> dif_p2_gen0_6_R33
sum((F_P2_G0_R34 - F_P2_G6_R34)^2) -> dif_p2_gen0_6_R34 
sum((F_P2_G0_R35 - F_P2_G6_R35)^2) -> dif_p2_gen0_6_R35 
sum((F_P2_G0_R36 - F_P2_G6_R36)^2) -> dif_p2_gen0_6_R36
sum((F_P2_G0_R37 - F_P2_G6_R37)^2) -> dif_p2_gen0_6_R37 
sum((F_P2_G0_R38 - F_P2_G6_R38)^2) -> dif_p2_gen0_6_R38 
sum((F_P2_G0_R39 - F_P2_G6_R39)^2) -> dif_p2_gen0_6_R39
sum((F_P2_G0_R40 - F_P2_G6_R40)^2) -> dif_p2_gen0_6_R40 
sum((F_P2_G0_R41 - F_P2_G6_R41)^2) -> dif_p2_gen0_6_R41 
sum((F_P2_G0_R42 - F_P2_G6_R42)^2) -> dif_p2_gen0_6_R42 
sum((F_P2_G0_R43 - F_P2_G6_R43)^2) -> dif_p2_gen0_6_R43
sum((F_P2_G0_R44 - F_P2_G6_R44)^2) -> dif_p2_gen0_6_R44 
sum((F_P2_G0_R45 - F_P2_G6_R45)^2) -> dif_p2_gen0_6_R45 
sum((F_P2_G0_R46 - F_P2_G6_R46)^2) -> dif_p2_gen0_6_R46
sum((F_P2_G0_R47 - F_P2_G6_R47)^2) -> dif_p2_gen0_6_R47 
sum((F_P2_G0_R48 - F_P2_G6_R48)^2) -> dif_p2_gen0_6_R48 
sum((F_P2_G0_R49 - F_P2_G6_R49)^2) -> dif_p2_gen0_6_R49
sum((F_P2_G0_R50 - F_P2_G6_R50)^2) -> dif_p2_gen0_6_R50 
sum((F_P2_G0_R51 - F_P2_G6_R51)^2) -> dif_p2_gen0_6_R51 
sum((F_P2_G0_R52 - F_P2_G6_R52)^2) -> dif_p2_gen0_6_R52 
sum((F_P2_G0_R53 - F_P2_G6_R53)^2) -> dif_p2_gen0_6_R53
sum((F_P2_G0_R54 - F_P2_G6_R54)^2) -> dif_p2_gen0_6_R54 
sum((F_P2_G0_R55 - F_P2_G6_R55)^2) -> dif_p2_gen0_6_R55 
sum((F_P2_G0_R56 - F_P2_G6_R56)^2) -> dif_p2_gen0_6_R56
sum((F_P2_G0_R57 - F_P2_G6_R57)^2) -> dif_p2_gen0_6_R57 
sum((F_P2_G0_R58 - F_P2_G6_R58)^2) -> dif_p2_gen0_6_R58 
sum((F_P2_G0_R59 - F_P2_G6_R59)^2) -> dif_p2_gen0_6_R59
sum((F_P2_G0_R60 - F_P2_G6_R60)^2) -> dif_p2_gen0_6_R60 
sum((F_P2_G0_R61 - F_P2_G6_R61)^2) -> dif_p2_gen0_6_R61 
sum((F_P2_G0_R62 - F_P2_G6_R62)^2) -> dif_p2_gen0_6_R62 
sum((F_P2_G0_R63 - F_P2_G6_R63)^2) -> dif_p2_gen0_6_R63
sum((F_P2_G0_R64 - F_P2_G6_R64)^2) -> dif_p2_gen0_6_R64 
sum((F_P2_G0_R65 - F_P2_G6_R65)^2) -> dif_p2_gen0_6_R65 
sum((F_P2_G0_R66 - F_P2_G6_R66)^2) -> dif_p2_gen0_6_R66
sum((F_P2_G0_R67 - F_P2_G6_R67)^2) -> dif_p2_gen0_6_R67 
sum((F_P2_G0_R68 - F_P2_G6_R68)^2) -> dif_p2_gen0_6_R68 
sum((F_P2_G0_R69 - F_P2_G6_R69)^2) -> dif_p2_gen0_6_R69
sum((F_P2_G0_R70 - F_P2_G6_R70)^2) -> dif_p2_gen0_6_R70 
sum((F_P2_G0_R71 - F_P2_G6_R71)^2) -> dif_p2_gen0_6_R71 
sum((F_P2_G0_R72 - F_P2_G6_R72)^2) -> dif_p2_gen0_6_R72 
sum((F_P2_G0_R73 - F_P2_G6_R73)^2) -> dif_p2_gen0_6_R73
sum((F_P2_G0_R74 - F_P2_G6_R74)^2) -> dif_p2_gen0_6_R74 
sum((F_P2_G0_R75 - F_P2_G6_R75)^2) -> dif_p2_gen0_6_R75 
sum((F_P2_G0_R76 - F_P2_G6_R76)^2) -> dif_p2_gen0_6_R76
sum((F_P2_G0_R77 - F_P2_G6_R77)^2) -> dif_p2_gen0_6_R77 
sum((F_P2_G0_R78 - F_P2_G6_R78)^2) -> dif_p2_gen0_6_R78 
sum((F_P2_G0_R79 - F_P2_G6_R79)^2) -> dif_p2_gen0_6_R79
sum((F_P2_G0_R80 - F_P2_G6_R80)^2) -> dif_p2_gen0_6_R80 
sum((F_P2_G0_R81 - F_P2_G6_R81)^2) -> dif_p2_gen0_6_R81 
sum((F_P2_G0_R82 - F_P2_G6_R82)^2) -> dif_p2_gen0_6_R82 
sum((F_P2_G0_R83 - F_P2_G6_R83)^2) -> dif_p2_gen0_6_R83
sum((F_P2_G0_R84 - F_P2_G6_R84)^2) -> dif_p2_gen0_6_R84 
sum((F_P2_G0_R85 - F_P2_G6_R85)^2) -> dif_p2_gen0_6_R85 
sum((F_P2_G0_R86 - F_P2_G6_R86)^2) -> dif_p2_gen0_6_R86
sum((F_P2_G0_R87 - F_P2_G6_R87)^2) -> dif_p2_gen0_6_R87 
sum((F_P2_G0_R88 - F_P2_G6_R88)^2) -> dif_p2_gen0_6_R88 
sum((F_P2_G0_R89 - F_P2_G6_R89)^2) -> dif_p2_gen0_6_R89
sum((F_P2_G0_R90 - F_P2_G6_R90)^2) -> dif_p2_gen0_6_R90 
sum((F_P2_G0_R91 - F_P2_G6_R91)^2) -> dif_p2_gen0_6_R91 
sum((F_P2_G0_R92 - F_P2_G6_R92)^2) -> dif_p2_gen0_6_R92 
sum((F_P2_G0_R93 - F_P2_G6_R93)^2) -> dif_p2_gen0_6_R93
sum((F_P2_G0_R94 - F_P2_G6_R94)^2) -> dif_p2_gen0_6_R94 
sum((F_P2_G0_R95 - F_P2_G6_R95)^2) -> dif_p2_gen0_6_R95 
sum((F_P2_G0_R96 - F_P2_G6_R96)^2) -> dif_p2_gen0_6_R96
sum((F_P2_G0_R97 - F_P2_G6_R97)^2) -> dif_p2_gen0_6_R97 
sum((F_P2_G0_R98 - F_P2_G6_R98)^2) -> dif_p2_gen0_6_R98 
sum((F_P2_G0_R99 - F_P2_G6_R99)^2) -> dif_p2_gen0_6_R99
sum((F_P2_G0_R100 - F_P2_G6_R100)^2) -> dif_p2_gen0_6_R100 

dif_p2_gen0_6_R1 <- cbind(rep =1, sum = dif_p2_gen0_6_R1)
dif_p2_gen0_6_R2 <- cbind(rep =2, sum = dif_p2_gen0_6_R2)
dif_p2_gen0_6_R3 <- cbind(rep =3, sum = dif_p2_gen0_6_R3)
dif_p2_gen0_6_R4 <- cbind(rep =4, sum = dif_p2_gen0_6_R4)
dif_p2_gen0_6_R5 <- cbind(rep =5, sum = dif_p2_gen0_6_R5)
dif_p2_gen0_6_R6 <- cbind(rep =6, sum = dif_p2_gen0_6_R6)
dif_p2_gen0_6_R7 <- cbind(rep =7, sum = dif_p2_gen0_6_R7)
dif_p2_gen0_6_R8 <- cbind(rep =8, sum = dif_p2_gen0_6_R8)
dif_p2_gen0_6_R9 <- cbind(rep =9, sum = dif_p2_gen0_6_R9)
dif_p2_gen0_6_R10 <- cbind(rep =10, sum = dif_p2_gen0_6_R10)
dif_p2_gen0_6_R11 <- cbind(rep =11, sum = dif_p2_gen0_6_R11)
dif_p2_gen0_6_R12 <- cbind(rep =12, sum = dif_p2_gen0_6_R12)
dif_p2_gen0_6_R13 <- cbind(rep =13, sum = dif_p2_gen0_6_R13)
dif_p2_gen0_6_R14 <- cbind(rep =14, sum = dif_p2_gen0_6_R14)
dif_p2_gen0_6_R15 <- cbind(rep =15, sum = dif_p2_gen0_6_R15)
dif_p2_gen0_6_R16 <- cbind(rep =16, sum = dif_p2_gen0_6_R16)
dif_p2_gen0_6_R17 <- cbind(rep =17, sum = dif_p2_gen0_6_R17)
dif_p2_gen0_6_R18 <- cbind(rep =18, sum = dif_p2_gen0_6_R18)
dif_p2_gen0_6_R19 <- cbind(rep =19, sum = dif_p2_gen0_6_R19)
dif_p2_gen0_6_R20 <- cbind(rep =20, sum = dif_p2_gen0_6_R20)
dif_p2_gen0_6_R21 <- cbind(rep =21, sum = dif_p2_gen0_6_R21)
dif_p2_gen0_6_R22 <- cbind(rep =22, sum = dif_p2_gen0_6_R22)
dif_p2_gen0_6_R23 <- cbind(rep =23, sum = dif_p2_gen0_6_R23)
dif_p2_gen0_6_R24 <- cbind(rep =24, sum = dif_p2_gen0_6_R24)
dif_p2_gen0_6_R25 <- cbind(rep =25, sum = dif_p2_gen0_6_R25)
dif_p2_gen0_6_R26 <- cbind(rep =26, sum = dif_p2_gen0_6_R26)
dif_p2_gen0_6_R27 <- cbind(rep =27, sum = dif_p2_gen0_6_R27)
dif_p2_gen0_6_R28 <- cbind(rep =28, sum = dif_p2_gen0_6_R28)
dif_p2_gen0_6_R29 <- cbind(rep =29, sum = dif_p2_gen0_6_R29)
dif_p2_gen0_6_R30 <- cbind(rep =30, sum = dif_p2_gen0_6_R30)
dif_p2_gen0_6_R31 <- cbind(rep =31, sum = dif_p2_gen0_6_R31)
dif_p2_gen0_6_R32 <- cbind(rep =32, sum = dif_p2_gen0_6_R32)
dif_p2_gen0_6_R33 <- cbind(rep =33, sum = dif_p2_gen0_6_R33)
dif_p2_gen0_6_R34 <- cbind(rep =34, sum = dif_p2_gen0_6_R34)
dif_p2_gen0_6_R35 <- cbind(rep =35, sum = dif_p2_gen0_6_R35)
dif_p2_gen0_6_R36 <- cbind(rep =36, sum = dif_p2_gen0_6_R36)
dif_p2_gen0_6_R37 <- cbind(rep =37, sum = dif_p2_gen0_6_R37)
dif_p2_gen0_6_R38 <- cbind(rep =38, sum = dif_p2_gen0_6_R38)
dif_p2_gen0_6_R39 <- cbind(rep =39, sum = dif_p2_gen0_6_R39)
dif_p2_gen0_6_R40 <- cbind(rep =40, sum = dif_p2_gen0_6_R40)
dif_p2_gen0_6_R41 <- cbind(rep =41, sum = dif_p2_gen0_6_R41)
dif_p2_gen0_6_R42 <- cbind(rep =42, sum = dif_p2_gen0_6_R42)
dif_p2_gen0_6_R43 <- cbind(rep =43, sum = dif_p2_gen0_6_R43)
dif_p2_gen0_6_R44 <- cbind(rep =44, sum = dif_p2_gen0_6_R44)
dif_p2_gen0_6_R45 <- cbind(rep =45, sum = dif_p2_gen0_6_R45)
dif_p2_gen0_6_R46 <- cbind(rep =46, sum = dif_p2_gen0_6_R46)
dif_p2_gen0_6_R47 <- cbind(rep =47, sum = dif_p2_gen0_6_R47)
dif_p2_gen0_6_R48 <- cbind(rep =48, sum = dif_p2_gen0_6_R48)
dif_p2_gen0_6_R49 <- cbind(rep =49, sum = dif_p2_gen0_6_R49)
dif_p2_gen0_6_R50 <- cbind(rep =50, sum = dif_p2_gen0_6_R50)
dif_p2_gen0_6_R51 <- cbind(rep =51, sum = dif_p2_gen0_6_R51)
dif_p2_gen0_6_R52 <- cbind(rep =52, sum = dif_p2_gen0_6_R52)
dif_p2_gen0_6_R53 <- cbind(rep =53, sum = dif_p2_gen0_6_R53)
dif_p2_gen0_6_R54 <- cbind(rep =54, sum = dif_p2_gen0_6_R54)
dif_p2_gen0_6_R55 <- cbind(rep =55, sum = dif_p2_gen0_6_R55)
dif_p2_gen0_6_R56 <- cbind(rep =56, sum = dif_p2_gen0_6_R56)
dif_p2_gen0_6_R57 <- cbind(rep =57, sum = dif_p2_gen0_6_R57)
dif_p2_gen0_6_R58 <- cbind(rep =58, sum = dif_p2_gen0_6_R58)
dif_p2_gen0_6_R59 <- cbind(rep =59, sum = dif_p2_gen0_6_R59)
dif_p2_gen0_6_R60 <- cbind(rep =60, sum = dif_p2_gen0_6_R60)
dif_p2_gen0_6_R61 <- cbind(rep =61, sum = dif_p2_gen0_6_R61)
dif_p2_gen0_6_R62 <- cbind(rep =62, sum = dif_p2_gen0_6_R62)
dif_p2_gen0_6_R63 <- cbind(rep =63, sum = dif_p2_gen0_6_R63)
dif_p2_gen0_6_R64 <- cbind(rep =64, sum = dif_p2_gen0_6_R64)
dif_p2_gen0_6_R65 <- cbind(rep =65, sum = dif_p2_gen0_6_R65)
dif_p2_gen0_6_R66 <- cbind(rep =66, sum = dif_p2_gen0_6_R66)
dif_p2_gen0_6_R67 <- cbind(rep =67, sum = dif_p2_gen0_6_R67)
dif_p2_gen0_6_R68 <- cbind(rep =68, sum = dif_p2_gen0_6_R68)
dif_p2_gen0_6_R69 <- cbind(rep =69, sum = dif_p2_gen0_6_R69)
dif_p2_gen0_6_R70 <- cbind(rep =70, sum = dif_p2_gen0_6_R70)
dif_p2_gen0_6_R71 <- cbind(rep =71, sum = dif_p2_gen0_6_R71)
dif_p2_gen0_6_R72 <- cbind(rep =72, sum = dif_p2_gen0_6_R72)
dif_p2_gen0_6_R73 <- cbind(rep =73, sum = dif_p2_gen0_6_R73)
dif_p2_gen0_6_R74 <- cbind(rep =74, sum = dif_p2_gen0_6_R74)
dif_p2_gen0_6_R75 <- cbind(rep =75, sum = dif_p2_gen0_6_R75)
dif_p2_gen0_6_R76 <- cbind(rep =76, sum = dif_p2_gen0_6_R76)
dif_p2_gen0_6_R77 <- cbind(rep =77, sum = dif_p2_gen0_6_R77)
dif_p2_gen0_6_R78 <- cbind(rep =78, sum = dif_p2_gen0_6_R78)
dif_p2_gen0_6_R79 <- cbind(rep =79, sum = dif_p2_gen0_6_R79)
dif_p2_gen0_6_R80 <- cbind(rep =80, sum = dif_p2_gen0_6_R80)
dif_p2_gen0_6_R81 <- cbind(rep =81, sum = dif_p2_gen0_6_R81)
dif_p2_gen0_6_R82 <- cbind(rep =82, sum = dif_p2_gen0_6_R82)
dif_p2_gen0_6_R83 <- cbind(rep =83, sum = dif_p2_gen0_6_R83)
dif_p2_gen0_6_R84 <- cbind(rep =84, sum = dif_p2_gen0_6_R84)
dif_p2_gen0_6_R85 <- cbind(rep =85, sum = dif_p2_gen0_6_R85)
dif_p2_gen0_6_R86 <- cbind(rep =86, sum = dif_p2_gen0_6_R86)
dif_p2_gen0_6_R87 <- cbind(rep =87, sum = dif_p2_gen0_6_R87)
dif_p2_gen0_6_R88 <- cbind(rep =88, sum = dif_p2_gen0_6_R88)
dif_p2_gen0_6_R89 <- cbind(rep =89, sum = dif_p2_gen0_6_R89)
dif_p2_gen0_6_R90 <- cbind(rep =90, sum = dif_p2_gen0_6_R90)
dif_p2_gen0_6_R91 <- cbind(rep =91, sum = dif_p2_gen0_6_R91)
dif_p2_gen0_6_R92 <- cbind(rep =92, sum = dif_p2_gen0_6_R92)
dif_p2_gen0_6_R93 <- cbind(rep =93, sum = dif_p2_gen0_6_R93)
dif_p2_gen0_6_R94 <- cbind(rep =94, sum = dif_p2_gen0_6_R94)
dif_p2_gen0_6_R95 <- cbind(rep =95, sum = dif_p2_gen0_6_R95)
dif_p2_gen0_6_R96 <- cbind(rep =96, sum = dif_p2_gen0_6_R96)
dif_p2_gen0_6_R97 <- cbind(rep =97, sum = dif_p2_gen0_6_R97)
dif_p2_gen0_6_R98 <- cbind(rep =98, sum = dif_p2_gen0_6_R98)
dif_p2_gen0_6_R99 <- cbind(rep =99, sum = dif_p2_gen0_6_R99)
dif_p2_gen0_6_R100 <- cbind(rep =100, sum = dif_p2_gen0_6_R100)


dif_p2_gen0_6 <- rbind(dif_p2_gen0_6_R1, dif_p2_gen0_6_R2, dif_p2_gen0_6_R3, dif_p2_gen0_6_R4, dif_p2_gen0_6_R5, dif_p2_gen0_6_R6,
                       dif_p2_gen0_6_R7, dif_p2_gen0_6_R8, dif_p2_gen0_6_R9, dif_p2_gen0_6_R10, dif_p2_gen0_6_R11, dif_p2_gen0_6_R12,
                       dif_p2_gen0_6_R13, dif_p2_gen0_6_R14, dif_p2_gen0_6_R15, dif_p2_gen0_6_R16, dif_p2_gen0_6_R17, dif_p2_gen0_6_R18,
                       dif_p2_gen0_6_R19, dif_p2_gen0_6_R20, dif_p2_gen0_6_R21, dif_p2_gen0_6_R22, dif_p2_gen0_6_R23, dif_p2_gen0_6_R24,
                       dif_p2_gen0_6_R25, dif_p2_gen0_6_R26, dif_p2_gen0_6_R27, dif_p2_gen0_6_R28, dif_p2_gen0_6_R29, dif_p2_gen0_6_R30,
                       dif_p2_gen0_6_R31, dif_p2_gen0_6_R32, dif_p2_gen0_6_R33, dif_p2_gen0_6_R34, dif_p2_gen0_6_R35, dif_p2_gen0_6_R36,
                       dif_p2_gen0_6_R37, dif_p2_gen0_6_R38, dif_p2_gen0_6_R39, dif_p2_gen0_6_R40, dif_p2_gen0_6_R41, dif_p2_gen0_6_R42,
                       dif_p2_gen0_6_R43, dif_p2_gen0_6_R44, dif_p2_gen0_6_R45, dif_p2_gen0_6_R46, dif_p2_gen0_6_R47,
                       dif_p2_gen0_6_R48, dif_p2_gen0_6_R49, dif_p2_gen0_6_R50, dif_p2_gen0_6_R51, dif_p2_gen0_6_R52, dif_p2_gen0_6_R53,
                       dif_p2_gen0_6_R54, dif_p2_gen0_6_R55, dif_p2_gen0_6_R56, dif_p2_gen0_6_R57, dif_p2_gen0_6_R58, dif_p2_gen0_6_R59,
                       dif_p2_gen0_6_R60, dif_p2_gen0_6_R61, dif_p2_gen0_6_R62, dif_p2_gen0_6_R63, dif_p2_gen0_6_R64, dif_p2_gen0_6_R65,
                       dif_p2_gen0_6_R66, dif_p2_gen0_6_R67, dif_p2_gen0_6_R68, dif_p2_gen0_6_R69, dif_p2_gen0_6_R70, dif_p2_gen0_6_R71,
                       dif_p2_gen0_6_R72, dif_p2_gen0_6_R73, dif_p2_gen0_6_R74, dif_p2_gen0_6_R75, dif_p2_gen0_6_R76, dif_p2_gen0_6_R77,
                       dif_p2_gen0_6_R78, dif_p2_gen0_6_R79, dif_p2_gen0_6_R80, dif_p2_gen0_6_R81, dif_p2_gen0_6_R82, dif_p2_gen0_6_R83,
                       dif_p2_gen0_6_R84, dif_p2_gen0_6_R85, dif_p2_gen0_6_R86, dif_p2_gen0_6_R87, dif_p2_gen0_6_R88, dif_p2_gen0_6_R89,
                       dif_p2_gen0_6_R90, dif_p2_gen0_6_R91, dif_p2_gen0_6_R92, dif_p2_gen0_6_R93, dif_p2_gen0_6_R94, dif_p2_gen0_6_R95,
                       dif_p2_gen0_6_R96, dif_p2_gen0_6_R97, dif_p2_gen0_6_R98, dif_p2_gen0_6_R99, dif_p2_gen0_6_R100) 

dif_p2_gen0_6 <- cbind(dif_gen = 6, pop=2, dif_p2_gen0_6)

# sum of squared differences between generation 0 and 10 pop2 ----
sum((F_P2_G0_R1 - F_P2_G10_R1)^2) -> dif_p2_gen0_10_R1
sum((F_P2_G0_R2 - F_P2_G10_R2)^2) -> dif_p2_gen0_10_R2 
sum((F_P2_G0_R3 - F_P2_G10_R3)^2) -> dif_p2_gen0_10_R3 
sum((F_P2_G0_R4 - F_P2_G10_R4)^2) -> dif_p2_gen0_10_R4
sum((F_P2_G0_R5 - F_P2_G10_R5)^2) -> dif_p2_gen0_10_R5 
sum((F_P2_G0_R6 - F_P2_G10_R6)^2) -> dif_p2_gen0_10_R6 
sum((F_P2_G0_R7 - F_P2_G10_R7)^2) -> dif_p2_gen0_10_R7
sum((F_P2_G0_R8 - F_P2_G10_R8)^2) -> dif_p2_gen0_10_R8 
sum((F_P2_G0_R9 - F_P2_G10_R9)^2) -> dif_p2_gen0_10_R9 
sum((F_P2_G0_R10 - F_P2_G10_R10)^2) -> dif_p2_gen0_10_R10
sum((F_P2_G0_R11 - F_P2_G10_R11)^2) -> dif_p2_gen0_10_R11 
sum((F_P2_G0_R12 - F_P2_G10_R12)^2) -> dif_p2_gen0_10_R12 
sum((F_P2_G0_R13 - F_P2_G10_R13)^2) -> dif_p2_gen0_10_R13
sum((F_P2_G0_R14 - F_P2_G10_R14)^2) -> dif_p2_gen0_10_R14 
sum((F_P2_G0_R15 - F_P2_G10_R15)^2) -> dif_p2_gen0_10_R15 
sum((F_P2_G0_R16 - F_P2_G10_R16)^2) -> dif_p2_gen0_10_R16
sum((F_P2_G0_R17 - F_P2_G10_R17)^2) -> dif_p2_gen0_10_R17 
sum((F_P2_G0_R18 - F_P2_G10_R18)^2) -> dif_p2_gen0_10_R18 
sum((F_P2_G0_R19 - F_P2_G10_R19)^2) -> dif_p2_gen0_10_R19
sum((F_P2_G0_R20 - F_P2_G10_R20)^2) -> dif_p2_gen0_10_R20 
sum((F_P2_G0_R21 - F_P2_G10_R21)^2) -> dif_p2_gen0_10_R21 
sum((F_P2_G0_R22 - F_P2_G10_R22)^2) -> dif_p2_gen0_10_R22 
sum((F_P2_G0_R23 - F_P2_G10_R23)^2) -> dif_p2_gen0_10_R23
sum((F_P2_G0_R24 - F_P2_G10_R24)^2) -> dif_p2_gen0_10_R24 
sum((F_P2_G0_R25 - F_P2_G10_R25)^2) -> dif_p2_gen0_10_R25 
sum((F_P2_G0_R26 - F_P2_G10_R26)^2) -> dif_p2_gen0_10_R26
sum((F_P2_G0_R27 - F_P2_G10_R27)^2) -> dif_p2_gen0_10_R27 
sum((F_P2_G0_R28 - F_P2_G10_R28)^2) -> dif_p2_gen0_10_R28 
sum((F_P2_G0_R29 - F_P2_G10_R29)^2) -> dif_p2_gen0_10_R29
sum((F_P2_G0_R30 - F_P2_G10_R30)^2) -> dif_p2_gen0_10_R30 
sum((F_P2_G0_R31 - F_P2_G10_R31)^2) -> dif_p2_gen0_10_R31 
sum((F_P2_G0_R32 - F_P2_G10_R32)^2) -> dif_p2_gen0_10_R32 
sum((F_P2_G0_R33 - F_P2_G10_R33)^2) -> dif_p2_gen0_10_R33
sum((F_P2_G0_R34 - F_P2_G10_R34)^2) -> dif_p2_gen0_10_R34 
sum((F_P2_G0_R35 - F_P2_G10_R35)^2) -> dif_p2_gen0_10_R35 
sum((F_P2_G0_R36 - F_P2_G10_R36)^2) -> dif_p2_gen0_10_R36
sum((F_P2_G0_R37 - F_P2_G10_R37)^2) -> dif_p2_gen0_10_R37 
sum((F_P2_G0_R38 - F_P2_G10_R38)^2) -> dif_p2_gen0_10_R38 
sum((F_P2_G0_R39 - F_P2_G10_R39)^2) -> dif_p2_gen0_10_R39
sum((F_P2_G0_R40 - F_P2_G10_R40)^2) -> dif_p2_gen0_10_R40 
sum((F_P2_G0_R41 - F_P2_G10_R41)^2) -> dif_p2_gen0_10_R41 
sum((F_P2_G0_R42 - F_P2_G10_R42)^2) -> dif_p2_gen0_10_R42 
sum((F_P2_G0_R43 - F_P2_G10_R43)^2) -> dif_p2_gen0_10_R43
sum((F_P2_G0_R44 - F_P2_G10_R44)^2) -> dif_p2_gen0_10_R44 
sum((F_P2_G0_R45 - F_P2_G10_R45)^2) -> dif_p2_gen0_10_R45 
sum((F_P2_G0_R46 - F_P2_G10_R46)^2) -> dif_p2_gen0_10_R46
sum((F_P2_G0_R47 - F_P2_G10_R47)^2) -> dif_p2_gen0_10_R47 
sum((F_P2_G0_R48 - F_P2_G10_R48)^2) -> dif_p2_gen0_10_R48 
sum((F_P2_G0_R49 - F_P2_G10_R49)^2) -> dif_p2_gen0_10_R49
sum((F_P2_G0_R50 - F_P2_G10_R50)^2) -> dif_p2_gen0_10_R50 
sum((F_P2_G0_R51 - F_P2_G10_R51)^2) -> dif_p2_gen0_10_R51 
sum((F_P2_G0_R52 - F_P2_G10_R52)^2) -> dif_p2_gen0_10_R52 
sum((F_P2_G0_R53 - F_P2_G10_R53)^2) -> dif_p2_gen0_10_R53
sum((F_P2_G0_R54 - F_P2_G10_R54)^2) -> dif_p2_gen0_10_R54 
sum((F_P2_G0_R55 - F_P2_G10_R55)^2) -> dif_p2_gen0_10_R55 
sum((F_P2_G0_R56 - F_P2_G10_R56)^2) -> dif_p2_gen0_10_R56
sum((F_P2_G0_R57 - F_P2_G10_R57)^2) -> dif_p2_gen0_10_R57 
sum((F_P2_G0_R58 - F_P2_G10_R58)^2) -> dif_p2_gen0_10_R58 
sum((F_P2_G0_R59 - F_P2_G10_R59)^2) -> dif_p2_gen0_10_R59
sum((F_P2_G0_R60 - F_P2_G10_R60)^2) -> dif_p2_gen0_10_R60 
sum((F_P2_G0_R61 - F_P2_G10_R61)^2) -> dif_p2_gen0_10_R61 
sum((F_P2_G0_R62 - F_P2_G10_R62)^2) -> dif_p2_gen0_10_R62 
sum((F_P2_G0_R63 - F_P2_G10_R63)^2) -> dif_p2_gen0_10_R63
sum((F_P2_G0_R64 - F_P2_G10_R64)^2) -> dif_p2_gen0_10_R64 
sum((F_P2_G0_R65 - F_P2_G10_R65)^2) -> dif_p2_gen0_10_R65 
sum((F_P2_G0_R66 - F_P2_G10_R66)^2) -> dif_p2_gen0_10_R66
sum((F_P2_G0_R67 - F_P2_G10_R67)^2) -> dif_p2_gen0_10_R67 
sum((F_P2_G0_R68 - F_P2_G10_R68)^2) -> dif_p2_gen0_10_R68 
sum((F_P2_G0_R69 - F_P2_G10_R69)^2) -> dif_p2_gen0_10_R69
sum((F_P2_G0_R70 - F_P2_G10_R70)^2) -> dif_p2_gen0_10_R70 
sum((F_P2_G0_R71 - F_P2_G10_R71)^2) -> dif_p2_gen0_10_R71
sum((F_P2_G0_R72 - F_P2_G10_R72)^2) -> dif_p2_gen0_10_R72 
sum((F_P2_G0_R73 - F_P2_G10_R73)^2) -> dif_p2_gen0_10_R73
sum((F_P2_G0_R74 - F_P2_G10_R74)^2) -> dif_p2_gen0_10_R74 
sum((F_P2_G0_R75 - F_P2_G10_R75)^2) -> dif_p2_gen0_10_R75 
sum((F_P2_G0_R76 - F_P2_G10_R76)^2) -> dif_p2_gen0_10_R76
sum((F_P2_G0_R77 - F_P2_G10_R77)^2) -> dif_p2_gen0_10_R77 
sum((F_P2_G0_R78 - F_P2_G10_R78)^2) -> dif_p2_gen0_10_R78 
sum((F_P2_G0_R79 - F_P2_G10_R79)^2) -> dif_p2_gen0_10_R79
sum((F_P2_G0_R80 - F_P2_G10_R80)^2) -> dif_p2_gen0_10_R80 
sum((F_P2_G0_R81 - F_P2_G10_R81)^2) -> dif_p2_gen0_10_R81 
sum((F_P2_G0_R82 - F_P2_G10_R82)^2) -> dif_p2_gen0_10_R82 
sum((F_P2_G0_R83 - F_P2_G10_R83)^2) -> dif_p2_gen0_10_R83
sum((F_P2_G0_R84 - F_P2_G10_R84)^2) -> dif_p2_gen0_10_R84 
sum((F_P2_G0_R85 - F_P2_G10_R85)^2) -> dif_p2_gen0_10_R85 
sum((F_P2_G0_R86 - F_P2_G10_R86)^2) -> dif_p2_gen0_10_R86
sum((F_P2_G0_R87 - F_P2_G10_R87)^2) -> dif_p2_gen0_10_R87 
sum((F_P2_G0_R88 - F_P2_G10_R88)^2) -> dif_p2_gen0_10_R88 
sum((F_P2_G0_R89 - F_P2_G10_R89)^2) -> dif_p2_gen0_10_R89
sum((F_P2_G0_R90 - F_P2_G10_R90)^2) -> dif_p2_gen0_10_R90 
sum((F_P2_G0_R91 - F_P2_G10_R91)^2) -> dif_p2_gen0_10_R91 
sum((F_P2_G0_R92 - F_P2_G10_R92)^2) -> dif_p2_gen0_10_R92 
sum((F_P2_G0_R93 - F_P2_G10_R93)^2) -> dif_p2_gen0_10_R93
sum((F_P2_G0_R94 - F_P2_G10_R94)^2) -> dif_p2_gen0_10_R94 
sum((F_P2_G0_R95 - F_P2_G10_R95)^2) -> dif_p2_gen0_10_R95 
sum((F_P2_G0_R96 - F_P2_G10_R96)^2) -> dif_p2_gen0_10_R96
sum((F_P2_G0_R97 - F_P2_G10_R97)^2) -> dif_p2_gen0_10_R97 
sum((F_P2_G0_R98 - F_P2_G10_R98)^2) -> dif_p2_gen0_10_R98 
sum((F_P2_G0_R99 - F_P2_G10_R99)^2) -> dif_p2_gen0_10_R99
sum((F_P2_G0_R100 - F_P2_G10_R100)^2) -> dif_p2_gen0_10_R100 

dif_p2_gen0_10_R1 <- cbind(rep =1, sum = dif_p2_gen0_10_R1)
dif_p2_gen0_10_R2 <- cbind(rep =2, sum = dif_p2_gen0_10_R2)
dif_p2_gen0_10_R3 <- cbind(rep =3, sum = dif_p2_gen0_10_R3)
dif_p2_gen0_10_R4 <- cbind(rep =4, sum = dif_p2_gen0_10_R4)
dif_p2_gen0_10_R5 <- cbind(rep =5, sum = dif_p2_gen0_10_R5)
dif_p2_gen0_10_R6 <- cbind(rep =6, sum = dif_p2_gen0_10_R6)
dif_p2_gen0_10_R7 <- cbind(rep =7, sum = dif_p2_gen0_10_R7)
dif_p2_gen0_10_R8 <- cbind(rep =8, sum = dif_p2_gen0_10_R8)
dif_p2_gen0_10_R9 <- cbind(rep =9, sum = dif_p2_gen0_10_R9)
dif_p2_gen0_10_R10 <- cbind(rep =10, sum = dif_p2_gen0_10_R10)
dif_p2_gen0_10_R11 <- cbind(rep =11, sum = dif_p2_gen0_10_R11)
dif_p2_gen0_10_R12 <- cbind(rep =12, sum = dif_p2_gen0_10_R12)
dif_p2_gen0_10_R13 <- cbind(rep =13, sum = dif_p2_gen0_10_R13)
dif_p2_gen0_10_R14 <- cbind(rep =14, sum = dif_p2_gen0_10_R14)
dif_p2_gen0_10_R15 <- cbind(rep =15, sum = dif_p2_gen0_10_R15)
dif_p2_gen0_10_R16 <- cbind(rep =16, sum = dif_p2_gen0_10_R16)
dif_p2_gen0_10_R17 <- cbind(rep =17, sum = dif_p2_gen0_10_R17)
dif_p2_gen0_10_R18 <- cbind(rep =18, sum = dif_p2_gen0_10_R18)
dif_p2_gen0_10_R19 <- cbind(rep =19, sum = dif_p2_gen0_10_R19)
dif_p2_gen0_10_R20 <- cbind(rep =20, sum = dif_p2_gen0_10_R20)
dif_p2_gen0_10_R21 <- cbind(rep =21, sum = dif_p2_gen0_10_R21)
dif_p2_gen0_10_R22 <- cbind(rep =22, sum = dif_p2_gen0_10_R22)
dif_p2_gen0_10_R23 <- cbind(rep =23, sum = dif_p2_gen0_10_R23)
dif_p2_gen0_10_R24 <- cbind(rep =24, sum = dif_p2_gen0_10_R24)
dif_p2_gen0_10_R25 <- cbind(rep =25, sum = dif_p2_gen0_10_R25)
dif_p2_gen0_10_R26 <- cbind(rep =26, sum = dif_p2_gen0_10_R26)
dif_p2_gen0_10_R27 <- cbind(rep =27, sum = dif_p2_gen0_10_R27)
dif_p2_gen0_10_R28 <- cbind(rep =28, sum = dif_p2_gen0_10_R28)
dif_p2_gen0_10_R29 <- cbind(rep =29, sum = dif_p2_gen0_10_R29)
dif_p2_gen0_10_R30 <- cbind(rep =30, sum = dif_p2_gen0_10_R30)
dif_p2_gen0_10_R31 <- cbind(rep =31, sum = dif_p2_gen0_10_R31)
dif_p2_gen0_10_R32 <- cbind(rep =32, sum = dif_p2_gen0_10_R32)
dif_p2_gen0_10_R33 <- cbind(rep =33, sum = dif_p2_gen0_10_R33)
dif_p2_gen0_10_R34 <- cbind(rep =34, sum = dif_p2_gen0_10_R34)
dif_p2_gen0_10_R35 <- cbind(rep =35, sum = dif_p2_gen0_10_R35)
dif_p2_gen0_10_R36 <- cbind(rep =36, sum = dif_p2_gen0_10_R36)
dif_p2_gen0_10_R37 <- cbind(rep =37, sum = dif_p2_gen0_10_R37)
dif_p2_gen0_10_R38 <- cbind(rep =38, sum = dif_p2_gen0_10_R38)
dif_p2_gen0_10_R39 <- cbind(rep =39, sum = dif_p2_gen0_10_R39)
dif_p2_gen0_10_R40 <- cbind(rep =40, sum = dif_p2_gen0_10_R40)
dif_p2_gen0_10_R41 <- cbind(rep =41, sum = dif_p2_gen0_10_R41)
dif_p2_gen0_10_R42 <- cbind(rep =42, sum = dif_p2_gen0_10_R42)
dif_p2_gen0_10_R43 <- cbind(rep =43, sum = dif_p2_gen0_10_R43)
dif_p2_gen0_10_R44 <- cbind(rep =44, sum = dif_p2_gen0_10_R44)
dif_p2_gen0_10_R45 <- cbind(rep =45, sum = dif_p2_gen0_10_R45)
dif_p2_gen0_10_R46 <- cbind(rep =46, sum = dif_p2_gen0_10_R46)
dif_p2_gen0_10_R47 <- cbind(rep =47, sum = dif_p2_gen0_10_R47)
dif_p2_gen0_10_R48 <- cbind(rep =48, sum = dif_p2_gen0_10_R48)
dif_p2_gen0_10_R49 <- cbind(rep =49, sum = dif_p2_gen0_10_R49)
dif_p2_gen0_10_R50 <- cbind(rep =50, sum = dif_p2_gen0_10_R50)
dif_p2_gen0_10_R51 <- cbind(rep =51, sum = dif_p2_gen0_10_R51)
dif_p2_gen0_10_R52 <- cbind(rep =52, sum = dif_p2_gen0_10_R52)
dif_p2_gen0_10_R53 <- cbind(rep =53, sum = dif_p2_gen0_10_R53)
dif_p2_gen0_10_R54 <- cbind(rep =54, sum = dif_p2_gen0_10_R54)
dif_p2_gen0_10_R55 <- cbind(rep =55, sum = dif_p2_gen0_10_R55)
dif_p2_gen0_10_R56 <- cbind(rep =56, sum = dif_p2_gen0_10_R56)
dif_p2_gen0_10_R57 <- cbind(rep =57, sum = dif_p2_gen0_10_R57)
dif_p2_gen0_10_R58 <- cbind(rep =58, sum = dif_p2_gen0_10_R58)
dif_p2_gen0_10_R59 <- cbind(rep =59, sum = dif_p2_gen0_10_R59)
dif_p2_gen0_10_R60 <- cbind(rep =60, sum = dif_p2_gen0_10_R60)
dif_p2_gen0_10_R61 <- cbind(rep =61, sum = dif_p2_gen0_10_R61)
dif_p2_gen0_10_R62 <- cbind(rep =62, sum = dif_p2_gen0_10_R62)
dif_p2_gen0_10_R63 <- cbind(rep =63, sum = dif_p2_gen0_10_R63)
dif_p2_gen0_10_R64 <- cbind(rep =64, sum = dif_p2_gen0_10_R64)
dif_p2_gen0_10_R65 <- cbind(rep =65, sum = dif_p2_gen0_10_R65)
dif_p2_gen0_10_R66 <- cbind(rep =66, sum = dif_p2_gen0_10_R66)
dif_p2_gen0_10_R67 <- cbind(rep =67, sum = dif_p2_gen0_10_R67)
dif_p2_gen0_10_R68 <- cbind(rep =68, sum = dif_p2_gen0_10_R68)
dif_p2_gen0_10_R69 <- cbind(rep =69, sum = dif_p2_gen0_10_R69)
dif_p2_gen0_10_R70 <- cbind(rep =70, sum = dif_p2_gen0_10_R70)
dif_p2_gen0_10_R71 <- cbind(rep =71, sum = dif_p2_gen0_10_R71)
dif_p2_gen0_10_R72 <- cbind(rep =72, sum = dif_p2_gen0_10_R72)
dif_p2_gen0_10_R73 <- cbind(rep =73, sum = dif_p2_gen0_10_R73)
dif_p2_gen0_10_R74 <- cbind(rep =74, sum = dif_p2_gen0_10_R74)
dif_p2_gen0_10_R75 <- cbind(rep =75, sum = dif_p2_gen0_10_R75)
dif_p2_gen0_10_R76 <- cbind(rep =76, sum = dif_p2_gen0_10_R76)
dif_p2_gen0_10_R77 <- cbind(rep =77, sum = dif_p2_gen0_10_R77)
dif_p2_gen0_10_R78 <- cbind(rep =78, sum = dif_p2_gen0_10_R78)
dif_p2_gen0_10_R79 <- cbind(rep =79, sum = dif_p2_gen0_10_R79)
dif_p2_gen0_10_R80 <- cbind(rep =80, sum = dif_p2_gen0_10_R80)
dif_p2_gen0_10_R81 <- cbind(rep =81, sum = dif_p2_gen0_10_R81)
dif_p2_gen0_10_R82 <- cbind(rep =82, sum = dif_p2_gen0_10_R82)
dif_p2_gen0_10_R83 <- cbind(rep =83, sum = dif_p2_gen0_10_R83)
dif_p2_gen0_10_R84 <- cbind(rep =84, sum = dif_p2_gen0_10_R84)
dif_p2_gen0_10_R85 <- cbind(rep =85, sum = dif_p2_gen0_10_R85)
dif_p2_gen0_10_R86 <- cbind(rep =86, sum = dif_p2_gen0_10_R86)
dif_p2_gen0_10_R87 <- cbind(rep =87, sum = dif_p2_gen0_10_R87)
dif_p2_gen0_10_R88 <- cbind(rep =88, sum = dif_p2_gen0_10_R88)
dif_p2_gen0_10_R89 <- cbind(rep =89, sum = dif_p2_gen0_10_R89)
dif_p2_gen0_10_R90 <- cbind(rep =90, sum = dif_p2_gen0_10_R90)
dif_p2_gen0_10_R91 <- cbind(rep =91, sum = dif_p2_gen0_10_R91)
dif_p2_gen0_10_R92 <- cbind(rep =92, sum = dif_p2_gen0_10_R92)
dif_p2_gen0_10_R93 <- cbind(rep =93, sum = dif_p2_gen0_10_R93)
dif_p2_gen0_10_R94 <- cbind(rep =94, sum = dif_p2_gen0_10_R94)
dif_p2_gen0_10_R95 <- cbind(rep =95, sum = dif_p2_gen0_10_R95)
dif_p2_gen0_10_R96 <- cbind(rep =96, sum = dif_p2_gen0_10_R96)
dif_p2_gen0_10_R97 <- cbind(rep =97, sum = dif_p2_gen0_10_R97)
dif_p2_gen0_10_R98 <- cbind(rep =98, sum = dif_p2_gen0_10_R98)
dif_p2_gen0_10_R99 <- cbind(rep =99, sum = dif_p2_gen0_10_R99)
dif_p2_gen0_10_R100 <- cbind(rep =100, sum = dif_p2_gen0_10_R100)


dif_p2_gen0_10 <- rbind(dif_p2_gen0_10_R1, dif_p2_gen0_10_R2, dif_p2_gen0_10_R3, dif_p2_gen0_10_R4, dif_p2_gen0_10_R5, dif_p2_gen0_10_R6,
                        dif_p2_gen0_10_R7, dif_p2_gen0_10_R8, dif_p2_gen0_10_R9, dif_p2_gen0_10_R10, dif_p2_gen0_10_R11, dif_p2_gen0_10_R12,
                        dif_p2_gen0_10_R13, dif_p2_gen0_10_R14, dif_p2_gen0_10_R15, dif_p2_gen0_10_R16, dif_p2_gen0_10_R17, dif_p2_gen0_10_R18,
                        dif_p2_gen0_10_R19, dif_p2_gen0_10_R20, dif_p2_gen0_10_R21, dif_p2_gen0_10_R22, dif_p2_gen0_10_R23, dif_p2_gen0_10_R24,
                        dif_p2_gen0_10_R25, dif_p2_gen0_10_R26, dif_p2_gen0_10_R27, dif_p2_gen0_10_R28, dif_p2_gen0_10_R29, dif_p2_gen0_10_R30,
                        dif_p2_gen0_10_R31, dif_p2_gen0_10_R32, dif_p2_gen0_10_R33, dif_p2_gen0_10_R34, dif_p2_gen0_10_R35, dif_p2_gen0_10_R36,
                        dif_p2_gen0_10_R37, dif_p2_gen0_10_R38, dif_p2_gen0_10_R39, dif_p2_gen0_10_R40, dif_p2_gen0_10_R41, dif_p2_gen0_10_R42,
                        dif_p2_gen0_10_R43, dif_p2_gen0_10_R44, dif_p2_gen0_10_R45, dif_p2_gen0_10_R46, dif_p2_gen0_10_R47,
                        dif_p2_gen0_10_R48, dif_p2_gen0_10_R49, dif_p2_gen0_10_R50, dif_p2_gen0_10_R51, dif_p2_gen0_10_R52, dif_p2_gen0_10_R53,
                        dif_p2_gen0_10_R54, dif_p2_gen0_10_R55, dif_p2_gen0_10_R56, dif_p2_gen0_10_R57, dif_p2_gen0_10_R58, dif_p2_gen0_10_R59,
                        dif_p2_gen0_10_R60, dif_p2_gen0_10_R61, dif_p2_gen0_10_R62, dif_p2_gen0_10_R63, dif_p2_gen0_10_R64, dif_p2_gen0_10_R65,
                        dif_p2_gen0_10_R66, dif_p2_gen0_10_R67, dif_p2_gen0_10_R68, dif_p2_gen0_10_R69, dif_p2_gen0_10_R70, dif_p2_gen0_10_R71,
                        dif_p2_gen0_10_R72, dif_p2_gen0_10_R73, dif_p2_gen0_10_R74, dif_p2_gen0_10_R75, dif_p2_gen0_10_R76, dif_p2_gen0_10_R77,
                        dif_p2_gen0_10_R78, dif_p2_gen0_10_R79, dif_p2_gen0_10_R80, dif_p2_gen0_10_R81, dif_p2_gen0_10_R82, dif_p2_gen0_10_R83,
                        dif_p2_gen0_10_R84, dif_p2_gen0_10_R85, dif_p2_gen0_10_R86, dif_p2_gen0_10_R87, dif_p2_gen0_10_R88, dif_p2_gen0_10_R89,
                        dif_p2_gen0_10_R90, dif_p2_gen0_10_R91, dif_p2_gen0_10_R92, dif_p2_gen0_10_R93, dif_p2_gen0_10_R94, dif_p2_gen0_10_R95,
                        dif_p2_gen0_10_R96, dif_p2_gen0_10_R97, dif_p2_gen0_10_R98, dif_p2_gen0_10_R99, dif_p2_gen0_10_R100) 

dif_p2_gen0_10 <- cbind(dif_gen = 10, pop=2, dif_p2_gen0_10)

dif_p2 <- rbind(dif_p2_gen0_0, dif_p2_gen0_3, dif_p2_gen0_6, dif_p2_gen0_10)

dif_p2 <- as.data.frame(dif_p2)
dif_p2$sum <- (dif_p2$sum/30)
dif_p2$dif_gen <- as.factor(dif_p2$dif_gen)
dif_p2$pop <- as.factor(dif_p2$pop)

ggplot(aes(y = sum, x = dif_gen, fill = pop), data = dif_p2) + geom_boxplot() + labs(title="allele frequencies") + 
  xlab('generation') + ylab('distance')

# dataframe with pop1 and pop2 ----  
dif <- rbind(dif_p1, dif_p2)

dif <- as.data.frame(dif)
dif$dif_gen <- as.factor(dif$dif_gen)
dif$pop <- as.factor(dif$pop)

#plot----
ggplot(aes(y = sum, x = dif_gen, fill = pop), data = dif) + geom_boxplot() + labs(title="allele frequency estimates") + 
  xlab('generation') + ylab('distance') + theme_bw()
