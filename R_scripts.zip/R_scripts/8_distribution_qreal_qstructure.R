#·· plots of distribution of qreal and Structure

library(ggplot2)

F01_L30_A10 <- rbind(F01_A10_L30_M001, F01_A10_L30_M005)
F01_L30_A10_no0 <- rbind(F01_A10_L30_M001_no0, F01_A10_L30_M005_no0)


#create graph of q real ----
ggplot(F01_L30_A10, aes(x = real_q_values, stat(density), colour = interaction(m, alleles), fill = interaction(m, alleles))) + geom_density(size=1.0, alpha=0.2) +
  xlab('real q values') + ylim(0,5) + 
  labs(title="F01_L30") + theme_bw()

#create graph of q real ----
ggplot(F01_L30_A10, aes(x = Structure_q_values, stat(density), colour = interaction(m, alleles), fill = interaction(m, alleles))) + geom_density(size=1.0, alpha=0.2) +
  xlab('real q values') + ylim(0,5) + 
  labs(title="F01_L30") + theme_bw()




