### non parametric test to test if q structure is significantly greater than q real

require(coin)

#Fst 0.1 M 0.05----
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L10_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L30_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L100_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A5_L10_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A5_L30_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A5_L100_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A10_L10_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A10_L30_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A10_L100_M005_no0, paired = TRUE, alternative = "greater")

#Fst 0.1 M 0.01----
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L10_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L30_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L100_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A5_L10_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A5_L30_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A5_L100_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A10_L10_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A10_L30_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A10_L100_M001_no0, paired = TRUE, alternative = "greater")

#Fst 0.05 M 0.05----
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F005_A2_L10_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F005_A2_L30_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F005_A2_L100_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F005_A5_L10_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F005_A5_L30_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F005_A5_L100_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F005_A10_L10_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F005_A10_L30_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F005_A10_L100_M005_no0, paired = TRUE, alternative = "greater")

#Fst 0.05 M 0.01----
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F005_A2_L10_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F005_A2_L30_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F005_A2_L100_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F005_A5_L10_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F005_A5_L30_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F005_A5_L100_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F005_A10_L10_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F005_A10_L30_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F005_A10_L100_M001_no0, paired = TRUE, alternative = "greater")

#Fst 0.2 M 0.05----
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F02_A2_L10_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F02_A2_L30_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F02_A2_L100_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F02_A5_L10_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F02_A5_L30_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F02_A5_L100_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F02_A10_L10_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F02_A10_L30_M005_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F02_A10_L100_M005_no0, paired = TRUE, alternative = "greater")

#Fst 0.2 M 0.01----
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F02_A2_L10_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F02_A2_L30_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F02_A2_L100_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F02_A5_L10_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F02_A5_L30_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F02_A5_L100_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F02_A10_L10_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F02_A10_L30_M001_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F02_A10_L100_M001_no0, paired = TRUE, alternative = "greater")


#reference 10% ----
#popinfo on M001 A5
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A5_L30_M001_ref10_popinfo_no0_no1, paired = TRUE, alternative = "greater")
#popinfo on M001 A10
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A10_L30_M001_ref10_popinfo_no0_no1, paired = TRUE, alternative = "greater")
#popinfo on M005 A5
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A5_L30_M005_ref10_popinfo_no0_no1, paired = TRUE, alternative = "greater")
#popinfo on M005 A10
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A10_L30_M005_ref10_popinfo_no0_no1, paired = TRUE, alternative = "greater")

#popinfo off M001 A5
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A5_L30_M001_ref10_no0_no1, paired = TRUE, alternative = "greater")
#popinfo off M001 A10
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A10_L30_M001_ref10_no0_no1, paired = TRUE, alternative = "greater")
#popinfo off M005 A5
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A5_L30_M005_ref10_no0_no1, paired = TRUE, alternative = "greater")
#popinfo off M005 A10
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A10_L30_M005_ref10_no0_no1, paired = TRUE, alternative = "greater")


#reference 30% ----
#popinfo on M001 A5
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A5_L30_M001_ref30_popinfo_no0_no1, paired = TRUE, alternative = "greater")
#popinfo on M001 A10
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A10_L30_M001_ref30_popinfo_no0_no1, paired = TRUE, alternative = "greater")
#popinfo on M005 A5
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A5_L30_M005_ref30_popinfo_no0_no1, paired = TRUE, alternative = "greater")
#popinfo on M005 A10
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A10_L30_M005_ref30_popinfo_no0_no1, paired = TRUE, alternative = "greater")

#popinfo off M001 A5
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A5_L30_M001_ref30_no0_no1, paired = TRUE, alternative = "greater")
#popinfo off M001 A10
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A10_L30_M001_ref30_no0_no1, paired = TRUE, alternative = "greater")
#popinfo off M005 A5
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A5_L30_M005_ref30_no0_no1, paired = TRUE, alternative = "greater")
#popinfo off M005 A10
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A10_L30_M005_ref30_no0_no1, paired = TRUE, alternative = "greater")

#test reference 100 ----
#L30 A5
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A5_L30_N205_reference_corr_no0_no1, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A5_L30_N205_reference_corr_no0_no1, paired = TRUE)
#L30 A10
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A10_L30_N205_reference_corr_no0_no1, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A10_L30_N205_reference_corr_no0_no1, paired = TRUE)
#L100 A5
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A5_L100_N205_reference_corr_no0_no1, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A5_L100_N205_reference_corr_no0_no1, paired = TRUE)
#L100 A10
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A10_L100_N205_reference_corr_no0_no1, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A10_L100_N205_reference_corr_no0_no1, paired = TRUE)
