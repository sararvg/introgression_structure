### linear regressions 

#nine plots fst 0.1, m 0.05 ----
p1 <- ggplot(data= F01_A2_L10_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F01_A2_L10_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p2 <- ggplot(data= F01_A5_L10_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F01_A5_L10_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p3 <- ggplot(data= F01_A10_L10_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F01_A10_L10_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p4 <- ggplot(data= F01_A2_L30_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F01_A2_L30_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p5 <- ggplot(data= F01_A5_L30_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F01_A5_L30_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p6 <- ggplot(data= F01_A10_L30_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F01_A10_L30_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue") + geom_smooth(method=lm, color="black")
p7 <- ggplot(data= F01_A2_L100_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F01_A2_L100_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p8 <- ggplot(data= F01_A5_L100_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F01_A5_L100_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="black") + geom_smooth(method=lm, color="red")
p9 <- ggplot(data= F01_A10_L100_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F01_A10_L100_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="black") + geom_smooth(method=lm, color="red")

grid.arrange(p1, p2, p3, p4, p5, p6, p7, p8, p9, ncol=3, top = "Fst 0.1, m 0.05")

#Regression Fst 0.1 m 0.05 ----
reg1 <- lm(Structure_q_values ~ real_q_values, data=F01_A2_L10_M005_no0)
reg2 <- lm(Structure_q_values ~ real_q_values, data=F01_A5_L10_M005_no0)
reg3 <- lm(Structure_q_values ~ real_q_values, data=F01_A10_L10_M005_no0)
reg4 <- lm(Structure_q_values ~ real_q_values, data=F01_A2_L30_M005_no0)
reg5 <- lm(Structure_q_values ~ real_q_values, data=F01_A5_L30_M005_no0)
reg6 <- lm(Structure_q_values ~ real_q_values, data=F01_A10_L30_M005_no0)
reg7 <- lm(Structure_q_values ~ real_q_values, data=F01_A2_L100_M005_no0)
reg8 <- lm(Structure_q_values ~ real_q_values, data=F01_A5_L100_M005_no0)
reg9 <- lm(Structure_q_values ~ real_q_values, data=F01_A10_L100_M005_no0)

par(mfrow=c(3,3))
qqnorm(residuals(reg1)); qqline(residuals(reg1))
qqnorm(residuals(reg2)); qqline(residuals(reg2))
qqnorm(residuals(reg3)); qqline(residuals(reg3))
qqnorm(residuals(reg4)); qqline(residuals(reg4))
qqnorm(residuals(reg5)); qqline(residuals(reg5))
qqnorm(residuals(reg6)); qqline(residuals(reg6))
qqnorm(residuals(reg7)); qqline(residuals(reg7))
qqnorm(residuals(reg8)); qqline(residuals(reg8))
qqnorm(residuals(reg9)); qqline(residuals(reg9))

summary(reg8)
summary(reg9)

#compare q structure with q real
b1 <- ggplot(data=F01_A5_L100_M005_no0, aes(x=rep, y=qdif)) +
  labs(title = "2 a, 10 l", y = "qdif") + geom_boxplot()  + theme_bw() +
  geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(-1,1))+
  geom_point(position = position_jitter(width = 0.1), size=1)
b1


#nine plots fst 0.1, m 0.01 ----
p10 <- ggplot(data= F01_A2_L10_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F01_A2_L10_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue") 
p11 <- ggplot(data= F01_A5_L10_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F01_A5_L10_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p12 <- ggplot(data= F01_A10_L10_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F01_A10_L10_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p13<- ggplot(data= F01_A2_L30_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F01_A2_L30_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p14 <- ggplot(data= F01_A5_L30_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F01_A5_L30_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p15 <- ggplot(data= F01_A10_L30_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F01_A10_L30_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue") + geom_smooth(method=lm, color="grey")
p16 <- ggplot(data= F01_A2_L100_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F01_A2_L100_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p17 <- ggplot(data= F01_A5_L100_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F01_A5_L100_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue") + geom_smooth(method=lm, color="black")
p18 <- ggplot(data= F01_A10_L100_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F01_A10_L100_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="black") + geom_smooth(method=lm, color="red")

grid.arrange(p10, p11, p12, p13, p14, p15, p16, p17, p18, ncol=3, top = "Fst 0.1, m 0.01")

#Regression Fst 0.1 m 0.01 ----
reg10 <- lm(Structure_q_values ~ real_q_values, data=F01_A2_L10_M001_no0)
reg11 <- lm(Structure_q_values ~ real_q_values, data=F01_A5_L10_M001_no0)
reg12 <- lm(Structure_q_values ~ real_q_values, data=F01_A10_L10_M001_no0)
reg13 <- lm(Structure_q_values ~ real_q_values, data=F01_A2_L30_M001_no0)
reg14 <- lm(Structure_q_values ~ real_q_values, data=F01_A5_L30_M001_no0)
reg15 <- lm(Structure_q_values ~ real_q_values, data=F01_A10_L30_M001_no0)
reg16 <- lm(Structure_q_values ~ real_q_values, data=F01_A2_L100_M001_no0)
reg17 <- lm(Structure_q_values ~ real_q_values, data=F01_A5_L100_M001_no0)
reg18 <- lm(Structure_q_values ~ real_q_values, data=F01_A10_L100_M001_no0)

par(mfrow=c(3,3))
qqnorm(residuals(reg10)); qqline(residuals(reg10))
qqnorm(residuals(reg11)); qqline(residuals(reg11))
qqnorm(residuals(reg12)); qqline(residuals(reg12))
qqnorm(residuals(reg13)); qqline(residuals(reg13))
qqnorm(residuals(reg14)); qqline(residuals(reg14))
qqnorm(residuals(reg15)); qqline(residuals(reg15))
qqnorm(residuals(reg16)); qqline(residuals(reg16))
qqnorm(residuals(reg17)); qqline(residuals(reg17))
qqnorm(residuals(reg18)); qqline(residuals(reg18))

summary(reg15)
summary(reg17)
summary(reg18)


#nine plots fst 0.2, m 0.05 ----
p19 <- ggplot(data= F02_A2_L10_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F02_A2_L10_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue") 
p20 <- ggplot(data= F02_A5_L10_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F02_A5_L10_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p21 <- ggplot(data= F02_A10_L10_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F02_A10_L10_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p22<- ggplot(data= F02_A2_L30_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F02_A2_L30_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p23 <- ggplot(data= F02_A5_L30_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F02_A5_L30_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="black") + geom_smooth(method=lm, color="orange")
p24 <- ggplot(data= F02_A10_L30_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F02_A10_L30_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="black") + geom_smooth(method=lm, color="orange")
p25 <- ggplot(data= F02_A2_L100_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F02_A2_L100_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="black") + geom_smooth(method=lm, color="orange")
p26 <- ggplot(data= F02_A5_L100_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F02_A5_L100_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="black") + geom_smooth(method=lm, color="red")
p27 <- ggplot(data= F02_A10_L100_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F02_A10_L100_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="black") + geom_smooth(method=lm, color="red")

grid.arrange(p19, p20, p21, p22, p23, p24, p25, p26, p27, ncol=3, top = "Fst 0.2, m 0.05")

#Regression Fst 0.2 m 0.05 ----
reg19 <- lm(Structure_q_values ~ real_q_values, data=F02_A2_L10_M005_no0)
reg20 <- lm(Structure_q_values ~ real_q_values, data=F02_A5_L10_M005_no0)
reg21 <- lm(Structure_q_values ~ real_q_values, data=F02_A10_L10_M005_no0)
reg22 <- lm(Structure_q_values ~ real_q_values, data=F02_A2_L30_M005_no0)
reg23 <- lm(Structure_q_values ~ real_q_values, data=F02_A5_L30_M005_no0)
reg24 <- lm(Structure_q_values ~ real_q_values, data=F02_A10_L30_M005_no0)
reg25 <- lm(Structure_q_values ~ real_q_values, data=F02_A2_L100_M005_no0)
reg26 <- lm(Structure_q_values ~ real_q_values, data=F02_A5_L100_M005_no0)
reg27 <- lm(Structure_q_values ~ real_q_values, data=F02_A10_L100_M005_no0)

par(mfrow=c(3,3))
qqnorm(residuals(reg19)); qqline(residuals(reg19))
qqnorm(residuals(reg20)); qqline(residuals(reg20))
qqnorm(residuals(reg21)); qqline(residuals(reg21))
qqnorm(residuals(reg22)); qqline(residuals(reg22))
qqnorm(residuals(reg23)); qqline(residuals(reg23))
qqnorm(residuals(reg24)); qqline(residuals(reg24))
qqnorm(residuals(reg25)); qqline(residuals(reg25))
qqnorm(residuals(reg26)); qqline(residuals(reg26))
qqnorm(residuals(reg27)); qqline(residuals(reg27))

summary(reg24)
summary(reg25)
summary(reg26)
summary(reg27)

summary(reg23)


#nine plots fst 0.2, m 0.01 ----
p28 <- ggplot(data= F02_A2_L10_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F02_A2_L10_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue") 
p29 <- ggplot(data= F02_A5_L10_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F02_A5_L10_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p30 <- ggplot(data= F02_A10_L10_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F02_A10_L10_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p31<- ggplot(data= F02_A2_L30_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F02_A2_L30_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p32 <- ggplot(data= F02_A5_L30_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F02_A5_L30_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p33 <- ggplot(data= F02_A10_L30_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F02_A10_L30_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p34 <- ggplot(data= F02_A2_L100_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F02_A2_L100_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p35 <- ggplot(data= F02_A5_L100_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F02_A5_L100_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p36 <- ggplot(data= F02_A10_L100_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F02_A10_L100_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="black") + geom_smooth(method=lm, color="red")

grid.arrange(p28, p29, p30, p31, p32, p33, p34, p35, p36, ncol=3, top = "Fst 0.2, m 0.01")

#Regression Fst 0.2 m 0.01 ----
reg28 <- lm(Structure_q_values ~ real_q_values, data=F02_A2_L10_M001_no0)
reg29 <- lm(Structure_q_values ~ real_q_values, data=F02_A5_L10_M001_no0)
reg30 <- lm(Structure_q_values ~ real_q_values, data=F02_A10_L10_M001_no0)
reg31 <- lm(Structure_q_values ~ real_q_values, data=F02_A2_L30_M001_no0)
reg32 <- lm(Structure_q_values ~ real_q_values, data=F02_A5_L30_M001_no0)
reg33 <- lm(Structure_q_values ~ real_q_values, data=F02_A10_L30_M001_no0)
reg34 <- lm(Structure_q_values ~ real_q_values, data=F02_A2_L100_M001_no0)
reg35 <- lm(Structure_q_values ~ real_q_values, data=F02_A5_L100_M001_no0)
reg36 <- lm(Structure_q_values ~ real_q_values, data=F02_A10_L100_M001_no0)

par(mfrow=c(3,3))
qqnorm(residuals(reg28)); qqline(residuals(reg28))
qqnorm(residuals(reg29)); qqline(residuals(reg29))
qqnorm(residuals(reg30)); qqline(residuals(reg30))
qqnorm(residuals(reg31)); qqline(residuals(reg31))
qqnorm(residuals(reg32)); qqline(residuals(reg32))
qqnorm(residuals(reg33)); qqline(residuals(reg33))
qqnorm(residuals(reg34)); qqline(residuals(reg34))
qqnorm(residuals(reg35)); qqline(residuals(reg35))
qqnorm(residuals(reg36)); qqline(residuals(reg36))

summary(reg36)


#nine plots fst 0.05, m 0.05 ----
p37 <- ggplot(data= F005_A2_L10_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F005_A2_L10_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue") 
p38 <- ggplot(data= F005_A5_L10_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F005_A5_L10_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p39 <- ggplot(data= F005_A10_L10_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F005_A10_L10_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p40<- ggplot(data= F005_A2_L30_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F005_A2_L30_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p41 <- ggplot(data= F005_A5_L30_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F005_A5_L30_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p42 <- ggplot(data= F005_A10_L30_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F005_A10_L30_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p43 <- ggplot(data= F005_A2_L100_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F005_A2_L100_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p44 <- ggplot(data= F005_A5_L100_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F005_A5_L100_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="black") + geom_smooth(method=lm, color="red")
p45 <- ggplot(data= F005_A10_L100_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F005_A10_L100_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="black") + geom_smooth(method=lm, color="orange")

grid.arrange(p37, p38, p39, p40, p41, p42, p43, p44, p45, ncol=3, top = "Fst 0.05, m 0.05")

#Regression Fst 0.05 m 0.05 ----
reg37 <- lm(Structure_q_values ~ real_q_values, data=F005_A2_L10_M005_no0)
reg38 <- lm(Structure_q_values ~ real_q_values, data=F005_A5_L10_M005_no0)
reg39 <- lm(Structure_q_values ~ real_q_values, data=F005_A10_L10_M005_no0)
reg40 <- lm(Structure_q_values ~ real_q_values, data=F005_A2_L30_M005_no0)
reg41 <- lm(Structure_q_values ~ real_q_values, data=F005_A5_L30_M005_no0)
reg42 <- lm(Structure_q_values ~ real_q_values, data=F005_A10_L30_M005_no0)
reg43 <- lm(Structure_q_values ~ real_q_values, data=F005_A2_L100_M005_no0)
reg44 <- lm(Structure_q_values ~ real_q_values, data=F005_A5_L100_M005_no0)
reg45 <- lm(Structure_q_values ~ real_q_values, data=F005_A10_L100_M005_no0)

par(mfrow=c(3,3))
qqnorm(residuals(reg37)); qqline(residuals(reg37))
qqnorm(residuals(reg38)); qqline(residuals(reg38))
qqnorm(residuals(reg39)); qqline(residuals(reg39))
qqnorm(residuals(reg40)); qqline(residuals(reg40))
qqnorm(residuals(reg41)); qqline(residuals(reg41))
qqnorm(residuals(reg42)); qqline(residuals(reg42))
qqnorm(residuals(reg43)); qqline(residuals(reg43))
qqnorm(residuals(reg44)); qqline(residuals(reg44))
qqnorm(residuals(reg45)); qqline(residuals(reg45))

summary(reg44)
summary(reg45)


#nine plots fst 0.05, m 0.01 ----
p46 <- ggplot(data= F005_A2_L10_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F005_A2_L10_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue") 
p47 <- ggplot(data= F005_A5_L10_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F005_A5_L10_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p48 <- ggplot(data= F005_A10_L10_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F005_A10_L10_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p49<- ggplot(data= F005_A2_L30_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F005_A2_L30_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p50 <- ggplot(data= F005_A5_L30_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F005_A5_L30_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p51 <- ggplot(data= F005_A10_L30_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F005_A10_L30_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p52 <- ggplot(data= F005_A2_L100_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F005_A2_L100_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p53 <- ggplot(data= F005_A5_L100_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F005_A5_L100_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")
p54 <- ggplot(data= F005_A10_L100_M001_no0, aes(x=real_q_values, y=Structure_q_values)) +
  labs(title = "F005_A10_L100_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="black") + geom_smooth(method=lm, color="red")


grid.arrange(p46, p47, p48, p49, p50, p51, p52, p53, p54, ncol=3, top = "Fst 0.05, m 0.01")

#Regression Fst 0.05 m 0.01 ----
reg46 <- lm(Structure_q_values ~ real_q_values, data=F005_A2_L10_M001_no0)
reg47 <- lm(Structure_q_values ~ real_q_values, data=F005_A5_L10_M001_no0)
reg48 <- lm(Structure_q_values ~ real_q_values, data=F005_A10_L10_M001_no0)
reg49 <- lm(Structure_q_values ~ real_q_values, data=F005_A2_L30_M001_no0)
reg50 <- lm(Structure_q_values ~ real_q_values, data=F005_A5_L30_M001_no0)
reg51 <- lm(Structure_q_values ~ real_q_values, data=F005_A10_L30_M001_no0)
reg52 <- lm(Structure_q_values ~ real_q_values, data=F005_A2_L100_M001_no0)
reg53 <- lm(Structure_q_values ~ real_q_values, data=F005_A5_L100_M001_no0)
reg54 <- lm(Structure_q_values ~ real_q_values, data=F005_A10_L100_M001_no0)

par(mfrow=c(3,3))
qqnorm(residuals(reg46)); qqline(residuals(reg46))
qqnorm(residuals(reg47)); qqline(residuals(reg47))
qqnorm(residuals(reg48)); qqline(residuals(reg48))
qqnorm(residuals(reg49)); qqline(residuals(reg49))
qqnorm(residuals(reg50)); qqline(residuals(reg50))
qqnorm(residuals(reg51)); qqline(residuals(reg51))
qqnorm(residuals(reg52)); qqline(residuals(reg52))
qqnorm(residuals(reg53)); qqline(residuals(reg53))
qqnorm(residuals(reg54)); qqline(residuals(reg54))

summary(reg54)

# final regression line graph -----
grid.arrange(p54, p44, p45, p18, p8, p9, p36, p26, p27, ncol = 3)
grid.arrange(p54, p44, p45, p18, p8, p9, p23, p24, p25, ncol = 3)
