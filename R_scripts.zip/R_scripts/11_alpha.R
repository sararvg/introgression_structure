### additional tests with the POPALPHAS option activated: load data, plots and models 

library(ggplot2)
library(gridExtra)
library(cowplot)

##load data ----
#alpha, 30 markers, 5 alleles, migration 1%, no ref
F01_A5_L30_M001_N200_alpha <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001_N200_alpha", alpha = "ON", reference = 0, popinfo = "OFF", read.table("Fst0.1_NAl5_NMar30_M0.01_N200_alpha", header=T, dec = "."))
F01_A5_L30_M001_N200_alpha <- cbind (qdif= F01_A5_L30_M001_N200_alpha$Structure_q_values - F01_A5_L30_M001_N200_alpha$real_q_values, F01_A5_L30_M001_N200_alpha)
F01_A5_L30_M001_N200_alpha$minimum_CI <- NULL
F01_A5_L30_M001_N200_alpha$maximum_CI <- NULL
F01_A5_L30_M001_N200_alpha_no0 <- top(F01_A5_L30_M001_N200_alpha, 100, 13, 7)

F01_A5_L30_M001 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001", alpha = "OFF", reference = 0, popinfo = "OFF", read.table("Fst0.1_NAl5_NMar30_M0.01_N200", header=T, dec = "."))
F01_A5_L30_M001 <- cbind (qdif= F01_A5_L30_M001$Structure_q_values - F01_A5_L30_M001$real_q_values, F01_A5_L30_M001)
F01_A5_L30_M001$minimum_CI <- NULL
F01_A5_L30_M001$maximum_CI <- NULL
F01_A5_L30_M001_no0 <- top(F01_A5_L30_M001, 100, 13, 7)

#alpha, 30 markers, 10 alleles, migration 1%, no ref
F01_A10_L30_M001_N200_alpha <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001_N200_alpha", alpha = "ON", reference = 0, popinfo = "OFF", read.table("Fst0.1_NAl10_NMar30_M0.01_N200_alpha", header=T, dec = "."))
F01_A10_L30_M001_N200_alpha <- cbind (qdif= F01_A10_L30_M001_N200_alpha$Structure_q_values - F01_A10_L30_M001_N200_alpha$real_q_values, F01_A10_L30_M001_N200_alpha)
F01_A10_L30_M001_N200_alpha$minimum_CI <- NULL
F01_A10_L30_M001_N200_alpha$maximum_CI <- NULL
F01_A10_L30_M001_N200_alpha_no0 <- top(F01_A10_L30_M001_N200_alpha, 100, 13, 7)

F01_A10_L30_M001 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001", alpha = "OFF", reference = 0, popinfo = "OFF", read.table("Fst0.1_NAl10_NMar30_M0.01_N200", header=T, dec = "."))
F01_A10_L30_M001 <- cbind (qdif= F01_A10_L30_M001$Structure_q_values - F01_A10_L30_M001$real_q_values, F01_A10_L30_M001)
F01_A10_L30_M001$minimum_CI <- NULL
F01_A10_L30_M001$maximum_CI <- NULL
F01_A10_L30_M001_no0 <- top(F01_A10_L30_M001, 100, 13, 7)

#alpha, 30 markers, 5 alleles, migration 5%, no ref
F01_A5_L30_M005_N200_alpha <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005_N200_alpha", alpha = "ON", reference = 0, popinfo = "OFF", read.table("Fst0.1_NAl5_NMar30_M0.05_N200_alpha", header=T, dec = "."))
F01_A5_L30_M005_N200_alpha <- cbind (qdif= F01_A5_L30_M005_N200_alpha$Structure_q_values - F01_A5_L30_M005_N200_alpha$real_q_values, F01_A5_L30_M005_N200_alpha)
F01_A5_L30_M005_N200_alpha$minimum_CI <- NULL
F01_A5_L30_M005_N200_alpha$maximum_CI <- NULL
F01_A5_L30_M005_N200_alpha_no0 <- top(F01_A5_L30_M005_N200_alpha, 100, 13, 7)

F01_A5_L30_M005 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005", alpha = "OFF", reference = 0, popinfo = "OFF", read.table("Fst0.1_NAl5_NMar30_M0.05_N200", header=T, dec = "."))
F01_A5_L30_M005 <- cbind (qdif= F01_A5_L30_M005$Structure_q_values - F01_A5_L30_M005$real_q_values, F01_A5_L30_M005)
F01_A5_L30_M005$minimum_CI <- NULL
F01_A5_L30_M005$maximum_CI <- NULL
F01_A5_L30_M005_no0 <- top(F01_A5_L30_M005, 100, 13, 7)

#alpha, 30 markers, 10 alleles, migration 5%, no ref
F01_A10_L30_M005_N200_alpha <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005_N200_alpha", alpha = "ON", reference = 0, popinfo = "OFF", read.table("Fst0.1_NAl10_NMar30_M0.05_N200_alpha", header=T, dec = "."))
F01_A10_L30_M005_N200_alpha <- cbind (qdif= F01_A10_L30_M005_N200_alpha$Structure_q_values - F01_A10_L30_M005_N200_alpha$real_q_values, F01_A10_L30_M005_N200_alpha)
F01_A10_L30_M005_N200_alpha$minimum_CI <- NULL
F01_A10_L30_M005_N200_alpha$maximum_CI <- NULL
F01_A10_L30_M005_N200_alpha_no0 <- top(F01_A10_L30_M005_N200_alpha, 100, 13, 7)

F01_A10_L30_M005 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005", alpha = "OFF", reference = 0, popinfo = "OFF", read.table("Fst0.1_NAl10_NMar30_M0.05_N200", header=T, dec = "."))
F01_A10_L30_M005 <- cbind (qdif= F01_A10_L30_M005$Structure_q_values - F01_A10_L30_M005$real_q_values, F01_A10_L30_M005)
F01_A10_L30_M005$minimum_CI <- NULL
F01_A10_L30_M005$maximum_CI <- NULL
F01_A10_L30_M005_no0 <- top(F01_A10_L30_M005, 100, 13, 7)

F01_noref <- rbind(F01_A5_L30_M001_N200_alpha, F01_A5_L30_M001, F01_A10_L30_M001_N200_alpha, F01_A10_L30_M001, 
                   F01_A5_L30_M005_N200_alpha, F01_A5_L30_M005, F01_A10_L30_M005_N200_alpha, F01_A10_L30_M005)

F01_M005_noref <- rbind(F01_A5_L30_M005_N200_alpha, F01_A5_L30_M005, F01_A10_L30_M005_N200_alpha, F01_A10_L30_M005)
F01_M005_noref_no0 <- rbind(F01_A5_L30_M005_N200_alpha_no0, F01_A5_L30_M005_no0, F01_A10_L30_M005_N200_alpha_no0, F01_A10_L30_M005_no0)

F01_M001_noref <- rbind(F01_A5_L30_M001_N200_alpha, F01_A5_L30_M001, F01_A10_L30_M001_N200_alpha, F01_A10_L30_M001)
F01_M001_noref_no0 <- rbind(F01_A5_L30_M001_N200_alpha_no0, F01_A5_L30_M001_no0, F01_A10_L30_M001_N200_alpha_no0, F01_A10_L30_M001_no0)


#alpha reference 10% ----
#alpha, 30 markers, 5 alleles, migration 1%, ref 10%
F01_A5_L30_M001_N200_ref10_alpha <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001_N200_ref10_alpha", alpha = "ON", reference = 0.10, popinfo = "OFF", read.table("Fst0.1_NAl5_NMar30_M0.01_N200_ref10_alpha", header=T, dec = "."))
F01_A5_L30_M001_N200_ref10_alpha <- cbind (qdif= F01_A5_L30_M001_N200_ref10_alpha$Structure_q_values - F01_A5_L30_M001_N200_ref10_alpha$real_q_values, F01_A5_L30_M001_N200_ref10_alpha)
F01_A5_L30_M001_N200_ref10_alpha$minimum_CI <- NULL
F01_A5_L30_M001_N200_ref10_alpha$maximum_CI <- NULL
F01_A5_L30_M001_N200_ref10_alpha_no0 <- top(F01_A5_L30_M001_N200_ref10_alpha, 100, 13, 7)
F01_A5_L30_M001_N200_ref10_alpha_no0_no1 <- top2(F01_A5_L30_M001_N200_ref10_alpha, 90, 13, 7)

F01_A5_L30_M001_N200_ref10 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001_N200_ref10", alpha = "OFF", reference = 0.10, popinfo = "OFF", read.table("Fst0.1_NAl5_NMar30_M0.01_N200_reference_10", header=T, dec = "."))
F01_A5_L30_M001_N200_ref10 <- cbind (qdif= F01_A5_L30_M001_N200_ref10$Structure_q_values - F01_A5_L30_M001_N200_ref10$real_q_values, F01_A5_L30_M001_N200_ref10)
F01_A5_L30_M001_N200_ref10$minimum_CI <- NULL
F01_A5_L30_M001_N200_ref10$maximum_CI <- NULL
F01_A5_L30_M001_N200_ref10_no0 <- top(F01_A5_L30_M001_N200_ref10, 100, 13, 7)
F01_A5_L30_M001_N200_ref10_no0_no1 <- top2(F01_A5_L30_M001_N200_ref10, 90, 13, 7)

#alpha, 30 markers, 10 alleles, migration 1%, ref 10%
F01_A10_L30_M001_N200_ref10_alpha <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001_N200_ref10_alpha", alpha = "ON", reference = 0.10, popinfo = "OFF", read.table("Fst0.1_NAl10_NMar30_M0.01_N200_ref10_alpha", header=T, dec = "."))
F01_A10_L30_M001_N200_ref10_alpha <- cbind (qdif= F01_A10_L30_M001_N200_ref10_alpha$Structure_q_values - F01_A10_L30_M001_N200_ref10_alpha$real_q_values, F01_A10_L30_M001_N200_ref10_alpha)
F01_A10_L30_M001_N200_ref10_alpha$minimum_CI <- NULL
F01_A10_L30_M001_N200_ref10_alpha$maximum_CI <- NULL
F01_A10_L30_M001_N200_ref10_alpha_no0 <- top(F01_A10_L30_M001_N200_ref10_alpha, 100, 13, 7)
F01_A10_L30_M001_N200_ref10_alpha_no0_no1 <- top2(F01_A10_L30_M001_N200_ref10_alpha, 90, 13, 7)

F01_A10_L30_M001_N200_ref10 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001_N200_ref10", alpha = "OFF", reference = 0.10, popinfo = "OFF", read.table("Fst0.1_NAl10_NMar30_M0.01_N200_reference_10", header=T, dec = "."))
F01_A10_L30_M001_N200_ref10 <- cbind (qdif= F01_A10_L30_M001_N200_ref10$Structure_q_values - F01_A10_L30_M001_N200_ref10$real_q_values, F01_A10_L30_M001_N200_ref10)
F01_A10_L30_M001_N200_ref10$minimum_CI <- NULL
F01_A10_L30_M001_N200_ref10$maximum_CI <- NULL
F01_A10_L30_M001_N200_ref10_no0 <- top(F01_A10_L30_M001_N200_ref10, 100, 13, 7)
F01_A10_L30_M001_N200_ref10_no0_no1 <- top2(F01_A10_L30_M001_N200_ref10, 90, 13, 7)

#alpha, 30 markers, 5 alleles, migration 5%, ref 10%
F01_A5_L30_M005_N200_ref10_alpha <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005_N200_ref10_alpha", alpha = "ON", reference = 0.10, popinfo = "OFF", read.table("Fst0.1_NAl5_NMar30_M0.05_N200_ref10_alpha", header=T, dec = "."))
F01_A5_L30_M005_N200_ref10_alpha <- cbind (qdif= F01_A5_L30_M005_N200_ref10_alpha$Structure_q_values - F01_A5_L30_M005_N200_ref10_alpha$real_q_values, F01_A5_L30_M005_N200_ref10_alpha)
F01_A5_L30_M005_N200_ref10_alpha$minimum_CI <- NULL
F01_A5_L30_M005_N200_ref10_alpha$maximum_CI <- NULL
F01_A5_L30_M005_N200_ref10_alpha_no0 <- top(F01_A5_L30_M005_N200_ref10_alpha, 100, 13, 7)
F01_A5_L30_M005_N200_ref10_alpha_no0_no1 <- top2(F01_A5_L30_M005_N200_ref10_alpha, 90, 13, 7)

F01_A5_L30_M005_N200_ref10 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005_N200_ref10", alpha = "OFF", reference = 0.10, popinfo = "OFF", read.table("Fst0.1_NAl5_NMar30_M0.05_N200_reference_10", header=T, dec = "."))
F01_A5_L30_M005_N200_ref10 <- cbind (qdif= F01_A5_L30_M005_N200_ref10$Structure_q_values - F01_A5_L30_M005_N200_ref10$real_q_values, F01_A5_L30_M005_N200_ref10)
F01_A5_L30_M005_N200_ref10$minimum_CI <- NULL
F01_A5_L30_M005_N200_ref10$maximum_CI <- NULL
F01_A5_L30_M005_N200_ref10_no0 <- top(F01_A5_L30_M005_N200_ref10, 100, 13, 7)
F01_A5_L30_M005_N200_ref10_no0_no1 <- top2(F01_A5_L30_M005_N200_ref10, 90, 13, 7)

#alpha, 30 markers, 10 alleles, migration 5%, ref 10%
F01_A10_L30_M005_N200_ref10_alpha <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005_N200_ref10_alpha", alpha = "ON", reference = 0.10, popinfo = "OFF", read.table("Fst0.1_NAl10_NMar30_M0.05_N200_ref10_alpha", header=T, dec = "."))
F01_A10_L30_M005_N200_ref10_alpha <- cbind (qdif= F01_A10_L30_M005_N200_ref10_alpha$Structure_q_values - F01_A10_L30_M005_N200_ref10_alpha$real_q_values, F01_A10_L30_M005_N200_ref10_alpha)
F01_A10_L30_M005_N200_ref10_alpha$minimum_CI <- NULL
F01_A10_L30_M005_N200_ref10_alpha$maximum_CI <- NULL
F01_A10_L30_M005_N200_ref10_alpha_no0 <- top(F01_A10_L30_M005_N200_ref10_alpha, 100, 13, 7)
F01_A10_L30_M005_N200_ref10_alpha_no0_no1 <- top2(F01_A10_L30_M005_N200_ref10_alpha, 90, 13, 7)

F01_A10_L30_M005_N200_ref10 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005_N200_ref10", alpha = "OFF", reference = 0.10, popinfo = "OFF", read.table("Fst0.1_NAl10_NMar30_M0.05_N200_reference_10", header=T, dec = "."))
F01_A10_L30_M005_N200_ref10 <- cbind (qdif= F01_A10_L30_M005_N200_ref10$Structure_q_values - F01_A10_L30_M005_N200_ref10$real_q_values, F01_A10_L30_M005_N200_ref10)
F01_A10_L30_M005_N200_ref10$minimum_CI <- NULL
F01_A10_L30_M005_N200_ref10$maximum_CI <- NULL
F01_A10_L30_M005_N200_ref10_no0 <- top(F01_A10_L30_M005_N200_ref10, 100, 13, 7)
F01_A10_L30_M005_N200_ref10_no0_no1 <- top2(F01_A10_L30_M005_N200_ref10, 90, 13, 7)

#alpha reference 10% popinfo----
#alpha, 30 markers, 5 alleles, migration 1%, ref 10%
F01_A5_L30_M001_N200_ref10_alpha_popinfo <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001_N200_ref10_alpha_popinfo", alpha = "ON", reference = 0.10, popinfo = "ON",read.table("Fst0.1_NAl5_NMar30_M0.01_N200_ref10_alpha_popinfo", header=T, dec = "."))
F01_A5_L30_M001_N200_ref10_alpha_popinfo <- cbind (qdif= F01_A5_L30_M001_N200_ref10_alpha_popinfo$Structure_q_values - F01_A5_L30_M001_N200_ref10_alpha_popinfo$real_q_values, F01_A5_L30_M001_N200_ref10_alpha_popinfo)
F01_A5_L30_M001_N200_ref10_alpha_popinfo_no0 <- top(F01_A5_L30_M001_N200_ref10_alpha_popinfo, 100, 13, 7)
F01_A5_L30_M001_N200_ref10_alpha_popinfo_no0_no1 <- top2(F01_A5_L30_M001_N200_ref10_alpha_popinfo, 90, 13, 7)

F01_A5_L30_M001_N200_ref10_popinfo <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001_N200_ref10_popinfo", alpha = "OFF", reference = 0.10, popinfo = "ON",read.table("Fst0.1_NAl5_NMar30_M0.01_N200_reference_10_popinfo", header=T, dec = "."))
F01_A5_L30_M001_N200_ref10_popinfo <- cbind (qdif= F01_A5_L30_M001_N200_ref10_popinfo$Structure_q_values - F01_A5_L30_M001_N200_ref10_popinfo$real_q_values, F01_A5_L30_M001_N200_ref10_popinfo)
F01_A5_L30_M001_N200_ref10_popinfo_no0 <- top(F01_A5_L30_M001_N200_ref10_popinfo, 100, 13, 7)
F01_A5_L30_M001_N200_ref10_popinfo_no0_no1 <- top2(F01_A5_L30_M001_N200_ref10_popinfo, 90, 13, 7)

#alpha, 30 markers, 10 alleles, migration 1%, ref 10%
F01_A10_L30_M001_N200_ref10_alpha_popinfo <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001_N200_ref10_alpha_popinfo", alpha = "ON", reference = 0.10, popinfo = "ON", read.table("Fst0.1_NAl10_NMar30_M0.01_N200_ref10_alpha_popinfo", header=T, dec = "."))
F01_A10_L30_M001_N200_ref10_alpha_popinfo <- cbind (qdif= F01_A10_L30_M001_N200_ref10_alpha_popinfo$Structure_q_values - F01_A10_L30_M001_N200_ref10_alpha_popinfo$real_q_values, F01_A10_L30_M001_N200_ref10_alpha_popinfo)
F01_A10_L30_M001_N200_ref10_alpha_popinfo_no0 <- top(F01_A10_L30_M001_N200_ref10_alpha_popinfo, 100, 13, 7)
F01_A10_L30_M001_N200_ref10_alpha_popinfo_no0_no1 <- top2(F01_A10_L30_M001_N200_ref10_alpha_popinfo, 90, 13, 7)

F01_A10_L30_M001_N200_ref10_popinfo <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001_N200_ref10_popinfo", alpha = "OFF", reference = 0.10, popinfo = "ON", read.table("Fst0.1_NAl10_NMar30_M0.01_N200_reference_10_popinfo", header=T, dec = "."))
F01_A10_L30_M001_N200_ref10_popinfo <- cbind (qdif= F01_A10_L30_M001_N200_ref10_popinfo$Structure_q_values - F01_A10_L30_M001_N200_ref10_popinfo$real_q_values, F01_A10_L30_M001_N200_ref10_popinfo)
F01_A10_L30_M001_N200_ref10_popinfo_no0 <- top(F01_A10_L30_M001_N200_ref10_popinfo, 100, 13, 7)
F01_A10_L30_M001_N200_ref10_popinfo_no0_no1 <- top2(F01_A10_L30_M001_N200_ref10_popinfo, 90, 13, 7)

#alpha, 30 markers, 5 alleles, migration 5%, ref 10%
F01_A5_L30_M005_N200_ref10_alpha_popinfo <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005_N200_ref10_alpha_popinfo",alpha = "ON", reference = 0.10, popinfo = "ON", read.table("Fst0.1_NAl5_NMar30_M0.05_N200_ref10_alpha_popinfo", header=T, dec = "."))
F01_A5_L30_M005_N200_ref10_alpha_popinfo <- cbind (qdif= F01_A5_L30_M005_N200_ref10_alpha_popinfo$Structure_q_values - F01_A5_L30_M005_N200_ref10_alpha_popinfo$real_q_values, F01_A5_L30_M005_N200_ref10_alpha_popinfo)
F01_A5_L30_M005_N200_ref10_alpha_popinfo_no0 <- top(F01_A5_L30_M005_N200_ref10_alpha_popinfo, 100, 13, 7)
F01_A5_L30_M005_N200_ref10_alpha_popinfo_no0_no1 <- top2(F01_A5_L30_M005_N200_ref10_alpha_popinfo, 90, 13, 7)

F01_A5_L30_M005_N200_ref10_popinfo <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005_N200_ref10_popinfo",alpha = "OFF", reference = 0.10, popinfo = "ON", read.table("Fst0.1_NAl5_NMar30_M0.05_N200_reference_10_popinfo", header=T, dec = "."))
F01_A5_L30_M005_N200_ref10_popinfo <- cbind (qdif= F01_A5_L30_M005_N200_ref10_popinfo$Structure_q_values - F01_A5_L30_M005_N200_ref10_popinfo$real_q_values, F01_A5_L30_M005_N200_ref10_popinfo)
F01_A5_L30_M005_N200_ref10_popinfo_no0 <- top(F01_A5_L30_M005_N200_ref10_popinfo, 100, 13, 7)
F01_A5_L30_M005_N200_ref10_popinfo_no0_no1 <- top2(F01_A5_L30_M005_N200_ref10_popinfo, 90, 13, 7)

#alpha, 30 markers, 10 alleles, migration 5%, ref 10%
F01_A10_L30_M005_N200_ref10_alpha_popinfo <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005_N200_ref10_alpha_popinfo", alpha = "ON", reference = 0.10, popinfo = "ON", read.table("Fst0.1_NAl10_NMar30_M0.05_N200_ref10_alpha_popinfo", header=T, dec = "."))
F01_A10_L30_M005_N200_ref10_alpha_popinfo <- cbind (qdif= F01_A10_L30_M005_N200_ref10_alpha_popinfo$Structure_q_values - F01_A10_L30_M005_N200_ref10_alpha_popinfo$real_q_values, F01_A10_L30_M005_N200_ref10_alpha_popinfo)
F01_A10_L30_M005_N200_ref10_alpha_popinfo_no0 <- top(F01_A10_L30_M005_N200_ref10_alpha_popinfo, 100, 13, 7)
F01_A10_L30_M005_N200_ref10_alpha_popinfo_no0_no1 <- top2(F01_A10_L30_M005_N200_ref10_alpha_popinfo, 90, 13, 7)

F01_A10_L30_M005_N200_ref10_popinfo <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005_N200_ref10_popinfo", alpha = "OFF", reference = 0.10, popinfo = "ON", read.table("Fst0.1_NAl10_NMar30_M0.05_N200_reference_10_popinfo", header=T, dec = "."))
F01_A10_L30_M005_N200_ref10_popinfo <- cbind (qdif= F01_A10_L30_M005_N200_ref10_popinfo$Structure_q_values - F01_A10_L30_M005_N200_ref10_popinfo$real_q_values, F01_A10_L30_M005_N200_ref10_popinfo)
F01_A10_L30_M005_N200_ref10_popinfo_no0 <- top(F01_A10_L30_M005_N200_ref10_popinfo, 100, 13, 7)
F01_A10_L30_M005_N200_ref10_popinfo_no0_no1 <- top2(F01_A10_L30_M005_N200_ref10_popinfo, 90, 13, 7)

F01_ref10 <- rbind(F01_A5_L30_M001_N200_ref10_alpha, F01_A5_L30_M001_N200_ref10, F01_A5_L30_M001_N200_ref10_alpha_popinfo, F01_A5_L30_M001_N200_ref10_popinfo,  
                   F01_A5_L30_M005_N200_ref10_alpha, F01_A5_L30_M005_N200_ref10, F01_A5_L30_M005_N200_ref10_alpha_popinfo, F01_A5_L30_M005_N200_ref10_popinfo,
                   F01_A10_L30_M001_N200_ref10_alpha, F01_A10_L30_M001_N200_ref10, F01_A10_L30_M001_N200_ref10_alpha_popinfo, F01_A10_L30_M001_N200_ref10_popinfo,  
                   F01_A10_L30_M005_N200_ref10_alpha, F01_A10_L30_M005_N200_ref10, F01_A10_L30_M005_N200_ref10_alpha_popinfo, F01_A10_L30_M005_N200_ref10_popinfo)

F01_M005_ref10 <- rbind(F01_A5_L30_M005_N200_ref10_alpha, F01_A5_L30_M005_N200_ref10, F01_A5_L30_M005_N200_ref10_alpha_popinfo, F01_A5_L30_M005_N200_ref10_popinfo,  
                        F01_A10_L30_M005_N200_ref10_alpha, F01_A10_L30_M005_N200_ref10, F01_A10_L30_M005_N200_ref10_alpha_popinfo, F01_A10_L30_M005_N200_ref10_popinfo)
F01_M005_ref10_no0_no1 <- rbind(F01_A5_L30_M005_N200_ref10_alpha_no0_no1, F01_A5_L30_M005_N200_ref10_no0_no1, F01_A5_L30_M005_N200_ref10_alpha_popinfo_no0_no1, F01_A5_L30_M005_N200_ref10_popinfo_no0_no1,  
                                F01_A10_L30_M005_N200_ref10_alpha_no0_no1, F01_A10_L30_M005_N200_ref10_no0_no1, F01_A10_L30_M005_N200_ref10_alpha_popinfo_no0_no1, F01_A10_L30_M005_N200_ref10_popinfo_no0_no1)

F01_M001_ref10 <- rbind(F01_A5_L30_M001_N200_ref10_alpha, F01_A5_L30_M001_N200_ref10, F01_A5_L30_M001_N200_ref10_alpha_popinfo, F01_A5_L30_M001_N200_ref10_popinfo,
                        F01_A10_L30_M001_N200_ref10_alpha, F01_A10_L30_M001_N200_ref10, F01_A10_L30_M001_N200_ref10_alpha_popinfo, F01_A10_L30_M001_N200_ref10_popinfo)
F01_M001_ref10_no0_no1 <- rbind(F01_A5_L30_M001_N200_ref10_alpha_no0_no1, F01_A5_L30_M001_N200_ref10_no0_no1, F01_A5_L30_M001_N200_ref10_alpha_popinfo_no0_no1, F01_A5_L30_M001_N200_ref10_popinfo_no0_no1,
                                F01_A10_L30_M001_N200_ref10_alpha_no0_no1, F01_A10_L30_M001_N200_ref10_no0_no1, F01_A10_L30_M001_N200_ref10_alpha_popinfo_no0_no1, F01_A10_L30_M001_N200_ref10_popinfo_no0_no1)


#alpha reference 30% ----
#alpha, 30 markers, 5 alleles, migration 1%, ref 30%
F01_A5_L30_M001_N200_ref30_alpha <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001_N200_ref30_alpha", alpha = "ON", reference = 0.30, popinfo = "OFF", read.table("Fst0.1_NAl5_NMar30_M0.01_N200_ref30_alpha", header=T, dec = "."))
F01_A5_L30_M001_N200_ref30_alpha <- cbind (qdif= F01_A5_L30_M001_N200_ref30_alpha$Structure_q_values - F01_A5_L30_M001_N200_ref30_alpha$real_q_values, F01_A5_L30_M001_N200_ref30_alpha)
F01_A5_L30_M001_N200_ref30_alpha$minimum_CI <- NULL
F01_A5_L30_M001_N200_ref30_alpha$maximum_CI <- NULL
F01_A5_L30_M001_N200_ref30_alpha_no0 <- top(F01_A5_L30_M001_N200_ref30_alpha, 100, 13, 7)
F01_A5_L30_M001_N200_ref30_alpha_no0_no1 <- top2(F01_A5_L30_M001_N200_ref30_alpha, 70, 13, 7)

F01_A5_L30_M001_N200_ref30 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001_N200_ref30", alpha = "OFF", reference = 0.30, popinfo = "OFF", read.table("Fst0.1_NAl5_NMar30_M0.01_N200_reference", header=T, dec = "."))
F01_A5_L30_M001_N200_ref30 <- cbind (qdif= F01_A5_L30_M001_N200_ref30$Structure_q_values - F01_A5_L30_M001_N200_ref30$real_q_values, F01_A5_L30_M001_N200_ref30)
F01_A5_L30_M001_N200_ref30$minimum_CI <- NULL
F01_A5_L30_M001_N200_ref30$maximum_CI <- NULL
F01_A5_L30_M001_N200_ref30_no0 <- top(F01_A5_L30_M001_N200_ref30, 100, 13, 7)
F01_A5_L30_M001_N200_ref30_no0_no1 <- top2(F01_A5_L30_M001_N200_ref30, 70, 13, 7)

#alpha, 30 markers, 10 alleles, migration 1%, ref 30%
F01_A10_L30_M001_N200_ref30_alpha <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001_N200_ref30_alpha", alpha = "ON", reference = 0.30, popinfo = "OFF", read.table("Fst0.1_NAl10_NMar30_M0.01_N200_ref30_alpha", header=T, dec = "."))
F01_A10_L30_M001_N200_ref30_alpha <- cbind (qdif= F01_A10_L30_M001_N200_ref30_alpha$Structure_q_values - F01_A10_L30_M001_N200_ref30_alpha$real_q_values, F01_A10_L30_M001_N200_ref30_alpha)
F01_A10_L30_M001_N200_ref30_alpha$minimum_CI <- NULL
F01_A10_L30_M001_N200_ref30_alpha$maximum_CI <- NULL
F01_A10_L30_M001_N200_ref30_alpha_no0 <- top(F01_A10_L30_M001_N200_ref30_alpha, 100, 13, 7)
F01_A10_L30_M001_N200_ref30_alpha_no0_no1 <- top2(F01_A10_L30_M001_N200_ref30_alpha, 70, 13, 7)

F01_A10_L30_M001_N200_ref30 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001_N200_ref30", alpha = "OFF", reference = 0.30, popinfo = "OFF", read.table("Fst0.1_NAl10_NMar30_M0.01_N200_reference", header=T, dec = "."))
F01_A10_L30_M001_N200_ref30 <- cbind (qdif= F01_A10_L30_M001_N200_ref30$Structure_q_values - F01_A10_L30_M001_N200_ref30$real_q_values, F01_A10_L30_M001_N200_ref30)
F01_A10_L30_M001_N200_ref30$minimum_CI <- NULL
F01_A10_L30_M001_N200_ref30$maximum_CI <- NULL
F01_A10_L30_M001_N200_ref30_no0 <- top(F01_A10_L30_M001_N200_ref30, 100, 13, 7)
F01_A10_L30_M001_N200_ref30_no0_no1 <- top2(F01_A10_L30_M001_N200_ref30, 70, 13, 7)

#alpha, 30 markers, 5 alleles, migration 5%, ref 30%
F01_A5_L30_M005_N200_ref30_alpha <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005_N200_ref30_alpha", alpha = "ON", reference = 0.30, popinfo = "OFF", read.table("Fst0.1_NAl5_NMar30_M0.05_N200_ref30_alpha", header=T, dec = "."))
F01_A5_L30_M005_N200_ref30_alpha <- cbind (qdif= F01_A5_L30_M005_N200_ref30_alpha$Structure_q_values - F01_A5_L30_M005_N200_ref30_alpha$real_q_values, F01_A5_L30_M005_N200_ref30_alpha)
F01_A5_L30_M005_N200_ref30_alpha$minimum_CI <- NULL
F01_A5_L30_M005_N200_ref30_alpha$maximum_CI <- NULL
F01_A5_L30_M005_N200_ref30_alpha_no0 <- top(F01_A5_L30_M005_N200_ref30_alpha, 100, 13, 7)
F01_A5_L30_M005_N200_ref30_alpha_no0_no1 <- top2(F01_A5_L30_M005_N200_ref30_alpha, 70, 13, 7)

F01_A5_L30_M005_N200_ref30 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005_N200_ref30", alpha = "OFF", reference = 0.30, popinfo = "OFF", read.table("Fst0.1_NAl5_NMar30_M0.05_N200_reference", header=T, dec = "."))
F01_A5_L30_M005_N200_ref30 <- cbind (qdif= F01_A5_L30_M005_N200_ref30$Structure_q_values - F01_A5_L30_M005_N200_ref30$real_q_values, F01_A5_L30_M005_N200_ref30)
F01_A5_L30_M005_N200_ref30$minimum_CI <- NULL
F01_A5_L30_M005_N200_ref30$maximum_CI <- NULL
F01_A5_L30_M005_N200_ref30_no0 <- top(F01_A5_L30_M005_N200_ref30, 100, 13, 7)
F01_A5_L30_M005_N200_ref30_no0_no1 <- top2(F01_A5_L30_M005_N200_ref30, 70, 13, 7)

#alpha, 30 markers, 10 alleles, migration 5%, ref 30%
F01_A10_L30_M005_N200_ref30_alpha <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005_N200_ref30_alpha", alpha = "ON", reference = 0.30, popinfo = "OFF", read.table("Fst0.1_NAl10_NMar30_M0.05_N200_ref30_alpha", header=T, dec = "."))
F01_A10_L30_M005_N200_ref30_alpha <- cbind (qdif= F01_A10_L30_M005_N200_ref30_alpha$Structure_q_values - F01_A10_L30_M005_N200_ref30_alpha$real_q_values, F01_A10_L30_M005_N200_ref30_alpha)
F01_A10_L30_M005_N200_ref30_alpha$minimum_CI <- NULL
F01_A10_L30_M005_N200_ref30_alpha$maximum_CI <- NULL
F01_A10_L30_M005_N200_ref30_alpha_no0 <- top(F01_A10_L30_M005_N200_ref30_alpha, 100, 13, 7)
F01_A10_L30_M005_N200_ref30_alpha_no0_no1 <- top2(F01_A10_L30_M005_N200_ref30_alpha, 70, 13, 7)

F01_A10_L30_M005_N200_ref30 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005_N200_ref30", alpha = "OFF", reference = 0.30, popinfo = "OFF", read.table("Fst0.1_NAl10_NMar30_M0.05_N200_reference", header=T, dec = "."))
F01_A10_L30_M005_N200_ref30 <- cbind (qdif= F01_A10_L30_M005_N200_ref30$Structure_q_values - F01_A10_L30_M005_N200_ref30$real_q_values, F01_A10_L30_M005_N200_ref30)
F01_A10_L30_M005_N200_ref30$minimum_CI <- NULL
F01_A10_L30_M005_N200_ref30$maximum_CI <- NULL
F01_A10_L30_M005_N200_ref30_no0 <- top(F01_A10_L30_M005_N200_ref30, 100, 13, 7)
F01_A10_L30_M005_N200_ref30_no0_no1 <- top2(F01_A10_L30_M005_N200_ref30, 70, 13, 7)

#alpha reference 30% popinfo----
#alpha, 30 markers, 5 alleles, migration 1%, ref 30%
F01_A5_L30_M001_N200_ref30_alpha_popinfo <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001_N200_ref30_alpha_popinfo", alpha = "ON", reference = 0.30, popinfo = "ON", read.table("Fst0.1_NAl5_NMar30_M0.01_N200_ref30_alpha_popinfo", header=T, dec = "."))
F01_A5_L30_M001_N200_ref30_alpha_popinfo <- cbind (qdif= F01_A5_L30_M001_N200_ref30_alpha_popinfo$Structure_q_values - F01_A5_L30_M001_N200_ref30_alpha_popinfo$real_q_values, F01_A5_L30_M001_N200_ref30_alpha_popinfo)
F01_A5_L30_M001_N200_ref30_alpha_popinfo_no0 <- top(F01_A5_L30_M001_N200_ref30_alpha_popinfo, 100, 13, 7)
F01_A5_L30_M001_N200_ref30_alpha_popinfo_no0_no1 <- top2(F01_A5_L30_M001_N200_ref30_alpha_popinfo, 70, 13, 7)

F01_A5_L30_M001_N200_ref30_popinfo <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001_N200_ref30_popinfo", alpha = "OFF", reference = 0.30, popinfo = "ON", read.table("Fst0.1_NAl5_NMar30_M0.01_N200_reference_30_popinfo", header=T, dec = "."))
F01_A5_L30_M001_N200_ref30_popinfo <- cbind (qdif= F01_A5_L30_M001_N200_ref30_popinfo$Structure_q_values - F01_A5_L30_M001_N200_ref30_popinfo$real_q_values, F01_A5_L30_M001_N200_ref30_popinfo)
F01_A5_L30_M001_N200_ref30_popinfo_no0 <- top(F01_A5_L30_M001_N200_ref30_popinfo, 100, 13, 7)
F01_A5_L30_M001_N200_ref30_popinfo_no0_no1 <- top2(F01_A5_L30_M001_N200_ref30_popinfo, 70, 13, 7)

#alpha, 30 markers, 10 alleles, migration 1%, ref 30%
F01_A10_L30_M001_N200_ref30_alpha_popinfo <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001_N200_ref30_alpha_popinfo", alpha = "ON", reference = 0.30, popinfo = "ON", read.table("Fst0.1_NAl10_NMar30_M0.01_N200_ref30_alpha_popinfo", header=T, dec = "."))
F01_A10_L30_M001_N200_ref30_alpha_popinfo <- cbind (qdif= F01_A10_L30_M001_N200_ref30_alpha_popinfo$Structure_q_values - F01_A10_L30_M001_N200_ref30_alpha_popinfo$real_q_values, F01_A10_L30_M001_N200_ref30_alpha_popinfo)
F01_A10_L30_M001_N200_ref30_alpha_popinfo_no0 <- top(F01_A10_L30_M001_N200_ref30_alpha_popinfo, 100, 13, 7)
F01_A10_L30_M001_N200_ref30_alpha_popinfo_no0_no1 <- top2(F01_A10_L30_M001_N200_ref30_alpha_popinfo, 70, 13, 7)

F01_A10_L30_M001_N200_ref30_popinfo <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001_N200_ref30_popinfo", alpha = "OFF", reference = 0.30, popinfo = "ON", read.table("Fst0.1_NAl10_NMar30_M0.01_N200_reference_30_popinfo", header=T, dec = "."))
F01_A10_L30_M001_N200_ref30_popinfo <- cbind (qdif= F01_A10_L30_M001_N200_ref30_popinfo$Structure_q_values - F01_A10_L30_M001_N200_ref30_popinfo$real_q_values, F01_A10_L30_M001_N200_ref30_popinfo)
F01_A10_L30_M001_N200_ref30_popinfo_no0 <- top(F01_A10_L30_M001_N200_ref30_popinfo, 100, 13, 7)
F01_A10_L30_M001_N200_ref30_popinfo_no0_no1 <- top2(F01_A10_L30_M001_N200_ref30_popinfo, 70, 13, 7)

#alpha, 30 markers, 5 alleles, migration 5%, ref 30%
F01_A5_L30_M005_N200_ref30_alpha_popinfo <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005_N200_ref30_alpha_popinfo", alpha = "ON", reference = 0.30, popinfo = "ON", read.table("Fst0.1_NAl5_NMar30_M0.05_N200_ref30_alpha_popinfo", header=T, dec = "."))
F01_A5_L30_M005_N200_ref30_alpha_popinfo <- cbind (qdif= F01_A5_L30_M005_N200_ref30_alpha_popinfo$Structure_q_values - F01_A5_L30_M005_N200_ref30_alpha_popinfo$real_q_values, F01_A5_L30_M005_N200_ref30_alpha_popinfo)
F01_A5_L30_M005_N200_ref30_alpha_popinfo_no0 <- top(F01_A5_L30_M005_N200_ref30_alpha_popinfo, 100, 13, 7)
F01_A5_L30_M005_N200_ref30_alpha_popinfo_no0_no1 <- top2(F01_A5_L30_M005_N200_ref30_alpha_popinfo, 70, 13, 7)

F01_A5_L30_M005_N200_ref30_popinfo <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005_N200_ref30_popinfo", alpha = "OFF", reference = 0.30, popinfo = "ON", read.table("Fst0.1_NAl5_NMar30_M0.05_N200_reference_30_popinfo", header=T, dec = "."))
F01_A5_L30_M005_N200_ref30_popinfo <- cbind (qdif= F01_A5_L30_M005_N200_ref30_popinfo$Structure_q_values - F01_A5_L30_M005_N200_ref30_popinfo$real_q_values, F01_A5_L30_M005_N200_ref30_popinfo)
F01_A5_L30_M005_N200_ref30_popinfo_no0 <- top(F01_A5_L30_M005_N200_ref30_popinfo, 100, 13, 7)
F01_A5_L30_M005_N200_ref30_popinfo_no0_no1 <- top2(F01_A5_L30_M005_N200_ref30_popinfo, 70, 13, 7)

#alpha, 30 markers, 10 alleles, migration 5%, ref 30%
F01_A10_L30_M005_N200_ref30_alpha_popinfo <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005_N200_ref30_alpha_popinfo", alpha = "ON", reference = 0.30, popinfo = "ON", read.table("Fst0.1_NAl10_NMar30_M0.05_N200_ref30_alpha_popinfo", header=T, dec = "."))
F01_A10_L30_M005_N200_ref30_alpha_popinfo <- cbind (qdif= F01_A10_L30_M005_N200_ref30_alpha_popinfo$Structure_q_values - F01_A10_L30_M005_N200_ref30_alpha_popinfo$real_q_values, F01_A10_L30_M005_N200_ref30_alpha_popinfo)
F01_A10_L30_M005_N200_ref30_alpha_popinfo_no0 <- top(F01_A10_L30_M005_N200_ref30_alpha_popinfo, 100, 13, 7)
F01_A10_L30_M005_N200_ref30_alpha_popinfo_no0_no1 <- top2(F01_A10_L30_M005_N200_ref30_alpha_popinfo, 70, 13, 7)

F01_A10_L30_M005_N200_ref30_popinfo <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005_N200_ref30_popinfo", alpha = "OFF", reference = 0.30, popinfo = "ON", read.table("Fst0.1_NAl10_NMar30_M0.05_N200_reference_30_popinfo", header=T, dec = "."))
F01_A10_L30_M005_N200_ref30_popinfo <- cbind (qdif= F01_A10_L30_M005_N200_ref30_popinfo$Structure_q_values - F01_A10_L30_M005_N200_ref30_popinfo$real_q_values, F01_A10_L30_M005_N200_ref30_popinfo)
F01_A10_L30_M005_N200_ref30_popinfo_no0 <- top(F01_A10_L30_M005_N200_ref30_popinfo, 100, 13, 7)
F01_A10_L30_M005_N200_ref30_popinfo_no0_no1 <- top2(F01_A10_L30_M005_N200_ref30_popinfo, 70, 13, 7)


F01_ref30 <- rbind(F01_A5_L30_M001_N200_ref30_alpha, F01_A5_L30_M001_N200_ref30, F01_A5_L30_M001_N200_ref30_alpha_popinfo, F01_A5_L30_M001_N200_ref30_popinfo,  
                   F01_A5_L30_M005_N200_ref30_alpha, F01_A5_L30_M005_N200_ref30, F01_A5_L30_M005_N200_ref30_alpha_popinfo, F01_A5_L30_M005_N200_ref30_popinfo,
                   F01_A10_L30_M001_N200_ref30_alpha, F01_A10_L30_M001_N200_ref30, F01_A10_L30_M001_N200_ref30_alpha_popinfo, F01_A10_L30_M001_N200_ref30_popinfo,  
                   F01_A10_L30_M005_N200_ref30_alpha, F01_A10_L30_M005_N200_ref30, F01_A10_L30_M005_N200_ref30_alpha_popinfo, F01_A10_L30_M005_N200_ref30_popinfo)

F01_M005_ref30 <- rbind(F01_A5_L30_M005_N200_ref30_alpha, F01_A5_L30_M005_N200_ref30, F01_A5_L30_M005_N200_ref30_alpha_popinfo, F01_A5_L30_M005_N200_ref30_popinfo,
                        F01_A10_L30_M005_N200_ref30_alpha, F01_A10_L30_M005_N200_ref30, F01_A10_L30_M005_N200_ref30_alpha_popinfo, F01_A10_L30_M005_N200_ref30_popinfo)
F01_M005_ref30_no0_no1 <- rbind(F01_A5_L30_M005_N200_ref30_alpha_no0_no1, F01_A5_L30_M005_N200_ref30_no0_no1, F01_A5_L30_M005_N200_ref30_alpha_popinfo_no0_no1, F01_A5_L30_M005_N200_ref30_popinfo_no0_no1,
                                F01_A10_L30_M005_N200_ref30_alpha_no0_no1, F01_A10_L30_M005_N200_ref30_no0_no1, F01_A10_L30_M005_N200_ref30_alpha_popinfo_no0_no1, F01_A10_L30_M005_N200_ref30_popinfo_no0_no1)

F01_M001_ref30 <- rbind(F01_A5_L30_M001_N200_ref30_alpha, F01_A5_L30_M001_N200_ref30, F01_A5_L30_M001_N200_ref30_alpha_popinfo, F01_A5_L30_M001_N200_ref30_popinfo, 
                        F01_A10_L30_M001_N200_ref30_alpha, F01_A10_L30_M001_N200_ref30, F01_A10_L30_M001_N200_ref30_alpha_popinfo, F01_A10_L30_M001_N200_ref30_popinfo)
F01_M001_ref30_no0_no1 <- rbind(F01_A5_L30_M001_N200_ref30_alpha_no0_no1, F01_A5_L30_M001_N200_ref30_no0_no1, F01_A5_L30_M001_N200_ref30_alpha_popinfo_no0_no1, F01_A5_L30_M001_N200_ref30_popinfo_no0_no1, 
                                F01_A10_L30_M001_N200_ref30_alpha_no0_no1, F01_A10_L30_M001_N200_ref30_no0_no1, F01_A10_L30_M001_N200_ref30_alpha_popinfo_no0_no1, F01_A10_L30_M001_N200_ref30_popinfo_no0_no1)


alpha_dataset <- rbind(F01_noref, F01_ref10, F01_ref30)

alpha_M005 <- rbind(F01_M005_noref, F01_M005_ref10, F01_M005_ref30)
alpha_M001 <- rbind(F01_M001_noref, F01_M001_ref10, F01_M001_ref30)

alpha_M005_no0_no1 <- rbind(F01_M005_noref_no0, F01_M005_ref10_no0_no1, F01_M005_ref30_no0_no1)
alpha_M001_no0_no1 <- rbind(F01_M001_noref_no0, F01_M001_ref10_no0_no1, F01_M001_ref30_no0_no1)


#plots ----
F01_noref$alpha <- as.factor(F01_noref$alpha)
levels(F01_noref$alpha)
levels(F01_noref$alpha) <- c("alpha OFF", "alpha ON")

F01_noref$alleles <- as.factor(F01_noref$alleles)
levels(F01_noref$alleles)
levels(F01_noref$alleles) <- c("5 alleles", "10 alleles")

F01_noref$m <- as.factor(F01_noref$m)
levels(F01_noref$m)
levels(F01_noref$m) <- c("hybridization 1%", "hybridization 5%")

plot.F01_noref <- ggplot(F01_noref, aes(real_q_values, Structure_q_values)) + 
  theme_bw() + 
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1)) +
  facet_grid(m + alleles ~ alpha) + xlab(expression('q'['real'])) + ylab(expression('q'['STRUCTURE'])) + 
  background_grid(major = 'y', minor = "none") + # add thin horizontal lines 
  panel_border() # and a border around each panel

plot.F01_noref


F01_noref_no0 <- rbind(F01_M001_noref_no0, F01_M005_noref_no0)
F01_noref_no0$alpha <- as.factor(F01_noref_no0$alpha)
levels(F01_noref_no0$alpha)
levels(F01_noref_no0$alpha) <- c("alpha OFF", "alpha ON")

F01_noref_no0$alleles <- as.factor(F01_noref_no0$alleles)
levels(F01_noref_no0$alleles)
levels(F01_noref_no0$alleles) <- c("5 alleles", "10 alleles")

F01_noref_no0$m <- as.factor(F01_noref_no0$m)
levels(F01_noref_no0$m)
levels(F01_noref_no0$m) <- c("hybridization 1%", "hybridization 5%")

plot.F01_noref_no0 <- ggplot(F01_noref_no0, aes(real_q_values, Structure_q_values)) + 
  theme_bw() + 
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1)) +
  facet_grid(m + alleles ~ alpha) + xlab(expression('q'['real'])) + ylab(expression('q'['STRUCTURE'])) #+ 

plot.F01_noref_no0


F01_ref10$alpha <- as.factor(F01_ref10$alpha)
levels(F01_ref10$alpha)
levels(F01_ref10$alpha) <- c("alpha OFF", "alpha ON")

F01_ref10$popinfo <- as.factor(F01_ref10$popinfo)
levels(F01_ref10$popinfo)
levels(F01_ref10$popinfo) <- c("popinfo OFF", "popinfo ON")

F01_ref10$alleles <- as.factor(F01_ref10$alleles)
levels(F01_ref10$alleles)
levels(F01_ref10$alleles) <- c("5 alleles", "10 alleles")

F01_ref10$m <- as.factor(F01_ref10$m)
levels(F01_ref10$m)
levels(F01_ref10$m) <- c("hybridization 1%", "hybridization 5%")


plot.F01_ref10 <- ggplot(F01_ref10, aes(real_q_values, Structure_q_values)) + 
  theme_bw() + 
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1)) +
  facet_grid(m + alleles ~ popinfo + alpha) + xlab(expression('q'['real'])) + ylab(expression('q'['STRUCTURE'])) + 
  background_grid(major = 'y', minor = "none") + # add thin horizontal lines 
  panel_border() # and a border around each panel

plot.F01_ref10

F01_ref10_no0_no1 <- rbind(F01_M005_ref10_no0_no1, F01_M001_ref10_no0_no1)
F01_ref10_no0_no1$alpha <- as.factor(F01_ref10_no0_no1$alpha)
levels(F01_ref10_no0_no1$alpha)
levels(F01_ref10_no0_no1$alpha) <- c("alpha OFF", "alpha ON")

F01_ref10_no0_no1$popinfo <- as.factor(F01_ref10_no0_no1$popinfo)
levels(F01_ref10_no0_no1$popinfo)
levels(F01_ref10_no0_no1$popinfo) <- c("popinfo OFF", "popinfo ON")

F01_ref10_no0_no1$alleles <- as.factor(F01_ref10_no0_no1$alleles)
levels(F01_ref10_no0_no1$alleles)
levels(F01_ref10_no0_no1$alleles) <- c("5 alleles", "10 alleles")

F01_ref10_no0_no1$m <- as.factor(F01_ref10_no0_no1$m)
levels(F01_ref10_no0_no1$m)
levels(F01_ref10_no0_no1$m) <- c("hybridization 1%", "hybridization 5%")

plot.F01_ref10_no0_no1 <- ggplot(F01_ref10_no0_no1, aes(real_q_values, Structure_q_values)) + 
  theme_bw() + 
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1)) +
  facet_grid(m + alleles ~ popinfo + alpha) + xlab(expression('q'['real'])) + ylab(expression('q'['STRUCTURE'])) + 
  background_grid(major = 'y', minor = "none") + # add thin horizontal lines 
  panel_border() # and a border around each panel

plot.F01_ref10_no0_no1 <- ggplot(F01_ref10_no0_no1, aes(real_q_values, Structure_q_values)) + 
  theme_bw() + 
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1)) +
  facet_grid(m + alleles ~ popinfo + alpha) + xlab(expression('q'['real'])) + ylab(expression('q'['STRUCTURE'])) #+ 

plot.F01_ref10_no0_no1


F01_ref30$alpha <- as.factor(F01_ref30$alpha)
levels(F01_ref30$alpha)
levels(F01_ref30$alpha) <- c("alpha OFF", "alpha ON")

F01_ref30$popinfo <- as.factor(F01_ref30$popinfo)
levels(F01_ref30$popinfo)
levels(F01_ref30$popinfo) <- c("popinfo OFF", "popinfo ON")

F01_ref30$alleles <- as.factor(F01_ref30$alleles)
levels(F01_ref30$alleles)
levels(F01_ref30$alleles) <- c("5 alleles", "10 alleles")

F01_ref30$m <- as.factor(F01_ref30$m)
levels(F01_ref30$m)
levels(F01_ref30$m) <- c("hybridization 1%", "hybridization 5%")


plot.F01_ref30 <- ggplot(F01_ref30, aes(real_q_values, Structure_q_values)) + 
  theme_bw() + 
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1)) +
  facet_grid(m + alleles ~ popinfo + alpha) + xlab(expression('q'['real'])) + ylab(expression('q'['STRUCTURE'])) + 
  background_grid(major = 'y', minor = "none") + # add thin horizontal lines 
  panel_border() # and a border around each panel

plot.F01_ref30


F01_ref30_no0_no1 <- rbind(F01_M005_ref30_no0_no1, F01_M001_ref30_no0_no1)
F01_ref30_no0_no1$alpha <- as.factor(F01_ref30_no0_no1$alpha)
levels(F01_ref30_no0_no1$alpha)
levels(F01_ref30_no0_no1$alpha) <- c("alpha OFF", "alpha ON")

F01_ref30_no0_no1$popinfo <- as.factor(F01_ref30_no0_no1$popinfo)
levels(F01_ref30_no0_no1$popinfo)
levels(F01_ref30_no0_no1$popinfo) <- c("popinfo OFF", "popinfo ON")

F01_ref30_no0_no1$alleles <- as.factor(F01_ref30_no0_no1$alleles)
levels(F01_ref30_no0_no1$alleles)
levels(F01_ref30_no0_no1$alleles) <- c("5 alleles", "10 alleles")

F01_ref30_no0_no1$m <- as.factor(F01_ref30_no0_no1$m)
levels(F01_ref30_no0_no1$m)
levels(F01_ref30_no0_no1$m) <- c("hybridization 1%", "hybridization 5%")

plot.F01_ref30_no0_no1 <- ggplot(F01_ref30_no0_no1, aes(real_q_values, Structure_q_values)) + 
  theme_bw() + 
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1)) +
  facet_grid(m + alleles ~ popinfo + alpha) + xlab(expression('q'['real'])) + ylab(expression('q'['STRUCTURE'])) #+ 

plot.F01_ref30_no0_no1

#models ----

library(betareg)
y.transf.betareg <- function(y){
  n.obs <- sum(!is.na(y))
  (y * (n.obs - 1) + 0.5) / n.obs
}


alpha_M005_no0_no1$qdif_abs <- abs(alpha_M005_no0_no1$qdif)
alpha_M005_no0_no1$alpha <- as.factor(alpha_M005_no0_no1$alpha)
alpha_M005_no0_no1$popinfo <- as.factor(alpha_M005_no0_no1$popinfo)
m <- betareg(y.transf.betareg(qdif_abs) ~ reference + alleles + popinfo + alpha, alpha_M005_no0_no1)
res <- residuals(m, type= "pearson")
qqnorm(res); qqline(res)
summary(m, type="pearson")
plot(m)


alpha_M001_no0_no1$qdif_abs <- abs(alpha_M001_no0_no1$qdif)
alpha_M001_no0_no1$alpha <- as.factor(alpha_M001_no0_no1$alpha)
alpha_M001_no0_no1$popinfo <- as.factor(alpha_M001_no0_no1$popinfo)
m <- betareg(y.transf.betareg(qdif_abs) ~ reference + alleles + popinfo + alpha, alpha_M001_no0_no1)
res <- residuals(m, type= "pearson")
qqnorm(res); qqline(res)
summary(m, type="pearson")
plot(m)
