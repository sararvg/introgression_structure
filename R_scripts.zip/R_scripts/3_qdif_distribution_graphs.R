### Distribution of q_structure - q_real

# Data fst 0.1 migration 0.05 ----
F01_A2_L10_M005 <- cbind(Fst=0.1, alleles=2, loci = 10, m=0.05, rep="F01_A2_L10_M005", read.table("Fst0.1_NAl2_NMar10_M0.05_N200", header=T, dec = "."))
F01_A2_L10_M005 <- cbind (qdif= F01_A2_L10_M005$Structure_q_values - F01_A2_L10_M005$real_q_values, F01_A2_L10_M005)
F01_A2_L10_M005_no0 <- top(F01_A2_L10_M005, 100, 12, 7)
h1 <- hist(F01_A2_L10_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 5000), xlab = 'qStructure-qreal', main = 'A2 M10')
rm(F01_A2_L10_M005)

F01_A5_L10_M005 <- cbind(Fst=0.1, alleles=5, loci = 10, m=0.05, rep="F01_A5_L10_M005", read.table("Fst0.1_NAl5_NMar10_M0.05_N200", header=T, dec = "."))
F01_A5_L10_M005 <- cbind (qdif= F01_A5_L10_M005$Structure_q_values - F01_A5_L10_M005$real_q_values, F01_A5_L10_M005)
F01_A5_L10_M005_no0 <- top(F01_A5_L10_M005, 100, 12, 7)
h2 <- hist(F01_A5_L10_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 5000), xlab = 'qStructure-qreal', main = 'A5 M10')
rm(F01_A5_L10_M005)

F01_A10_L10_M005 <- cbind(Fst=0.1, alleles=10, loci = 10, m=0.05, rep="F01_A10_L10_M005", read.table("Fst0.1_NAl10_NMar10_M0.05_N200", header=T, dec = "."))
F01_A10_L10_M005 <- cbind (qdif= F01_A10_L10_M005$Structure_q_values - F01_A10_L10_M005$real_q_values, F01_A10_L10_M005)
F01_A10_L10_M005_no0 <- top(F01_A10_L10_M005, 100, 12, 7)
h3 <- hist(F01_A10_L10_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 5000), xlab = 'qStructure-qreal', main = 'A10 M10')
rm(F01_A10_L10_M005)

F01_A2_L30_M005 <- cbind(Fst=0.1, alleles=2, loci = 30, m=0.05, rep="F01_A2_L30_M005", read.table("Fst0.1_NAl2_NMar30_M0.05_N200", header=T, dec = "."))
F01_A2_L30_M005 <- cbind (qdif= F01_A2_L30_M005$Structure_q_values - F01_A2_L30_M005$real_q_values, F01_A2_L30_M005)
F01_A2_L30_M005_no0 <- top(F01_A2_L30_M005, 100, 12, 7)
h4 <- hist(F01_A2_L30_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 5000), xlab = 'qStructure-qreal', main = 'A2 M30')
rm(F01_A2_L30_M005)

F01_A5_L30_M005 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005", read.table("Fst0.1_NAl5_NMar30_M0.05_N200", header=T, dec = "."))
F01_A5_L30_M005 <- cbind (qdif= F01_A5_L30_M005$Structure_q_values - F01_A5_L30_M005$real_q_values, F01_A5_L30_M005)
F01_A5_L30_M005_no0 <- top(F01_A5_L30_M005, 100, 12, 7)
h5 <- hist(F01_A5_L30_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 5000), xlab = 'qStructure-qreal', main = 'A5 M30')
rm(F01_A5_L30_M005)

F01_A10_L30_M005 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005", read.table("Fst0.1_NAl10_NMar30_M0.05_N200", header=T, dec = "."))
F01_A10_L30_M005 <- cbind (qdif= F01_A10_L30_M005$Structure_q_values - F01_A10_L30_M005$real_q_values, F01_A10_L30_M005)
F01_A10_L30_M005_no0 <- top(F01_A10_L30_M005, 100, 12, 7)
h6 <- hist(F01_A10_L30_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 5000), xlab = 'qStructure-qreal', main = 'A10 M30')
rm(F01_A10_L30_M005)

F01_A2_L100_M005 <- cbind(Fst=0.1, alleles=2, loci = 100, m=0.05, rep="F01_A2_L100_M005", read.table("Fst0.1_NAl2_NMar100_M0.05_N200", header=T, dec = "."))
F01_A2_L100_M005 <- cbind (qdif= F01_A2_L100_M005$Structure_q_values - F01_A2_L100_M005$real_q_values, F01_A2_L100_M005)
F01_A2_L100_M005_no0 <- top(F01_A2_L100_M005, 100, 12, 7)
h7 <- hist(F01_A2_L100_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 5000), xlab = 'qStructure-qreal', main = 'A2 M100')
rm(F01_A2_L100_M005)

F01_A5_L100_M005 <- cbind(Fst=0.1, alleles=5, loci = 100, m=0.05, rep="F01_A5_L100_M005", read.table("Fst0.1_NAl5_NMar100_M0.05_N200", header=T, dec = "."))
F01_A5_L100_M005 <- cbind (qdif= F01_A5_L100_M005$Structure_q_values - F01_A5_L100_M005$real_q_values, F01_A5_L100_M005)
F01_A5_L100_M005_no0 <- top(F01_A5_L100_M005, 100, 12, 7)
h8 <- hist(F01_A5_L100_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 5000), xlab = 'qStructure-qreal', main = 'A5 M100')
rm(F01_A5_L100_M005)

F01_A10_L100_M005 <- cbind(Fst=0.1, alleles=10, loci = 100, m=0.05, rep="F01_A10_L100_M005", read.table("Fst0.1_NAl10_NMar100_M0.05_N200", header=T, dec = "."))
F01_A10_L100_M005 <- cbind (qdif= F01_A10_L100_M005$Structure_q_values - F01_A10_L100_M005$real_q_values, F01_A10_L100_M005)
F01_A10_L100_M005_no0 <- top(F01_A10_L100_M005, 100, 12, 7)
h9 <- hist(F01_A10_L100_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 5000), xlab = 'qStructure-qreal', main = 'A10 M100')
rm(F01_A10_L100_M005)


F01_m005_no0 <- rbind(F01_A2_L10_M005_no0, F01_A5_L10_M005_no0, F01_A10_L10_M005_no0, 
                      F01_A2_L30_M005_no0, F01_A5_L30_M005_no0, F01_A10_L30_M005_no0,
                      F01_A2_L100_M005_no0,F01_A5_L100_M005_no0, F01_A10_L100_M005_no0)
F01_m005_no0_A2 <- rbind(F01_A2_L10_M005_no0, F01_A2_L30_M005_no0, F01_A2_L100_M005_no0)
F01_m005_no0_A5 <- rbind(F01_A5_L10_M005_no0, F01_A5_L30_M005_no0, F01_A5_L100_M005_no0)
F01_m005_no0_A10 <- rbind(F01_A10_L10_M005_no0,F01_A10_L30_M005_no0, F01_A10_L100_M005_no0)

#A2
F01_M005_A2_dens <- ggplot(F01_m005_no0_A2, aes(x = qdif, colour=interaction(loci, alleles))) + geom_vline(xintercept=0, size=1) +
  scale_color_brewer(palette="Dark2") + theme_bw() + theme(legend.title = element_blank(),legend.position = "none",axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_density(size=1) + xlim(-0.5, 0.75) + ylim(0,16) 
#A5
F01_M005_A5_dens <- ggplot(F01_m005_no0_A5, aes(x = qdif, colour = interaction(loci, alleles))) + geom_vline(xintercept=0, size=1) +
  scale_color_brewer(palette="Dark2") + theme_bw() + theme(legend.title = element_blank(),legend.position = "none",axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_density(size=1) + xlim(-0.5, 0.75) + ylim(0,16) 
#A10
F01_M005_A10_dens <- ggplot(F01_m005_no0_A10, aes(x = qdif, colour = interaction(loci, alleles))) + geom_vline(xintercept=0, size=1) +
  scale_color_brewer(palette="Dark2") + theme_bw() + theme(legend.title = element_blank(),legend.position = "none",axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_density(size=1) + xlim(-0.5, 0.75) + ylim(0,16) 

grid.arrange(F01_M005_A2_dens, F01_M005_A5_dens, F01_M005_A10_dens, ncol=1)


# Data fst 0.1 migration 0.01 ----
F01_A2_L10_M001 <- cbind(Fst=0.1, alleles=2, loci = 10, m=0.01, rep="F01_A2_L10_M001", read.table("Fst0.1_NAl2_NMar10_M0.01_N200", header=T, dec = "."))
F01_A2_L10_M001 <- cbind (qdif= F01_A2_L10_M001$Structure_q_values - F01_A2_L10_M001$real_q_values, F01_A2_L10_M001)
F01_A2_L10_M001_no0 <- top(F01_A2_L10_M001, 100, 12, 7)
h10 <- hist(F01_A2_L10_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A2 M10')
rm(F01_A2_L10_M001)

F01_A5_L10_M001 <- cbind(Fst=0.1, alleles=5, loci = 10, m=0.01, rep="F01_A5_L10_M001", read.table("Fst0.1_NAl5_NMar10_M0.01_N200", header=T, dec = "."))
F01_A5_L10_M001 <- cbind (qdif= F01_A5_L10_M001$Structure_q_values - F01_A5_L10_M001$real_q_values, F01_A5_L10_M001)
F01_A5_L10_M001_no0 <- top(F01_A5_L10_M001, 100, 12, 7)
h11 <- hist(F01_A5_L10_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A5 M10')
rm(F01_A5_L10_M001)

F01_A10_L10_M001 <- cbind(Fst=0.1, alleles=10, loci = 10, m=0.01, rep="F01_A10_L10_M001", read.table("Fst0.1_NAl10_NMar10_M0.01_N200", header=T, dec = "."))
F01_A10_L10_M001 <- cbind (qdif= F01_A10_L10_M001$Structure_q_values - F01_A10_L10_M001$real_q_values, F01_A10_L10_M001)
F01_A10_L10_M001_no0 <- top(F01_A10_L10_M001, 100, 12, 7)
h12 <- hist(F01_A10_L10_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A10 M10')
rm(F01_A10_L10_M001)

F01_A2_L30_M001 <- cbind(Fst=0.1, alleles=2, loci = 30, m=0.01, rep="F01_A2_L30_M001", read.table("Fst0.1_NAl2_NMar30_M0.01_N200", header=T, dec = "."))
F01_A2_L30_M001 <- cbind (qdif= F01_A2_L30_M001$Structure_q_values - F01_A2_L30_M001$real_q_values, F01_A2_L30_M001)
F01_A2_L30_M001_no0 <- top(F01_A2_L30_M001, 100, 12, 7)
h13 <- hist(F01_A2_L30_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A2 M30')
rm(F01_A2_L30_M001)

F01_A5_L30_M001 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001", read.table("Fst0.1_NAl5_NMar30_M0.01_N200", header=T, dec = "."))
F01_A5_L30_M001 <- cbind (qdif= F01_A5_L30_M001$Structure_q_values - F01_A5_L30_M001$real_q_values, F01_A5_L30_M001)
F01_A5_L30_M001_no0 <- top(F01_A5_L30_M001, 100, 12, 7)
h14 <- hist(F01_A5_L30_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A5 M30')
rm(F01_A5_L30_M001)

F01_A10_L30_M001 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001", read.table("Fst0.1_NAl10_NMar30_M0.01_N200", header=T, dec = "."))
F01_A10_L30_M001 <- cbind (qdif= F01_A10_L30_M001$Structure_q_values - F01_A10_L30_M001$real_q_values, F01_A10_L30_M001)
F01_A10_L30_M001_no0 <- top(F01_A10_L30_M001, 100, 12, 7)
h15 <- hist(F01_A10_L30_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A10 M30')
rm(F01_A10_L30_M001)

F01_A2_L100_M001 <- cbind(Fst=0.1, alleles=2, loci = 100, m=0.01, rep="F01_A2_L100_M001", read.table("Fst0.1_NAl2_NMar100_M0.01_N200", header=T, dec = "."))
F01_A2_L100_M001 <- cbind (qdif= F01_A2_L100_M001$Structure_q_values - F01_A2_L100_M001$real_q_values, F01_A2_L100_M001)
F01_A2_L100_M001_no0 <- top(F01_A2_L100_M001, 100, 12, 7)
h16 <- hist(F01_A2_L100_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A2 M100')
rm(F01_A2_L100_M001)

F01_A5_L100_M001 <- cbind(Fst=0.1, alleles=5, loci = 100, m=0.01, rep="F01_A5_L100_M001", read.table("Fst0.1_NAl5_NMar100_M0.01_N200", header=T, dec = "."))
F01_A5_L100_M001 <- cbind (qdif= F01_A5_L100_M001$Structure_q_values - F01_A5_L100_M001$real_q_values, F01_A5_L100_M001)
F01_A5_L100_M001_no0 <- top(F01_A5_L100_M001, 100, 12, 7)
h17 <- hist(F01_A5_L100_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A5 M100')
rm(F01_A5_L100_M001)

F01_A10_L100_M001 <- cbind(Fst=0.1, alleles=10, loci = 100, m=0.01, rep="F01_A10_L100_M001", read.table("Fst0.1_NAl10_NMar100_M0.01_N200", header=T, dec = "."))
F01_A10_L100_M001 <- cbind (qdif= F01_A10_L100_M001$Structure_q_values - F01_A10_L100_M001$real_q_values, F01_A10_L100_M001)
F01_A10_L100_M001_no0 <- top(F01_A10_L100_M001, 100, 12, 7)
h18 <- hist(F01_A10_L100_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A10 M100')
rm(F01_A10_L100_M001)

F01_m001_no0 <- rbind(F01_A2_L10_M001_no0, F01_A5_L10_M001_no0, F01_A10_L10_M001_no0, 
                      F01_A2_L30_M001_no0, F01_A5_L30_M001_no0, F01_A10_L30_M001_no0,
                      F01_A2_L100_M001_no0, F01_A5_L100_M001_no0, F01_A10_L100_M001_no0)
F01_m001_no0_A2 <- rbind(F01_A2_L10_M001_no0, F01_A2_L30_M001_no0, F01_A2_L100_M001_no0)
F01_m001_no0_A5 <- rbind(F01_A5_L10_M001_no0, F01_A5_L30_M001_no0, F01_A5_L100_M001_no0)
F01_m001_no0_A10 <- rbind(F01_A10_L10_M001_no0, F01_A10_L30_M001_no0, F01_A10_L100_M001_no0)

#A2
F01_M001_A2_dens <- ggplot(F01_m001_no0_A2, aes(x = qdif, colour=interaction(loci, alleles))) + geom_vline(xintercept=0, size=1) + 
  scale_color_brewer(palette="Dark2") + theme_bw() + theme(legend.title = element_blank(),legend.position = "none",axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_density(size=1) + xlim(-0.5, 0.75) + ylim(0,16) 
#A5
F01_M001_A5_dens <- ggplot(F01_m001_no0_A5, aes(x = qdif, colour = interaction(loci, alleles))) + geom_vline(xintercept=0, size=1) +
  scale_color_brewer(palette="Dark2") + theme_bw() + theme(legend.title = element_blank(),legend.position = "none",axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_density(size=1) + xlim(-0.5, 0.75) + ylim(0,16) 
#A10
F01_M001_A10_dens <- ggplot(F01_m001_no0_A10, aes(x = qdif, colour = interaction(loci, alleles))) + geom_vline(xintercept=0, size=1) +
  scale_color_brewer(palette="Dark2") + theme_bw() + theme(legend.title = element_blank(),legend.position = "none",axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_density(size=1) +  xlim(-0.5, 0.75) + ylim(0,16) 

grid.arrange(F01_M001_A2_dens, F01_M001_A5_dens, F01_M001_A10_dens, ncol=1)



# Data fst 0.2 migration 0.05 ----
F02_A2_L10_M005 <- cbind(Fst=0.2, alleles=2, loci = 10, m=0.05, rep="F02_A2_L10_M005", read.table("Fst0.2_NAl2_NMar10_M0.05_N200", header=T, dec = "."))
F02_A2_L10_M005 <- cbind (qdif= F02_A2_L10_M005$Structure_q_values - F02_A2_L10_M005$real_q_values, F02_A2_L10_M005)
F02_A2_L10_M005_no0 <- top(F02_A2_L10_M005, 100, 12, 7)
h19 <- hist(F02_A2_L10_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A2 M10')
rm(F02_A2_L10_M005)

F02_A5_L10_M005 <- cbind(Fst=0.2, alleles=5, loci = 10, m=0.05, rep="F02_A5_L10_M005", read.table("Fst0.2_NAl5_NMar10_M0.05_N200", header=T, dec = "."))
F02_A5_L10_M005 <- cbind (qdif= F02_A5_L10_M005$Structure_q_values - F02_A5_L10_M005$real_q_values, F02_A5_L10_M005)
F02_A5_L10_M005_no0 <- top(F02_A5_L10_M005, 100, 12, 7)
h20 <- hist(F02_A5_L10_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A5 M10')
rm(F02_A5_L10_M005)

F02_A10_L10_M005 <- cbind(Fst=0.2, alleles=10, loci = 10, m=0.05, rep="F02_A10_L10_M005", read.table("Fst0.2_NAl10_NMar10_M0.05_N200", header=T, dec = "."))
F02_A10_L10_M005 <- cbind (qdif= F02_A10_L10_M005$Structure_q_values - F02_A10_L10_M005$real_q_values, F02_A10_L10_M005)
F02_A10_L10_M005_no0 <- top(F02_A10_L10_M005, 100, 12, 7)
h21 <- hist(F02_A10_L10_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A10 M10')
rm(F02_A10_L10_M005)

F02_A2_L30_M005 <- cbind(Fst=0.2, alleles=2, loci = 30, m=0.05, rep="F02_A2_L30_M005", read.table("Fst0.2_NAl2_NMar30_M0.05_N200", header=T, dec = "."))
F02_A2_L30_M005 <- cbind (qdif= F02_A2_L30_M005$Structure_q_values - F02_A2_L30_M005$real_q_values, F02_A2_L30_M005)
F02_A2_L30_M005_no0 <- top(F02_A2_L30_M005, 100, 12, 7)
h22 <- hist(F02_A2_L30_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A2 M30')
rm(F02_A2_L30_M005)

F02_A5_L30_M005 <- cbind(Fst=0.2, alleles=5, loci = 30, m=0.05, rep="F02_A5_L30_M005", read.table("Fst0.2_NAl5_NMar30_M0.05_N200", header=T, dec = "."))
F02_A5_L30_M005 <- cbind (qdif= F02_A5_L30_M005$Structure_q_values - F02_A5_L30_M005$real_q_values, F02_A5_L30_M005)
F02_A5_L30_M005_no0 <- top(F02_A5_L30_M005, 100, 12, 7)
h23 <- hist(F02_A5_L30_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A5 M30')
rm(F02_A5_L30_M005)

F02_A10_L30_M005 <- cbind(Fst=0.2, alleles=10, loci = 30, m=0.05, rep="F02_A10_L30_M005", read.table("Fst0.2_NAl10_NMar30_M0.05_N200", header=T, dec = "."))
F02_A10_L30_M005 <- cbind (qdif= F02_A10_L30_M005$Structure_q_values - F02_A10_L30_M005$real_q_values, F02_A10_L30_M005)
F02_A10_L30_M005_no0 <- top(F02_A10_L30_M005, 100, 12, 7)
h24 <- hist(F02_A10_L30_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A10 M30')
rm(F02_A10_L30_M005)

F02_A2_L100_M005 <- cbind(Fst=0.2, alleles=2, loci = 100, m=0.05, rep="F02_A2_L100_M005", read.table("Fst0.2_NAl2_NMar100_M0.05_N200", header=T, dec = "."))
F02_A2_L100_M005 <- cbind (qdif= F02_A2_L100_M005$Structure_q_values - F02_A2_L100_M005$real_q_values, F02_A2_L100_M005)
F02_A2_L100_M005_no0 <- top(F02_A2_L100_M005, 100, 12, 7)
h25 <- hist(F02_A2_L100_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A2 M100')
rm(F02_A2_L100_M005)

F02_A5_L100_M005 <- cbind(Fst=0.2, alleles=5, loci = 100, m=0.05, rep="F02_A5_L100_M005", read.table("Fst0.2_NAl5_NMar100_M0.05_N200", header=T, dec = "."))
F02_A5_L100_M005 <- cbind (qdif= F02_A5_L100_M005$Structure_q_values - F02_A5_L100_M005$real_q_values, F02_A5_L100_M005)
F02_A5_L100_M005_no0 <- top(F02_A5_L100_M005, 100, 12, 7)
h26 <- hist(F02_A5_L100_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A5 M100')
rm(F02_A5_L100_M005)

F02_A10_L100_M005 <- cbind(Fst=0.2, alleles=10, loci = 100, m=0.05, rep="F02_A10_L100_M005", read.table("Fst0.2_NAl10_NMar100_M0.05_N200", header=T, dec = "."))
F02_A10_L100_M005 <- cbind (qdif= F02_A10_L100_M005$Structure_q_values - F02_A10_L100_M005$real_q_values, F02_A10_L100_M005)
F02_A10_L100_M005_no0 <- top(F02_A10_L100_M005, 100, 12, 7)
h27 <- hist(F02_A10_L100_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A10 M100')
rm(F02_A10_L100_M005)

F02_m005_no0 <- rbind(F02_A2_L10_M005_no0, F02_A5_L10_M005_no0, F02_A10_L10_M005_no0, 
                      F02_A2_L30_M005_no0, F02_A5_L30_M005_no0, F02_A10_L30_M005_no0,
                      F02_A2_L100_M005_no0,F02_A5_L100_M005_no0, F02_A10_L100_M005_no0)
F02_m005_no0_A2 <- rbind(F02_A2_L10_M005_no0, F02_A2_L30_M005_no0, F02_A2_L100_M005_no0)
F02_m005_no0_A5 <- rbind(F02_A5_L10_M005_no0, F02_A5_L30_M005_no0, F02_A5_L100_M005_no0)
F02_m005_no0_A10 <- rbind(F02_A10_L10_M005_no0,F02_A10_L30_M005_no0, F02_A10_L100_M005_no0)

#A2
F02_M005_A2_dens <- ggplot(F02_m005_no0_A2, aes(x = qdif, colour=interaction(loci, alleles))) + geom_vline(xintercept=0, size=1) +
  scale_color_brewer(palette="Dark2") + theme_bw() + theme(legend.title = element_blank(),legend.position = "none",axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_density(size=1) + xlim(-0.5, 0.75) + ylim(0,17) 
#A5
F02_M005_A5_dens <- ggplot(F02_m005_no0_A5, aes(x = qdif, colour = interaction(loci, alleles))) + geom_vline(xintercept=0, size=1) +
  scale_color_brewer(palette="Dark2") + theme_bw() + theme(legend.title = element_blank(),legend.position = "none",axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_density(size=1) + xlim(-0.5, 0.75) + ylim(0,17) 
#A10
F02_M005_A10_dens <- ggplot(F02_m005_no0_A10, aes(x = qdif, colour = interaction(loci, alleles))) + geom_vline(xintercept=0, size=1) +
  scale_color_brewer(palette="Dark2") + theme_bw() + theme(legend.title = element_blank(),legend.position = "none",axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_density(size=1) + xlim(-0.5, 0.75) + ylim(0,17) 

grid.arrange(F02_M005_A2_dens, F02_M005_A5_dens, F02_M005_A10_dens, ncol=1)



# Data fst 0.2 migration 0.01 ----
F02_A2_L10_M001 <- cbind(Fst=0.2, alleles=2, loci = 10, m=0.01, rep="F02_A2_L10_M001", read.table("Fst0.2_NAl2_NMar10_M0.01_N200", header=T, dec = "."))
F02_A2_L10_M001 <- cbind (qdif= F02_A2_L10_M001$Structure_q_values - F02_A2_L10_M001$real_q_values, F02_A2_L10_M001)
F02_A2_L10_M001_no0 <- top(F02_A2_L10_M001, 100, 12, 7)
h28 <- hist(F02_A2_L10_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A2 M10')
rm(F02_A2_L10_M001)

F02_A5_L10_M001 <- cbind(Fst=0.2, alleles=5, loci = 10, m=0.01, rep="F02_A5_L10_M001", read.table("Fst0.2_NAl5_NMar10_M0.01_N200", header=T, dec = "."))
F02_A5_L10_M001 <- cbind (qdif= F02_A5_L10_M001$Structure_q_values - F02_A5_L10_M001$real_q_values, F02_A5_L10_M001)
F02_A5_L10_M001_no0 <- top(F02_A5_L10_M001, 100, 12, 7)
h29 <- hist(F02_A5_L10_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A5 M10')
rm(F02_A5_L10_M001)

F02_A10_L10_M001 <- cbind(Fst=0.2, alleles=10, loci = 10, m=0.01, rep="F02_A10_L10_M001", read.table("Fst0.2_NAl10_NMar10_M0.01_N200", header=T, dec = "."))
F02_A10_L10_M001 <- cbind (qdif= F02_A10_L10_M001$Structure_q_values - F02_A10_L10_M001$real_q_values, F02_A10_L10_M001)
F02_A10_L10_M001_no0 <- top(F02_A10_L10_M001, 100, 12, 7)
h30 <- hist(F02_A10_L10_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A10 M10')
rm(F02_A10_L10_M001)

F02_A2_L30_M001 <- cbind(Fst=0.2, alleles=2, loci = 30, m=0.01, rep="F02_A2_L30_M001", read.table("Fst0.2_NAl2_NMar30_M0.01_N200", header=T, dec = "."))
F02_A2_L30_M001 <- cbind (qdif= F02_A2_L30_M001$Structure_q_values - F02_A2_L30_M001$real_q_values, F02_A2_L30_M001)
F02_A2_L30_M001_no0 <- top(F02_A2_L30_M001, 100, 12, 7)
h31 <- hist(F02_A2_L30_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A2 M30')
rm(F02_A2_L30_M001)

F02_A5_L30_M001 <- cbind(Fst=0.2, alleles=5, loci = 30, m=0.01, rep="F02_A5_L30_M001", read.table("Fst0.2_NAl5_NMar30_M0.01_N200", header=T, dec = "."))
F02_A5_L30_M001 <- cbind (qdif= F02_A5_L30_M001$Structure_q_values - F02_A5_L30_M001$real_q_values, F02_A5_L30_M001)
F02_A5_L30_M001_no0 <- top(F02_A5_L30_M001, 100, 12, 7)
h32 <- hist(F02_A5_L30_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A5 M30')
rm(F02_A5_L30_M001)

F02_A10_L30_M001 <- cbind(Fst=0.2, alleles=10, loci = 30, m=0.01, rep="F02_A10_L30_M001", read.table("Fst0.2_NAl10_NMar30_M0.01_N200", header=T, dec = "."))
F02_A10_L30_M001 <- cbind (qdif= F02_A10_L30_M001$Structure_q_values - F02_A10_L30_M001$real_q_values, F02_A10_L30_M001)
F02_A10_L30_M001_no0 <- top(F02_A10_L30_M001, 100, 12, 7)
h33 <- hist(F02_A10_L30_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A10 M30')
rm(F02_A10_L30_M001)

F02_A2_L100_M001 <- cbind(Fst=0.2, alleles=2, loci = 100, m=0.01, rep="F02_A2_L100_M001", read.table("Fst0.2_NAl2_NMar100_M0.01_N200", header=T, dec = "."))
F02_A2_L100_M001 <- cbind (qdif= F02_A2_L100_M001$Structure_q_values - F02_A2_L100_M001$real_q_values, F02_A2_L100_M001)
F02_A2_L100_M001_no0 <- top(F02_A2_L100_M001, 100, 12, 7)
h34 <- hist(F02_A2_L100_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A2 M100')
rm(F02_A2_L100_M001)

F02_A5_L100_M001 <- cbind(Fst=0.2, alleles=5, loci = 100, m=0.01, rep="F02_A5_L100_M001", read.table("Fst0.2_NAl5_NMar100_M0.01_N200", header=T, dec = "."))
F02_A5_L100_M001 <- cbind (qdif= F02_A5_L100_M001$Structure_q_values - F02_A5_L100_M001$real_q_values, F02_A5_L100_M001)
F02_A5_L100_M001_no0 <- top(F02_A5_L100_M001, 100, 12, 7)
h35 <- hist(F02_A5_L100_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A5 M100')
rm(F02_A5_L100_M001)

F02_A10_L100_M001 <- cbind(Fst=0.2, alleles=10, loci = 100, m=0.01, rep="F02_A10_L100_M001", read.table("Fst0.2_NAl10_NMar100_M0.01_N200", header=T, dec = "."))
F02_A10_L100_M001 <- cbind (qdif= F02_A10_L100_M001$Structure_q_values - F02_A10_L100_M001$real_q_values, F02_A10_L100_M001)
F02_A10_L100_M001_no0 <- top(F02_A10_L100_M001, 100, 12, 7)
h36 <- hist(F02_A10_L100_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A10 M100')
rm(F02_A10_L100_M001)


F02_m001_no0 <- rbind(F02_A2_L10_M001_no0, F02_A5_L10_M001_no0, F02_A10_L10_M001_no0, 
                      F02_A2_L30_M001_no0, F02_A5_L30_M001_no0, F02_A10_L30_M001_no0,
                      F02_A2_L100_M001_no0, F02_A5_L100_M001_no0, F02_A10_L100_M001_no0)
F02_m001_no0_A2 <- rbind(F02_A2_L10_M001_no0, F02_A2_L30_M001_no0, F02_A2_L100_M001_no0)
F02_m001_no0_A5 <- rbind(F02_A5_L10_M001_no0, F02_A5_L30_M001_no0, F02_A5_L100_M001_no0)
F02_m001_no0_A10 <- rbind(F02_A10_L10_M001_no0,F02_A10_L30_M001_no0, F02_A10_L100_M001_no0)

#A2
F02_M001_A2_dens <- ggplot(F02_m001_no0_A2, aes(x = qdif, colour=interaction(loci, alleles))) + geom_vline(xintercept=0, size=1) +
  scale_color_brewer(palette="Dark2") + theme_bw() + theme(legend.title = element_blank(),legend.position = "none",axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_density(size=1)  + xlim(-0.5, 0.75) + ylim(0,17) 
#A5
F02_M001_A5_dens <- ggplot(F02_m001_no0_A5, aes(x = qdif, colour = interaction(loci, alleles))) + geom_vline(xintercept=0, size=1) +
  scale_color_brewer(palette="Dark2") + theme_bw() + theme(legend.title = element_blank(),legend.position = "none",axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_density(size=1) + xlim(-0.5, 0.75) + ylim(0,17) 
#A10
F02_M001_A10_dens <- ggplot(F02_m001_no0_A10, aes(x = qdif, colour = interaction(loci, alleles))) + geom_vline(xintercept=0, size=1) +
  scale_color_brewer(palette="Dark2") + theme_bw() + theme(legend.title = element_blank(),legend.position = "none",axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_density(size=1) + xlim(-0.5, 0.75) + ylim(0,17) 

grid.arrange(F02_M001_A2_dens, F02_M001_A5_dens, F02_M001_A10_dens, ncol=1)



# Data fst 0.05 migration 0.05 ----
F005_A2_L10_M005 <- cbind(Fst=0.05, alleles=2, loci = 10, m=0.05, rep="F005_A2_L10_M005", read.table("Fst0.05_NAl2_NMar10_M0.05_N200", header=T, dec = "."))
F005_A2_L10_M005 <- cbind (qdif= F005_A2_L10_M005$Structure_q_values - F005_A2_L10_M005$real_q_values, F005_A2_L10_M005)
F005_A2_L10_M005_no0 <- top(F005_A2_L10_M005, 100, 12, 7)
h37 <- hist(F005_A2_L10_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A2 M10')
rm(F005_A2_L10_M005)

F005_A5_L10_M005 <- cbind(Fst=0.05, alleles=5, loci = 10, m=0.05, rep="F005_A5_L10_M005", read.table("Fst0.05_NAl5_NMar10_M0.05_N200", header=T, dec = "."))
F005_A5_L10_M005 <- cbind (qdif= F005_A5_L10_M005$Structure_q_values - F005_A5_L10_M005$real_q_values, F005_A5_L10_M005)
F005_A5_L10_M005_no0 <- top(F005_A5_L10_M005, 100, 12, 7)
h38 <- hist(F005_A5_L10_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A5 M10')
rm(F005_A5_L10_M005)

F005_A10_L10_M005 <- cbind(Fst=0.05, alleles=10, loci = 10, m=0.05, rep="F005_A10_L10_M005", read.table("Fst0.05_NAl10_NMar10_M0.05_N200", header=T, dec = "."))
F005_A10_L10_M005 <- cbind (qdif= F005_A10_L10_M005$Structure_q_values - F005_A10_L10_M005$real_q_values, F005_A10_L10_M005)
F005_A10_L10_M005_no0 <- top(F005_A10_L10_M005, 100, 12, 7)
h39 <- hist(F005_A10_L10_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A10 M10')
rm(F005_A10_L10_M005)

F005_A2_L30_M005 <- cbind(Fst=0.05, alleles=2, loci = 30, m=0.05, rep="F005_A2_L30_M005", read.table("Fst0.05_NAl2_NMar30_M0.05_N200", header=T, dec = "."))
F005_A2_L30_M005 <- cbind (qdif= F005_A2_L30_M005$Structure_q_values - F005_A2_L30_M005$real_q_values, F005_A2_L30_M005)
F005_A2_L30_M005_no0 <- top(F005_A2_L30_M005, 100, 12, 7)
h40 <- hist(F005_A2_L30_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A2 M30')
rm(F005_A2_L30_M005)

F005_A5_L30_M005 <- cbind(Fst=0.05, alleles=5, loci = 30, m=0.05, rep="F005_A5_L30_M005", read.table("Fst0.05_NAl5_NMar30_M0.05_N200", header=T, dec = "."))
F005_A5_L30_M005 <- cbind (qdif= F005_A5_L30_M005$Structure_q_values - F005_A5_L30_M005$real_q_values, F005_A5_L30_M005)
F005_A5_L30_M005_no0 <- top(F005_A5_L30_M005, 100, 12, 7)
h41 <- hist(F005_A5_L30_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A5 M30')
rm(F005_A5_L30_M005)

F005_A10_L30_M005 <- cbind(Fst=0.05, alleles=10, loci = 30, m=0.05, rep="F005_A10_L30_M005", read.table("Fst0.05_NAl10_NMar30_M0.05_N200", header=T, dec = "."))
F005_A10_L30_M005 <- cbind (qdif= F005_A10_L30_M005$Structure_q_values - F005_A10_L30_M005$real_q_values, F005_A10_L30_M005)
F005_A10_L30_M005_no0 <- top(F005_A10_L30_M005, 100, 12, 7)
h42 <- hist(F005_A10_L30_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A10 M30')
rm(F005_A10_L30_M005)

F005_A2_L100_M005 <- cbind(Fst=0.05, alleles=2, loci = 100, m=0.05, rep="F005_A2_L100_M005", read.table("Fst0.05_NAl2_NMar100_M0.05_N200", header=T, dec = "."))
F005_A2_L100_M005 <- cbind (qdif= F005_A2_L100_M005$Structure_q_values - F005_A2_L100_M005$real_q_values, F005_A2_L100_M005)
F005_A2_L100_M005_no0 <- top(F005_A2_L100_M005, 100, 12, 7)
h43 <- hist(F005_A2_L100_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A2 M100')
rm(F005_A2_L100_M005)

F005_A5_L100_M005 <- cbind(Fst=0.05, alleles=5, loci = 100, m=0.05, rep="F005_A5_L100_M005", read.table("Fst0.05_NAl5_NMar100_M0.05_N200", header=T, dec = "."))
F005_A5_L100_M005 <- cbind (qdif= F005_A5_L100_M005$Structure_q_values - F005_A5_L100_M005$real_q_values, F005_A5_L100_M005)
F005_A5_L100_M005_no0 <- top(F005_A5_L100_M005, 100, 12, 7)
h44 <- hist(F005_A5_L100_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A5 M100')
rm(F005_A5_L100_M005)

F005_A10_L100_M005 <- cbind(Fst=0.05, alleles=10, loci = 100, m=0.05, rep="F005_A10_L100_M005", read.table("Fst0.05_NAl10_NMar100_M0.05_N200", header=T, dec = "."))
F005_A10_L100_M005 <- cbind (qdif= F005_A10_L100_M005$Structure_q_values - F005_A10_L100_M005$real_q_values, F005_A10_L100_M005)
F005_A10_L100_M005_no0 <- top(F005_A10_L100_M005, 100, 12, 7)
h45 <- hist(F005_A10_L100_M005_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A10 M100')
rm(F005_A10_L100_M005)


F005_m005_no0 <- rbind(F005_A2_L10_M005_no0, F005_A5_L10_M005_no0, F005_A10_L10_M005_no0, 
                       F005_A2_L30_M005_no0, F005_A5_L30_M005_no0, F005_A10_L30_M005_no0,
                       F005_A2_L100_M005_no0, F005_A5_L100_M005_no0, F005_A10_L100_M005_no0)

F005_m005_no0_A2 <- rbind(F005_A2_L10_M005_no0, F005_A2_L30_M005_no0, F005_A2_L100_M005_no0)
F005_m005_no0_A5 <- rbind(F005_A5_L10_M005_no0, F005_A5_L30_M005_no0, F005_A5_L100_M005_no0)
F005_m005_no0_A10 <- rbind(F005_A10_L10_M005_no0,F005_A10_L30_M005_no0, F005_A10_L100_M005_no0)

#A2
F005_M005_A2_dens <- ggplot(F005_m005_no0_A2, aes(x = qdif, colour=interaction(loci, alleles))) + geom_vline(xintercept=0, size=1) +
  scale_color_brewer(palette="Dark2") + theme_bw() + theme(legend.title = element_blank(),legend.position = "none",axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_density(size=1) + xlim(-0.5, 0.75) + ylim(0,15) 
#A5
F005_M005_A5_dens <- ggplot(F005_m005_no0_A5, aes(x = qdif, colour = interaction(loci, alleles))) + geom_vline(xintercept=0, size=1) +
  scale_color_brewer(palette="Dark2") + theme_bw() + theme(legend.title = element_blank(),legend.position = "none",axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_density(size=1) + xlim(-0.5, 0.75) + ylim(0,15)
#A10
F005_M005_A10_dens <- ggplot(F005_m005_no0_A10, aes(x = qdif, colour = interaction(loci, alleles))) + geom_vline(xintercept=0, size=1) +
  scale_color_brewer(palette="Dark2") + theme_bw() + theme(legend.title = element_blank(),legend.position = "none",axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_density(size=1) + xlim(-0.5, 0.75) + ylim(0,15) 

grid.arrange(F005_M005_A2_dens, F005_M005_A5_dens, F005_M005_A10_dens, ncol=1)


# Data fst 0.05 migration 0.01 ----
F005_A2_L10_M001 <- cbind(Fst=0.05, alleles=2, loci = 10, m=0.01, rep="F005_A2_L10_M001", read.table("Fst0.05_NAl2_NMar10_M0.01_N200", header=T, dec = "."))
F005_A2_L10_M001 <- cbind (qdif= F005_A2_L10_M001$Structure_q_values - F005_A2_L10_M001$real_q_values, F005_A2_L10_M001)
F005_A2_L10_M001_no0 <- top(F005_A2_L10_M001, 100, 12, 7)
h46 <- hist(F005_A2_L10_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A2 M10')
rm(F005_A2_L10_M001)

F005_A5_L10_M001 <- cbind(Fst=0.05, alleles=5, loci = 10, m=0.01, rep="F005_A5_L10_M001", read.table("Fst0.05_NAl5_NMar10_M0.01_N200", header=T, dec = "."))
F005_A5_L10_M001 <- cbind (qdif= F005_A5_L10_M001$Structure_q_values - F005_A5_L10_M001$real_q_values, F005_A5_L10_M001)
F005_A5_L10_M001_no0 <- top(F005_A5_L10_M001, 100, 12, 7)
h47 <- hist(F005_A5_L10_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A5 M10')
rm(F005_A5_L10_M001)

F005_A10_L10_M001 <- cbind(Fst=0.05, alleles=10, loci = 10, m=0.01, rep="F005_A10_L10_M001", read.table("Fst0.05_NAl10_NMar10_M0.01_N200", header=T, dec = "."))
F005_A10_L10_M001 <- cbind (qdif= F005_A10_L10_M001$Structure_q_values - F005_A10_L10_M001$real_q_values, F005_A10_L10_M001)
F005_A10_L10_M001_no0 <- top(F005_A10_L10_M001, 100, 12, 7)
h48 <- hist(F005_A10_L10_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A10 M10')
rm(F005_A10_L10_M001)

F005_A2_L30_M001 <- cbind(Fst=0.05, alleles=2, loci = 30, m=0.01, rep="F005_A2_L30_M001", read.table("Fst0.05_NAl2_NMar30_M0.01_N200", header=T, dec = "."))
F005_A2_L30_M001 <- cbind (qdif= F005_A2_L30_M001$Structure_q_values - F005_A2_L30_M001$real_q_values, F005_A2_L30_M001)
F005_A2_L30_M001_no0 <- top(F005_A2_L30_M001, 100, 12, 7)
h49 <- hist(F005_A2_L30_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A2 M30')
rm(F005_A2_L30_M001)

F005_A5_L30_M001 <- cbind(Fst=0.05, alleles=5, loci = 30, m=0.01, rep="F005_A5_L30_M001", read.table("Fst0.05_NAl5_NMar30_M0.01_N200", header=T, dec = "."))
F005_A5_L30_M001 <- cbind (qdif= F005_A5_L30_M001$Structure_q_values - F005_A5_L30_M001$real_q_values, F005_A5_L30_M001)
F005_A5_L30_M001_no0 <- top(F005_A5_L30_M001, 100, 12, 7)
h50 <- hist(F005_A5_L30_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A5 M30')
rm(F005_A5_L30_M001)

F005_A10_L30_M001 <- cbind(Fst=0.05, alleles=10, loci = 30, m=0.01, rep="F005_A10_L30_M001", read.table("Fst0.05_NAl10_NMar30_M0.01_N200", header=T, dec = "."))
F005_A10_L30_M001 <- cbind (qdif= F005_A10_L30_M001$Structure_q_values - F005_A10_L30_M001$real_q_values, F005_A10_L30_M001)
F005_A10_L30_M001_no0 <- top(F005_A10_L30_M001, 100, 12, 7)
h51 <- hist(F005_A5_L30_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A5 M30')
rm(F005_A10_L30_M001)

F005_A2_L100_M001 <- cbind(Fst=0.05, alleles=2, loci = 100, m=0.01, rep="F005_A2_L100_M001", read.table("Fst0.05_NAl2_NMar100_M0.01_N200", header=T, dec = "."))
F005_A2_L100_M001 <- cbind (qdif= F005_A2_L100_M001$Structure_q_values - F005_A2_L100_M001$real_q_values, F005_A2_L100_M001)
F005_A2_L100_M001_no0 <- top(F005_A2_L100_M001, 100, 12, 7)
h52 <- hist(F005_A2_L100_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A2 M100')
rm(F005_A2_L100_M001)

F005_A5_L100_M001 <- cbind(Fst=0.05, alleles=5, loci = 100, m=0.01, rep="F005_A5_L100_M001", read.table("Fst0.05_NAl5_NMar100_M0.01_N200", header=T, dec = "."))
F005_A5_L100_M001 <- cbind (qdif= F005_A5_L100_M001$Structure_q_values - F005_A5_L100_M001$real_q_values, F005_A5_L100_M001)
F005_A5_L100_M001_no0 <- top(F005_A5_L100_M001, 100, 12, 7)
h53 <- hist(F005_A5_L100_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A5 M100')
rm(F005_A5_L100_M001)

F005_A10_L100_M001 <- cbind(Fst=0.05, alleles=10, loci = 100, m=0.01, rep="F005_A10_L100_M001", read.table("Fst0.05_NAl10_NMar100_M0.01_N200", header=T, dec = "."))
F005_A10_L100_M001 <- cbind (qdif= F005_A10_L100_M001$Structure_q_values - F005_A10_L100_M001$real_q_values, F005_A10_L100_M001)
F005_A10_L100_M001_no0 <- top(F005_A10_L100_M001, 100, 12, 7)
h54 <- hist(F005_A10_L100_M001_no0$qdif, xlim = c(-1, 1), ylim = c(0, 7500), xlab = 'qStructure-qreal', main = 'A5 M100')
rm(F005_A10_L100_M001)


F005_m001_no0 <- rbind(F005_A2_L10_M001_no0, F005_A5_L10_M001_no0, F005_A10_L10_M001_no0, 
                       F005_A2_L30_M001_no0, F005_A5_L30_M001_no0, F005_A10_L30_M001_no0,
                       F005_A2_L100_M001_no0,F005_A5_L100_M001_no0, F005_A10_L100_M001_no0)
F005_m001_no0_A2 <- rbind(F005_A2_L10_M001_no0, F005_A2_L30_M001_no0, F005_A2_L100_M001_no0)
F005_m001_no0_A5 <- rbind(F005_A5_L10_M001_no0, F005_A5_L30_M001_no0, F005_A5_L100_M001_no0)
F005_m001_no0_A10 <- rbind(F005_A10_L10_M001_no0,F005_A10_L30_M001_no0, F005_A10_L100_M001_no0)

#A2
F005_M001_A2_dens <- ggplot(F005_m001_no0_A2, aes(x = qdif, colour=interaction(loci, alleles))) + geom_vline(xintercept=0, size=1) +
  scale_color_brewer(palette="Dark2") + theme_bw() + theme(legend.title = element_blank(),legend.position = "none",axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_density(size=1) + xlim(-0.5, 0.75) + ylim(0,15) 
#A5
F005_M001_A5_dens <- ggplot(F005_m001_no0_A5, aes(x = qdif, colour = interaction(loci, alleles))) + geom_vline(xintercept=0, size=1) +
  scale_color_brewer(palette="Dark2") + theme_bw() + theme(legend.title = element_blank(),legend.position = "none",axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_density(size=1) + xlim(-0.5, 0.75) + ylim(0,15) 
#A10
F005_M001_A10_dens <- ggplot(F005_m001_no0_A10, aes(x = qdif, colour = interaction(loci, alleles))) + geom_vline(xintercept=0, size=1) +
  scale_color_brewer(palette="Dark2") + theme_bw() + theme(legend.title = element_blank(),legend.position = "none",axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_density(size=1) + xlim(-0.5, 0.75) + ylim(0,15) 

grid.arrange(F005_M001_A2_dens, F005_M001_A5_dens, F005_M001_A10_dens, ncol=1)


#Reference test: reference 200 and 5 admixed with independent allele frequencies----
par(mfrow=c(1,2))
#30 markers and 5 alleles
h55 <- hist(F01_A10_L30_N205_reference_corr_no0_no1$qdif, xlim = c(-0.6, 0.6), ylim = c(0, 350), xlab = 'qStructure-qreal', main = 'F01_A10_L30_N205_reference_corr_no0_no1')
#30 markers and 10 alleles
h56 <- hist(F01_A5_L30_N205_reference_corr_no0_no1$qdif, xlim = c(-0.4, 0.4), ylim = c(0, 350), xlab = 'qStructure-qreal', main = 'F01_A5_L30_N205_reference_corr_no0_no1')
#100 markers and 5 alleles
h57 <- hist(F01_A10_L100_N205_reference_corr_no0_no1$qdif, xlim = c(-0.6, 0.6), ylim = c(0, 350), xlab = 'qStructure-qreal', main = 'F01_A10_L100_N205_reference_corr_no0_no1')
#100 markers and 10 alleles
h58 <- hist(F01_A5_L100_N205_reference_corr_no0_no1$qdif, xlim = c(-0.4, 0.4), ylim = c(0, 350), xlab = 'qStructure-qreal', main = 'F01_A5_L100_N205_reference_corr_no0_no1')


