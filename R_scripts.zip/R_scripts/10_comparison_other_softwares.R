#software comparison: non parametric tests and plots

library(ggplot2)
library(gridExtra)
require(coin)
library(cowplot)

c11 <- ggplot(data= F01_A2_L100_M001_str, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))

wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L100_M001_str_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L100_M001_str_no0, paired = TRUE)

c12 <- ggplot(data= F01_A2_L100_M005_str, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))

wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L100_M005_str_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L100_M005_str_no0, paired = TRUE)

c11_adm <- ggplot(data= F01_A2_L100_M001_N200_admixture, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))

wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L100_M001_N200_admixture_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L100_M001_N200_admixture_no0, paired = TRUE)

c12_adm <- ggplot(data= F01_A2_L100_M005_N200_admixture, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))

wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L100_M005_N200_admixture_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L100_M005_N200_admixture_no0, paired = TRUE)

c11_ohana <- ggplot(data= F01_A2_L100_M001_N200_ohana, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))

wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L100_M001_N200_ohana_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L100_M001_N200_ohana_no0, paired = TRUE)

c12_ohana <- ggplot(data= F01_A2_L100_M005_N200_ohana, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))

wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L100_M005_N200_ohana_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L100_M005_N200_ohana_no0, paired = TRUE)

c11_snmf <- ggplot(data= F01_A2_L100_M001_N200_snmf, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))

wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L100_M001_N200_snmf_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L100_M001_N200_snmf_no0, paired = TRUE)

c12_snmf <- ggplot(data= F01_A2_L100_M005_N200_snmf, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))

wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L100_M005_N200_snmf_no0, paired = TRUE, alternative = "greater")
wilcoxsign_test(Structure_q_values ~ real_q_values, data = F01_A2_L100_M005_N200_snmf_no0, paired = TRUE)


#plots ---
dataset_softwares$m <- as.factor(dataset_softwares$m)
levels(dataset_softwares$m)
levels(dataset_softwares$m) <- c("Hybridization rate 1%", "Hybridization rate 5%")

plot.software <- ggplot(dataset_softwares, aes(real_q_values, Structure_q_values)) + 
  theme_bw() + 
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1)) +
  facet_grid(m ~ software) + xlab(expression('q'['real'])) + ylab(expression('q'['estimated'])) + 
  theme(strip.text.x = element_text(size = 12), strip.text.y = element_text(size = 12), strip.text = element_text(size = 20)) +
  theme(axis.text=element_text(size=10)) +
  background_grid(major = 'y', minor = "x") + # add thin horizontal lines 
  panel_border() # and a border around each panel

plot.software
