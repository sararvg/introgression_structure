### Inclusion of reference individuals from the ancestral population in Structure analysis: plots and models

## Plots ----

# without reference -> F01_L30_A5_M005:plot28 - F01_L30_A5_M001:plot27 -  F01_L30_A10_M005:plot46 - F01_L30_A10_M001:plot45  

# with 30% reference and popinfo OFF
p1_ref30_OFF <- qplot(F01_A5_L30_M005_ref30$real_q_values, F01_A5_L30_M005_ref30$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_M005_ref30_popinfoOFF') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p2_ref30_OFF <- qplot(F01_A10_L30_M005_ref30$real_q_values, F01_A10_L30_M005_ref30$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_M005_ref30_popinfoOFF') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p3_ref30_OFF <- qplot(F01_A5_L30_M001_ref30$real_q_values, F01_A5_L30_M001_ref30$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_M001_ref30_popinfoOFF') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p4_ref30_OFF <- qplot(F01_A10_L30_M001_ref30$real_q_values, F01_A10_L30_M001_ref30$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_M001_ref30_popinfoOFF') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

# with 30% reference and popinfo OFF
p1_ref30_ON <- qplot(F01_A5_L30_M005_ref30_popinfo$real_q_values, F01_A5_L30_M005_ref30_popinfo$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_M005_ref30_popinfoON') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p2_ref30_ON <- qplot(F01_A10_L30_M005_ref30_popinfo$real_q_values, F01_A10_L30_M005_ref30_popinfo$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_M005_ref30_popinfoON') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p3_ref30_ON <- qplot(F01_A5_L30_M001_ref30_popinfo$real_q_values, F01_A5_L30_M001_ref30_popinfo$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_M001_ref30_popinfoON') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p4_ref30_ON <- qplot(F01_A10_L30_M001_ref30_popinfo$real_q_values, F01_A10_L30_M001_ref30_popinfo$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_M001_ref30_popinfoON') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

grid.arrange(plot28, p1_ref30_OFF, p1_ref30_ON, plot46, p2_ref30_OFF, p2_ref30_ON, plot27, p3_ref30_OFF, p3_ref30_ON, plot45, p4_ref30_OFF, p4_ref30_ON, ncol = 3)

# with 10% reference and popinfo OFF
p1_ref10_OFF <- qplot(F01_A5_L30_M005_ref10$real_q_values, F01_A5_L30_M005_ref10$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_M005_ref10_popinfoOFF') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p2_ref10_OFF <- qplot(F01_A10_L30_M005_ref10$real_q_values, F01_A10_L30_M005_ref10$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_M005_ref10_popinfoOFF') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p3_ref10_OFF <- qplot(F01_A5_L30_M001_ref10$real_q_values, F01_A5_L30_M001_ref10$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_M001_ref10_popinfoOFF') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p4_ref10_OFF <- qplot(F01_A10_L30_M001_ref10$real_q_values, F01_A10_L30_M001_ref10$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_M001_ref10_popinfoOFF') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

# with 10% reference and popinfo OFF
p1_ref10_ON <- qplot(F01_A5_L30_M005_ref10_popinfo$real_q_values, F01_A5_L30_M005_ref10_popinfo$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_M005_ref10_popinfoON') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p2_ref10_ON <- qplot(F01_A10_L30_M005_ref10_popinfo$real_q_values, F01_A10_L30_M005_ref10_popinfo$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_M005_ref10_popinfoON') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p3_ref10_ON <- qplot(F01_A5_L30_M001_ref10_popinfo$real_q_values, F01_A5_L30_M001_ref10_popinfo$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_M001_ref10_popinfoON') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p4_ref10_ON <- qplot(F01_A10_L30_M001_ref10_popinfo$real_q_values, F01_A10_L30_M001_ref10_popinfo$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_M001_ref10_popinfoON') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

grid.arrange(plot28, p1_ref10_OFF, p1_ref10_ON, plot46, p2_ref10_OFF, p2_ref10_ON, plot27, p3_ref10_OFF, p3_ref10_ON, plot45, p4_ref10_OFF, p4_ref10_ON, ncol = 3)

grid.arrange(plot28, p1_ref10_OFF, p1_ref10_ON, p1_ref30_OFF, p1_ref30_ON, plot46, p2_ref10_OFF, p2_ref10_ON, p2_ref30_OFF, p2_ref30_ON, plot27, p3_ref10_OFF, p3_ref10_ON, p3_ref30_OFF, p3_ref30_ON, plot45, p4_ref10_OFF, p4_ref10_ON, p4_ref30_OFF, p4_ref30_ON, ncol = 5)
 

## Plots for 50 individuals ----

# no reference set to 0 

F01_A5_L30_M005_no0["reference"] <- 0   #p5
F01_A10_L30_M005_no0["reference"] <- 0  #p6
F01_A5_L30_M001_no0["reference"] <- 0   #p14
F01_A10_L30_M001_no0["reference"] <- 0  #p15

#valores absolutos qdif
F01_A5_L30_M005_no0$qdif_abs <- abs(F01_A5_L30_M005_no0$qdif)     #p5
F01_A10_L30_M005_no0$qdif_abs <- abs(F01_A10_L30_M005_no0$qdif)   #p6
F01_A5_L30_M001_no0$qdif_abs <- abs(F01_A5_L30_M001_no0$qdif)     #p14
F01_A10_L30_M001_no0$qdif_abs <- abs(F01_A10_L30_M001_no0$qdif)   #p15

F01_A5_L30_M005_ref_no0_no1$qdif_abs <- abs(F01_A5_L30_M005_ref_no0_no1$qdif)   #p5_ref_no1
F01_A10_L30_M005_ref_no0_no1$qdif_abs <- abs(F01_A10_L30_M005_ref_no0_no1$qdif) #p6_ref_no1
F01_A5_L30_M001_ref_no0_no1$qdif_abs <- abs(F01_A5_L30_M001_ref_no0_no1$qdif)   #p14_ref_no1
F01_A10_L30_M001_ref_no0_no1$qdif_abs <- abs(F01_A10_L30_M001_ref_no0_no1$qdif) #p15_ref_no1
  

#plot valores absolutos qdif
qdif_abs5 <- ggplot(data= F01_A5_L30_M005_no0, aes(x=real_q_values, y=qdif_abs)) + labs(title = "F01_A5_L30_M005_no0", x= "real_q_values", y = "qdif_abs")  + theme_bw() + geom_point(size=1, colour=I(alpha("blue",1/15))) + geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(0,0.8), xlim=c(0,1))
qdif_abs6 <- ggplot(data= F01_A10_L30_M005_no0, aes(x=real_q_values, y=qdif_abs)) + labs(title = "F01_A10_L30_M005_no0", x= "real_q_values", y = "qdif_abs")  + theme_bw() + geom_point(size=1, colour=I(alpha("blue",1/15))) + geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(0,0.8), xlim=c(0,1))
qdif_abs14 <- ggplot(data= F01_A5_L30_M001_no0, aes(x=real_q_values, y=qdif_abs)) + labs(title = "F01_A5_L30_M001_no0", x= "real_q_values", y = "qdif_abs")  + theme_bw() + geom_point(size=1, colour=I(alpha("blue",1/15))) + geom_abline(slope = 0, intercept = 0, color="blue")  + coord_cartesian(ylim=c(0,0.8), xlim=c(0,1))
qdif_abs15 <- ggplot(data= F01_A10_L30_M001_no0, aes(x=real_q_values, y=qdif_abs)) + labs(title = "F01_A10_L30_M001_no0", x= "real_q_values", y = "qdif_abs")  + theme_bw() + geom_point(size=1, colour=I(alpha("blue",1/15))) + geom_abline(slope = 0, intercept = 0, color="blue")  + coord_cartesian(ylim=c(0,0.8), xlim=c(0,1))
qdif_abs5_ref_no1 <- ggplot(data= F01_A5_L30_M005_ref_no0_no1, aes(x=real_q_values, y=qdif_abs)) + labs(title = "F01_A5_L30_M005_ref_no0_no1", x= "real_q_values", y = "qdif_abs")  + theme_bw() + geom_point(size=1, colour=I(alpha("blue",1/15))) + geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(0,0.8), xlim=c(0,1))
qdif_abs6_ref_no1 <- ggplot(data= F01_A10_L30_M005_ref_no0_no1, aes(x=real_q_values, y=qdif_abs)) + labs(title = "F01_A10_L30_M005_ref_no0_no1", x= "real_q_values", y = "qdif_abs")  + theme_bw() + geom_point(size=1, colour=I(alpha("blue",1/15))) + geom_abline(slope = 0, intercept = 0, color="blue")  + coord_cartesian(ylim=c(0,0.8), xlim=c(0,1))  
qdif_abs14_ref_no1 <- ggplot(data= F01_A5_L30_M001_ref_no0_no1, aes(x=real_q_values, y=qdif_abs)) + labs(title = "F01_A5_L30_M001_ref_no0_no1", x= "real_q_values", y = "qdif_abs")  + theme_bw() + geom_point(size=1, colour=I(alpha("blue",1/15))) + geom_abline(slope = 0, intercept = 0, color="blue")  + coord_cartesian(ylim=c(0,0.8), xlim=c(0,1)) 
qdif_abs15_ref_no1 <- ggplot(data= F01_A10_L30_M001_ref_no0_no1, aes(x=real_q_values, y=qdif_abs)) + labs(title = "F01_A10_L30_M001_ref_no0_no1", x= "real_q_values", y = "qdif_abs")  + theme_bw() + geom_point(size=1, colour=I(alpha("blue",1/15))) + geom_abline(slope = 0, intercept = 0, color="blue")  + coord_cartesian(ylim=c(0,0.8), xlim=c(0,1)) 

grid.arrange(qdif_abs5, qdif_abs5_ref_no1, qdif_abs6, qdif_abs6_ref_no1, qdif_abs14, qdif_abs14_ref_no1, qdif_abs15, qdif_abs15_ref_no1, ncol = 2)


p5_ref_no1 <- ggplot(data= F01_A5_L30_M005_ref_no0_no1, aes(x=real_q_values, y=Structure_q_values)) + labs(title = "F01_A5_L30_M005_ref_no0_no1", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + theme(plot.title = element_text(size = 10, face = "bold")) + theme(axis.title = element_text(size = 8)) +
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + geom_abline(slope = 1, intercept = 0, color="blue")

p1a <- qplot(F01_A5_L30_M005_ref_no0_no1$real_q_values, F01_A5_L30_M005_ref_no0_no1$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_M005_ref_no0_no1') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))


p6_ref_no1 <- ggplot(data= F01_A10_L30_M005_ref_no0_no1, aes(x=real_q_values, y=Structure_q_values)) + labs(title = "F01_A10_L30_M005_ref_no0_no1", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + theme(plot.title = element_text(size = 10, face = "bold")) + theme(axis.title = element_text(size = 8)) +
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + geom_abline(slope = 1, intercept = 0, color="blue")

p1b <- qplot(F01_A10_L30_M005_ref_no0_no1$real_q_values, F01_A10_L30_M005_ref_no0_no1$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_M005_ref_no0_no1') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))


p14_ref_no1 <- ggplot(data= F01_A5_L30_M001_ref_no0_no1, aes(x=real_q_values, y=Structure_q_values)) +  labs(title = "F01_A5_L30_M001_ref_no0_no1", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + theme(plot.title = element_text(size = 10, face = "bold")) + theme(axis.title = element_text(size = 8)) +
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + geom_abline(slope = 1, intercept = 0, color="blue")

p1c <- qplot(F01_A5_L30_M001_ref_no0_no1$real_q_values, F01_A5_L30_M001_ref_no0_no1$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_M001_ref_no0_no1') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))


p15_ref_no1 <- ggplot(data= F01_A10_L30_M001_ref_no0_no1, aes(x=real_q_values, y=Structure_q_values)) + labs(title = "F01_A10_L30_M001_ref_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + theme(plot.title = element_text(size = 10, face = "bold")) + theme(axis.title = element_text(size = 8)) +
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + geom_abline(slope = 1, intercept = 0, color="blue")

p1d <- qplot(F01_A10_L30_M001_ref_no0_no1$real_q_values, F01_A10_L30_M001_ref_no0_no1$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_M001_ref_no0') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))


p5 <- ggplot(data= F01_A5_L30_M005_no0, aes(x=real_q_values, y=Structure_q_values)) + labs(title = "F01_A5_L30_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + theme(plot.title = element_text(size = 10, face = "bold")) + theme(axis.title = element_text(size = 8)) +
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + geom_abline(slope = 1, intercept = 0, color="blue")

p1e <- qplot(F01_A5_L30_M005_no0$real_q_values, F01_A5_L30_M005_no0$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_M005_no0') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))


p6 <- ggplot(data= F01_A10_L30_M005_no0, aes(x=real_q_values, y=Structure_q_values)) +  labs(title = "F01_A10_L30_M005_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + theme(plot.title = element_text(size = 10, face = "bold")) + theme(axis.title = element_text(size = 8)) + 
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_abline(slope = 1, intercept = 0, color="blue")

p1f <- qplot(F01_A10_L30_M005_no0$real_q_values, F01_A10_L30_M005_no0$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_M005_no0') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))


p14 <- ggplot(data= F01_A5_L30_M001_no0, aes(x=real_q_values, y=Structure_q_values)) + labs(title = "F01_A5_L30_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + theme(plot.title = element_text(size = 10, face = "bold")) + theme(axis.title = element_text(size = 8)) +
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + geom_abline(slope = 1, intercept = 0, color="blue")

p1g <- qplot(F01_A5_L30_M001_no0$real_q_values, F01_A5_L30_M001_no0$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_M001_no0') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))


p15 <- ggplot(data= F01_A10_L30_M001_no0, aes(x=real_q_values, y=Structure_q_values)) + labs(title = "F01_A10_L30_M001_no0", x= "real_q_values", y = "Structure_q_values")  + theme_bw() + theme(plot.title = element_text(size = 10, face = "bold")) + theme(axis.title = element_text(size = 8)) +
  geom_point(size=1, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + geom_abline(slope = 1, intercept = 0, color="blue")

p1h <- qplot(F01_A10_L30_M001_no0$real_q_values, F01_A10_L30_M001_no0$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_M001_no0') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))


grid.arrange(p1a, p1b, p1e, p1f, p1c, p1d, p1g, p1h, ncol = 2)
grid.arrange(p1e, p1a, p1f, p1b, p1g, p1c, p1h, p1d, ncol = 2)

#absolute values of difference between q structure and q real 
F01_A5_L30_M005_no0$qdif_abs <- abs(F01_A5_L30_M005_no0$qdif)     #p5
F01_A10_L30_M005_no0$qdif_abs <- abs(F01_A10_L30_M005_no0$qdif)   #p6
F01_A5_L30_M001_no0$qdif_abs <- abs(F01_A5_L30_M001_no0$qdif)     #p14
F01_A10_L30_M001_no0$qdif_abs <- abs(F01_A10_L30_M001_no0$qdif)   #p15

F01_A5_L30_M005_ref_no0_no1$qdif_abs <- abs(F01_A5_L30_M005_ref_no0_no1$qdif)   #p5_ref_no1
F01_A10_L30_M005_ref_no0_no1$qdif_abs <- abs(F01_A10_L30_M005_ref_no0_no1$qdif) #p6_ref_no1
F01_A5_L30_M001_ref_no0_no1$qdif_abs <- abs(F01_A5_L30_M001_ref_no0_no1$qdif)   #p14_ref_no1
F01_A10_L30_M001_ref_no0_no1$qdif_abs <- abs(F01_A10_L30_M001_ref_no0_no1$qdif) #p15_ref_no1


# Models for both m ----

#test with alleles, reference, migration
F01_L30_reftest2_no0_no1$qdif_abs <- abs(F01_L30_reftest2_no0_no1$qdif)
m <- betareg(qdif_abs ~ reference + alleles + m, F01_L30_reftest2_no0_no1)
res <- residuals(m, type= "pearson")
qqnorm(res); qqline(res)   #residuals NOT normal
summary(m, type="pearson")

#test with alleles, reference, migration, popinfo (as factors)
F01_L30_reftest2_no0_no1$qdif_abs <- abs(F01_L30_reftest2_no0_no1$qdif)
F01_L30_reftest2_no0_no1$m <- as.factor(F01_L30_reftest2_no0_no1$m)
F01_L30_reftest2_no0_no1$alleles <- as.factor(F01_L30_reftest2_no0_no1$alleles)
m <- betareg(qdif_abs ~ reference + alleles + m + popinfo, F01_L30_reftest2_no0_no1)
res <- residuals(m, type= "pearson")
qqnorm(res); qqline(res)   #residuals NOT normal
summary(m, type="pearson")

#test with alleles, migration, popinfo (as factors)
F01_L30_reftest2_no0_no1$qdif_abs <- abs(F01_L30_reftest2_no0_no1$qdif)
F01_L30_reftest2_no0_no1$m <- as.factor(F01_L30_reftest2_no0_no1$m)
F01_L30_reftest2_no0_no1$alleles <- as.factor(F01_L30_reftest2_no0_no1$alleles)
m <- betareg(qdif_abs ~ alleles + m + popinfo, F01_L30_reftest2_no0_no1)
res <- residuals(m, type= "pearson")
qqnorm(res); qqline(res)   #residuals NOT normal
summary(m, type="pearson")

grid.arrange(qdif_abs5, qdif_abs5_ref_no1, qdif_abs6, qdif_abs6_ref_no1, ncol = 2)


# Models for m=0.05

#test with alleles, reference (as factors): m 0.05
reftest2_m005_no0_no1$qdif_abs <- abs(reftest2_m005_no0_no1$qdif)
#reftest2_m005_no0_no1$m <- as.factor(reftest2_m005_no0_no1$m)
reftest2_m005_no0_no1$alleles <- as.factor(reftest2_m005_no0_no1$alleles)
m <- betareg(qdif_abs ~ reference + alleles, reftest2_m005_no0_no1)
res <- residuals(m, type= "pearson")
qqnorm(res); qqline(res)   #residuals normal!
summary(m, type="pearson")

#test with alleles, reference, popinfo   
#reftest2_m005_no0_no1$qdif_abs <- abs(reftest2_m005_no0_no1$qdif)
m <- betareg(qdif_abs ~ reference + alleles + popinfo, reftest2_m005_no0_no1)
res <- residuals(m, type= "pearson")
qqnorm(res); qqline(res)    #residuals normal!
summary(m, type="pearson")

#test with alleles, reference, popinfo (reference as numeric) ----> we selected this MODEL!! 
#reftest2_m005_no0_no1$qdif_abs <- abs(reftest2_m005_no0_no1$qdif)
reftest2_m005_no0_no1$alleles <- as.numeric(reftest2_m005_no0_no1$alleles)
reftest2_m005_no0_no1$reference <- as.numeric(reftest2_m005_no0_no1$reference)
m <- betareg(qdif_abs ~ reference + alleles + popinfo, reftest2_m005_no0_no1)
res <- residuals(m, type= "pearson")
qqnorm(res); qqline(res)
summary(m, type="pearson")

# Models for m=0.01

#test with alleles, reference, popinfo
reftest2_m001_no0_no1$qdif_abs <- abs(reftest2_m001_no0_no1$qdif)
m <- betareg(qdif_abs ~ reference + alleles + popinfo, reftest2_m001_no0_no1)
res <- residuals(m, type= "pearson")
qqnorm(res); qqline(res)     #residuals NOT normal
summary(m, type="pearson")

reftest2_m001_no0_no1$alleles <- as.numeric(reftest2_m001_no0_no1$alleles)
reftest2_m001_no0_no1$reference <- as.numeric(reftest2_m001_no0_no1$reference)
m <- betareg(qdif_abs ~ reference + alleles + popinfo, reftest2_m001_no0_no1)
res <- residuals(m, type= "pearson")
qqnorm(res); qqline(res)
summary(m, type="pearson")

#plots 5 reference out of 50----

# without reference fst 0.1 markers 30 alleles 5 migration 0.05
read.table("Fst0.1_NAl5_NMar30_M0.05_N100", header=T, sep=" ")-> condition57
p1c <- qplot(condition57$real_q_values, condition57$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', 
             xlab='real q values', main = 'NAl_5_NMar_30_m_005_no_reference_N_50') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

# with reference fst 0.1 markers 30 alleles 5 migration 0.05
read.table("Fst0.1_NAl5_NMar30_M0.05_N100_reference", header=T, sep=" ")-> ref_455_5_005
p2c <- qplot(ref_455_5_005$real_q_values, ref_455_5_005$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', 
             xlab='real q values', main = 'NAl_5_NMar_30_m_005_reference_5_N_50') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

# without reference fst 0.1 markers 30 alleles 10 migration 0.05
read.table("Fst0.1_NAl10_NMar30_M0.05_N100", header=T, sep=" ")-> condition60
p3c <- qplot(condition60$real_q_values, condition60$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', 
             xlab='real q values', main = 'NAl_10_NMar_30_m_005_no_reference_N_50') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

# with reference fst 0.1 markers 30 alleles 10 migration 0.05
read.table("Fst0.1_NAl10_NMar30_M0.05_N100_reference", header=T, sep=" ")-> ref_455_10_005
p4c <- qplot(ref_455_10_005$real_q_values, ref_455_10_005$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', 
             xlab='real q values', main = 'NAl_10_NMar_30_m_005_reference_10_N_50') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

grid.arrange(p1c, p2c, p3c, p4c, ncol = 2)

# without reference fst 0.1 markers 30 alleles 5 migration 0.01
read.table("Fst0.1_NAl5_NMar30_M0.01_N200", header=T, sep=" ")-> condition58
p5c <- qplot(condition58$real_q_values, condition58$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', 
             xlab='real q values', main = 'NAl_5_NMar_30_m_0.01_no_reference_N_50') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

# with reference fst 0.1 markers 30 alleles 5 migration 0.01
read.table("Fst0.1_NAl5_NMar30_M0.01_N100_reference", header=T, sep=" ")-> ref_455_5_001
p6c <- qplot(ref_455_5_001$real_q_values, ref_455_5_001$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', 
             xlab='real q values', main = 'NAl_5_NMar_30_m_0.01_reference_5_N_50') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

# without reference fst 0.1 markers 30 alleles 10 migration 0.01
read.table("Fst0.1_NAl10_NMar30_M0.01_N100", header=T, sep=" ")-> condition59
p7c <- qplot(condition59$real_q_values, condition59$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', 
             xlab='real q values', main = 'NAl_10_NMar_30_m_0.01_no_reference_N_50') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

# with reference fst 0.1 markers 30 alleles 10 migration 0.01
read.table("Fst0.1_NAl10_NMar30_M0.01_N100_reference", header=T, sep=" ")-> ref_455_10_001
p8c <- qplot(ref_455_10_001$real_q_values, ref_455_10_001$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', 
             xlab='real q values', main = 'NAl_10_NMar_30_m_0.01_reference_5_N_50') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

grid.arrange(p5c, p6c, p7c, p8c, ncol = 2)


#plots 15 reference out of 50----

# without reference fst 0.1 markers 30 alleles 5 migration 0.05
read.table("Fst0.1_NAl5_NMar30_M0.05_N100", header=T, sep=" ")-> condition57
p1d <- qplot(condition57$real_q_values, condition57$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', 
             xlab='real q values', main = 'NAl_5_NMar_30_m_005_no_reference_N_50') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

# with reference fst 0.1 markers 30 alleles 5 migration 0.05
read.table("Fst0.1_NAl5_NMar30_M0.05_N100_reference", header=T, sep=" ")-> ref_3515_5_005
p2d <- qplot(ref_3515_5_005$real_q_values, ref_3515_5_005$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', 
             xlab='real q values', main = 'NAl_5_NMar_30_m_005_reference_15_N_50') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

# without reference fst 0.1 markers 30 alleles 10 migration 0.05
read.table("Fst0.1_NAl10_NMar30_M0.05_N100", header=T, sep=" ")-> condition60
p3d <- qplot(condition60$real_q_values, condition60$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', 
             xlab='real q values', main = 'NAl_10_NMar_30_m_005_no_reference_N_50') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

# with reference fst 0.1 markers 30 alleles 10 migration 0.05
read.table("Fst0.1_NAl10_NMar30_M0.05_N100_reference", header=T, sep=" ")-> ref_3515_10_005
p4d <- qplot(ref_3515_10_005$real_q_values, ref_3515_10_005$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', 
             xlab='real q values', main = 'NAl_10_NMar_30_m_005_reference_15_N_50') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

grid.arrange(p1d, p2d, p3d, p4d, ncol = 2)

# without reference fst 0.1 markers 30 alleles 5 migration 0.01
read.table("Fst0.1_NAl5_NMar30_M0.01_N100", header=T, sep=" ")-> condition58
p5d <- qplot(condition58$real_q_values, condition58$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', 
             xlab='real q values', main = 'NAl_5_NMar_30_m_0.01_no_reference_N_50') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

# with reference fst 0.1 markers 30 alleles 5 migration 0.01
read.table("Fst0.1_NAl5_NMar30_M0.01_N100_reference", header=T, sep=" ")-> ref_3515_5_001
p6d <- qplot(ref_3515_5_001$real_q_values, ref_3515_5_001$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', 
             xlab='real q values', main = 'NAl_5_NMar_30_m_0.01_reference_15_N_50') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

# without reference fst 0.1 markers 30 alleles 10 migration 0.01
read.table("Fst0.1_NAl10_NMar30_M0.01_N100", header=T, sep=" ")-> condition59
p7d <- qplot(condition59$real_q_values, condition59$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', 
             xlab='real q values', main = 'NAl_10_NMar_30_m_0.01_no_reference_N_50') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

# with reference fst 0.1 markers 30 alleles 10 migration 0.01
read.table("Fst0.1_NAl10_NMar30_M0.01_N100_reference", header=T, sep=" ")-> ref_3515_10_001
p8d <- qplot(ref_3515_10_001$real_q_values, ref_3515_10_001$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', 
             xlab='real q values', main = 'NAl_10_NMar_30_m_0.01_reference_15_N_50') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + 
  theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

grid.arrange(p5d, p6d, p7d, p8d, ncol = 2)

# all cases with 50 inidviduals: no reference, 5 out of 50, 15 out of 50

grid.arrange(p1d, p2c, p2d, p3d, p4c, p4d, p5d, p6c, p6d, p7d, p8c, p8d, ncol = 3)

# migration 0.01
grid.arrange(p5d, p6c, p6d, p7d, p8c, p8d, ncol = 3)

# migration 0.05
grid.arrange(p1d, p2c, p2d, p3d, p4c, p4d, ncol = 3)
