### plots representing qstructure values vs real values

# fst 0.1 migration 0.01 ----
plot7 <- ggplot(data= F01_A2_L10_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))#geom_abline(slope = 1, intercept = 0, color="blue")
plot9 <- ggplot(data= F01_A2_L30_M001, aes(x=real_q_values, y=Structure_q_values)) +
    theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
    geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
    geom_segment(aes(0, 0, xend = 1, yend = 1))
plot11 <- ggplot(data= F01_A2_L100_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot25 <- ggplot(data= F01_A5_L10_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot27 <- ggplot(data= F01_A5_L30_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot29 <- ggplot(data= F01_A5_L100_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot43 <- ggplot(data= F01_A10_L10_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot45 <- ggplot(data= F01_A10_L30_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot47 <- ggplot(data= F01_A10_L100_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))

grid.arrange(plot7, plot9, plot11, plot25, plot27, plot29, plot43, plot45, plot47, ncol = 3)

# fst 0.1 migration 0.05
plot8 <- ggplot(data= F01_A2_L10_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot10 <- ggplot(data= F01_A2_L30_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot12 <- ggplot(data= F01_A2_L100_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot26 <- ggplot(data= F01_A5_L10_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot28 <- ggplot(data= F01_A5_L30_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot30 <- ggplot(data= F01_A5_L100_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot44 <- ggplot(data= F01_A10_L10_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot46 <- ggplot(data= F01_A10_L30_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot48 <- ggplot(data= F01_A10_L100_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))

grid.arrange(plot8, plot10, plot12, plot26, plot28, plot30, plot44, plot46, plot48, ncol = 3)


# fst 0.05 migration 0.1 ----
plot1 <- ggplot(data= F005_A2_L10_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot3 <- ggplot(data= F005_A2_L30_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot5 <- ggplot(data= F005_A2_L100_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot19 <- ggplot(data= F005_A5_L10_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot21 <- ggplot(data= F005_A5_L30_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot23 <- ggplot(data= F005_A5_L100_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot37 <- ggplot(data= F005_A10_L10_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot39 <- ggplot(data= F005_A10_L30_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot41 <- ggplot(data= F005_A10_L100_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))

grid.arrange(plot1, plot3, plot5, plot19, plot21, plot23, plot37, plot39, plot41, ncol = 3)

# fst 0.05 migration 0.05 ----
plot2 <- ggplot(data= F005_A2_L10_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot4 <- ggplot(data= F005_A2_L30_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot6 <- ggplot(data= F005_A2_L100_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot20 <- ggplot(data= F005_A5_L10_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot22 <- ggplot(data= F005_A5_L30_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot24 <- ggplot(data= F005_A5_L100_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot38 <- ggplot(data= F005_A10_L10_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot40 <- ggplot(data= F005_A10_L30_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot42 <- ggplot(data= F005_A10_L100_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))

grid.arrange(plot2, plot4, plot6, plot20, plot22, plot24, plot38, plot40, plot42, ncol = 3)


# fst 0.2 migration 0.01 ----
plot13 <- ggplot(data= F02_A2_L10_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot15 <- ggplot(data= F02_A2_L30_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot17 <- ggplot(data= F02_A2_L100_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot31 <- ggplot(data= F02_A5_L10_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot33 <- ggplot(data= F02_A5_L30_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot35 <- ggplot(data= F02_A5_L100_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot49 <- ggplot(data= F02_A10_L10_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot51 <- ggplot(data= F02_A10_L30_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot53 <- ggplot(data= F02_A10_L100_M001, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))

grid.arrange(plot13, plot15, plot17, plot31, plot33, plot35, plot49, plot51, plot53, ncol = 3)

# fst 0.2 migration 0.05
plot14 <- ggplot(data= F02_A2_L10_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot16 <- ggplot(data= F02_A2_L30_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot18 <- ggplot(data= F02_A2_L100_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot32 <- ggplot(data= F02_A5_L10_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot34 <- ggplot(data= F02_A5_L30_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot36 <- ggplot(data= F02_A5_L100_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot50 <- ggplot(data= F02_A10_L10_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot52 <- ggplot(data= F02_A10_L30_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
plot54 <- ggplot(data= F02_A10_L100_M005, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))

grid.arrange(plot14, plot16, plot18, plot32, plot34, plot36, plot50, plot52, plot54, ncol = 3)


# test with DIFFERENT N
# fst 0.1 N 200 L30 m 0.01 and 0.05 ----
p1_200 <- qplot(F01_A5_L30_M001_N200$real_q_values, F01_A5_L30_M001_N200$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_M001_N200') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8)) #+ theme(axis.title.y = element_text(size = 8, face = "bold")) 
p2_200 <- qplot(F01_A10_L30_M001_N200$real_q_values, F01_A10_L30_M001_N200$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_M001_N200') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p3_200 <-qplot(F01_A5_L30_M005_N200$real_q_values, F01_A5_L30_M005_N200$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_M005_N200') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p4_200 <- qplot(F01_A10_L30_M005_N200$real_q_values, F01_A10_L30_M005_N200$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_M005_N200') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

grid.arrange(p1_200, p2_200, p3_200, p4_200, ncol = 2)

# fst 0.1 N 500 L30 m 0.01 and 0.05 ----
p1_500 <- qplot(F01_A5_L30_M001_N500$real_q_values, F01_A5_L30_M001_N500$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_M001_N500') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8)) #+ theme(axis.title.y = element_text(size = 8, face = "bold")) 
p2_500 <- qplot(F01_A10_L30_M001_N500$real_q_values, F01_A10_L30_M001_N500$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_M001_N500') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p3_500 <-qplot(F01_A5_L30_M005_N500$real_q_values, F01_A5_L30_M005_N500$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_M005_N500') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p4_500 <- qplot(F01_A10_L30_M005_N500$real_q_values, F01_A10_L30_M005_N500$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_M005_N500') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

grid.arrange(p1_500, p2_500, p3_500, p4_500, ncol = 2)

# test with INDEPENDENT allele frequency
# fst 0.1 N 100 L30 m 0.01 and 0.05 independent allele frequency ----
p1_L30_indep <- qplot(F01_A5_L30_M001_N100_indep$real_q_values, F01_A5_L30_M001_N100_indep$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_M001_N100_independent') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8)) #+ theme(axis.title.y = element_text(size = 8, face = "bold")) 
p2_L30_indep <- qplot(F01_A10_L30_M001_N100_indep$real_q_values, F01_A10_L30_M001_N100_indep$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_M001_N100_independent') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p3_L30_indep <-qplot(F01_A5_L30_M005_N100_indep$real_q_values, F01_A5_L30_M005_N100_indep$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_M005_N100_independent') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p4_L30_indep <- qplot(F01_A10_L30_M005_N100_indep$real_q_values, F01_A10_L30_M005_N100_indep$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_M005_N100_independent') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

grid.arrange(p1_L30_indep, p2_L30_indep, p3_L30_indep, p4_L30_indep, ncol = 2)

p1_L30_corr <- qplot(F01_A5_L30_M001$real_q_values, F01_A5_L30_M001$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_M001_N100_correlated') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8)) #+ theme(axis.title.y = element_text(size = 8, face = "bold")) 
p2_L30_corr <- qplot(F01_A10_L30_M001$real_q_values, F01_A10_L30_M001$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_M001_N100_correlated') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p3_L30_corr <-qplot(F01_A5_L30_M005$real_q_values, F01_A5_L30_M005$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_M005_N100_correlated') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p4_L30_corr <- qplot(F01_A10_L30_M005$real_q_values, F01_A10_L30_M005$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_M005_N100_correlated') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

grid.arrange(p1_L30_indep, p2_L30_indep, p1_L30_corr, p2_L30_corr, p3_L30_indep, p4_L30_indep, p3_L30_corr, p4_L30_corr, ncol = 2)

# fst 0.1 N 100 L100 m 0.01 and 0.05 independent allele frequency ----

p1_L100_indep <- qplot(F01_A5_L100_M001_N100_indep$real_q_values, F01_A5_L100_M001_N100_indep$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L100_M001_N100_independent') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8)) #+ theme(axis.title.y = element_text(size = 8, face = "bold")) 
p2_L100_indep <- qplot(F01_A10_L100_M001_N100_indep$real_q_values, F01_A10_L100_M001_N100_indep$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L100_M001_N100_independent') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p3_L100_indep <-qplot(F01_A5_L100_M005_N100_indep$real_q_values, F01_A5_L100_M005_N100_indep$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L100_M005_N100_independent') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p4_L100_indep <- qplot(F01_A10_L100_M005_N100_indep$real_q_values, F01_A10_L100_M005_N100_indep$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L100_M005_N100_independent') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

grid.arrange(p1_L100_indep, p2_L100_indep, p3_L100_indep, p4_L100_indep, ncol = 2)

p1_L100_corr <- qplot(F01_A5_L100_M001$real_q_values, F01_A5_L100_M001$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L100_M001_N100_correlated') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8)) #+ theme(axis.title.y = element_text(size = 8, face = "bold")) 
p2_L100_corr <- qplot(F01_A10_L100_M001$real_q_values, F01_A10_L100_M001$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L100_M001_N100_correlated') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p3_L100_corr <-qplot(F01_A5_L100_M005$real_q_values, F01_A5_L100_M005$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L100_M005_N100_correlated') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))
p4_L100_corr <- qplot(F01_A10_L100_M005$real_q_values, F01_A10_L100_M005$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L100_M005_N100_correlated') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

grid.arrange(p1_L100_indep, p2_L100_indep, p1_L100_corr, p2_L100_corr, p3_L100_indep, p4_L100_indep, p3_L100_corr, p4_L100_corr, ncol = 2)

grid.arrange(p1_L30_indep, p2_L30_indep, p1_L100_indep, p2_L100_indep, p1_L30_corr, p2_L30_corr, p1_L100_corr, p2_L100_corr,p3_L30_indep, p4_L30_indep, p3_L100_indep, p4_L100_indep, p3_L30_corr, p4_L30_corr, p3_L100_corr, p4_L100_corr, ncol = 4)


# reference test: fst 0.1 L 30 100 reference popA 100 popB 5 admixed independent allele frequency ----
p1_reference_indep <- qplot(F01_A5_L30_N205_reference_indep$real_q_values, F01_A5_L30_N205_reference_indep$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_N205_reference_indep') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8)) #+ theme(axis.title.y = element_text(size = 8, face = "bold")) 
p2_reference_indep <- qplot(F01_A10_L30_N205_reference_indep$real_q_values, F01_A10_L30_N205_reference_indep$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_N205_reference_indep') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

grid.arrange(p1_reference_indep, p2_reference_indep, ncol = 1)

p1_reference_indep_no0_no1 <- qplot(F01_A5_L30_N205_reference_indep_no0_no1$real_q_values, F01_A5_L30_N205_reference_indep_no0_no1$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_N205_reference_indep_no0_no1') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8)) #+ theme(axis.title.y = element_text(size = 8, face = "bold")) 
p2_reference_indep_no0_no1 <- qplot(F01_A10_L30_N205_reference_indep_no0_no1$real_q_values, F01_A10_L30_N205_reference_indep_no0_no1$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_N205_reference_indep_no0_no1') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8)) #+ theme(axis.title.y = element_text(size = 8, face = "bold")) 

grid.arrange(p1_reference_indep_no0_no1, p2_reference_indep_no0_no1, ncol = 1)

# reference test: fst 0.1 L 30 100 reference popA 100 popB 5 admixed correlated allele frequency ----
p1_reference_corr <- qplot(F01_A5_L30_N205_reference_corr$real_q_values, F01_A5_L30_N205_reference_corr$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L30_N205_reference_corr') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8)) #+ theme(axis.title.y = element_text(size = 8, face = "bold")) 
p2_reference_corr <- qplot(F01_A10_L30_N205_reference_corr$real_q_values, F01_A10_L30_N205_reference_corr$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L30_N205_reference_corr') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

grid.arrange(p1_reference_corr, p2_reference_corr, ncol = 1)

p1_reference_corr_no0_no1 <- ggplot(data= F01_A5_L30_N205_reference_corr_no0_no1, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
p2_reference_corr_no0_no1 <- ggplot(data= F01_A10_L30_N205_reference_corr_no0_no1, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))

grid.arrange(p1_reference_corr_no0_no1, p2_reference_corr_no0_no1, ncol = 1)

# graph correlated vs indepedent allele frequency 
grid.arrange(p1_reference_indep_no0_no1, p2_reference_indep_no0_no1, p1_reference_corr_no0_no1, p2_reference_corr_no0_no1, ncol = 2)


# reference test: fst 0.1 L 100 100 reference popA 100 popB 5 admixed correlated allele frequency ----
p3_reference_corr <- qplot(F01_A5_L100_N205_reference_corr$real_q_values, F01_A5_L100_N205_reference_corr$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A5_L100_N205_reference_corr') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8)) #+ theme(axis.title.y = element_text(size = 8, face = "bold")) 
p4_reference_corr <- qplot(F01_A10_L100_N205_reference_corr$real_q_values, F01_A10_L100_N205_reference_corr$Structure_q_values,colour=I(alpha("blue",1/15)), ylab='Structure q values', xlab='real q values', main = 'F01_A10_L100_N205_reference_corr') + geom_segment(aes(0, 0, xend = 1, yend = 1)) + theme(plot.title = element_text(size = 8, face = "bold")) + theme(axis.title = element_text(size = 8))

grid.arrange(p3_reference_corr, p4_reference_corr, ncol = 1)

p3_reference_corr_no0_no1 <- ggplot(data= F01_A5_L100_N205_reference_corr_no0_no1, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))
p4_reference_corr_no0_no1 <- ggplot(data= F01_A10_L100_N205_reference_corr_no0_no1, aes(x=real_q_values, y=Structure_q_values)) +
  theme_bw() + theme(axis.text.x=element_blank(),axis.title.x=element_blank(),axis.text.y=element_blank(),axis.title.y=element_blank()) +
  geom_point(size=0.7, colour=I(alpha("blue",1/15))) + coord_cartesian(ylim=c(0,1), xlim=c(0,1)) + 
  geom_segment(aes(0, 0, xend = 1, yend = 1))

grid.arrange(p3_reference_corr_no0_no1, p4_reference_corr_no0_no1, ncol = 1)

grid.arrange(p1_reference_corr_no0_no1, p2_reference_corr_no0_no1, p3_reference_corr_no0_no1, p4_reference_corr_no0_no1, ncol = 2)
