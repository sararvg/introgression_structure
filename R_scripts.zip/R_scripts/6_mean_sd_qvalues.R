### mean and SD q Structure and q real ----
#calculate mean and SD to check consistency of the simulations 

#Fst 0.1 M 0.05----
mean(F01_A2_L10_M005_no0$Structure_q_values)
sd(F01_A2_L10_M005_no0$Structure_q_values)
mean(F01_A2_L10_M005_no0$real_q_values)
sd(F01_A2_L10_M005_no0$real_q_values)

mean(F01_A2_L30_M005_no0$Structure_q_values)
sd(F01_A2_L30_M005_no0$Structure_q_values)
mean(F01_A2_L30_M005_no0$real_q_values)
sd(F01_A2_L30_M005_no0$real_q_values)

mean(F01_A2_L100_M005_no0$Structure_q_values)
sd(F01_A2_L100_M005_no0$Structure_q_values)
mean(F01_A2_L100_M005_no0$real_q_values)
sd(F01_A2_L100_M005_no0$real_q_values)

mean(F01_A5_L10_M005_no0$Structure_q_values)
sd(F01_A5_L10_M005_no0$Structure_q_values)
mean(F01_A5_L10_M005_no0$real_q_values)
sd(F01_A5_L10_M005_no0$real_q_values)

mean(F01_A5_L30_M005_no0$Structure_q_values)
sd(F01_A5_L30_M005_no0$Structure_q_values)
mean(F01_A5_L30_M005_no0$real_q_values)
sd(F01_A5_L30_M005_no0$real_q_values)

mean(F01_A5_L100_M005_no0$Structure_q_values)
sd(F01_A5_L100_M005_no0$Structure_q_values)
mean(F01_A5_L100_M005_no0$real_q_values)
sd(F01_A5_L100_M005_no0$real_q_values)

mean(F01_A10_L10_M005_no0$Structure_q_values)
sd(F01_A10_L10_M005_no0$Structure_q_values)
mean(F01_A10_L10_M005_no0$real_q_values)
sd(F01_A10_L10_M005_no0$real_q_values)

mean(F01_A10_L30_M005_no0$Structure_q_values)
sd(F01_A10_L30_M005_no0$Structure_q_values)
mean(F01_A10_L30_M005_no0$real_q_values)
sd(F01_A10_L30_M005_no0$real_q_values)

mean(F01_A10_L100_M005_no0$Structure_q_values)
sd(F01_A10_L100_M005_no0$Structure_q_values)
mean(F01_A10_L100_M005_no0$real_q_values)
sd(F01_A10_L100_M005_no0$real_q_values)

#Fst 0.1 M 0.01----
mean(F01_A2_L10_M001_no0$Structure_q_values)
sd(F01_A2_L10_M001_no0$Structure_q_values)
mean(F01_A2_L10_M001_no0$real_q_values)
sd(F01_A2_L10_M001_no0$real_q_values)

mean(F01_A2_L30_M001_no0$Structure_q_values)
sd(F01_A2_L30_M001_no0$Structure_q_values)
mean(F01_A2_L30_M001_no0$real_q_values)
sd(F01_A2_L30_M001_no0$real_q_values)

mean(F01_A2_L100_M001_no0$Structure_q_values)
sd(F01_A2_L100_M001_no0$Structure_q_values)
mean(F01_A2_L100_M001_no0$real_q_values)
sd(F01_A2_L100_M001_no0$real_q_values)

mean(F01_A5_L10_M001_no0$Structure_q_values)
sd(F01_A5_L10_M001_no0$Structure_q_values)
mean(F01_A5_L10_M001_no0$real_q_values)
sd(F01_A5_L10_M001_no0$real_q_values)

mean(F01_A5_L30_M001_no0$Structure_q_values)
sd(F01_A5_L30_M001_no0$Structure_q_values)
mean(F01_A5_L30_M001_no0$real_q_values)
sd(F01_A5_L30_M001_no0$real_q_values)

mean(F01_A5_L100_M001_no0$Structure_q_values)
sd(F01_A5_L100_M001_no0$Structure_q_values)
mean(F01_A5_L100_M001_no0$real_q_values)
sd(F01_A5_L100_M001_no0$real_q_values)

mean(F01_A10_L10_M001_no0$Structure_q_values)
sd(F01_A10_L10_M001_no0$Structure_q_values)
mean(F01_A10_L10_M001_no0$real_q_values)
sd(F01_A10_L10_M001_no0$real_q_values)

mean(F01_A10_L30_M001_no0$Structure_q_values)
sd(F01_A10_L30_M001_no0$Structure_q_values)
mean(F01_A10_L30_M001_no0$real_q_values)
sd(F01_A10_L30_M001_no0$real_q_values)

mean(F01_A10_L100_M001_no0$Structure_q_values)
sd(F01_A10_L100_M001_no0$Structure_q_values)
mean(F01_A10_L100_M001_no0$real_q_values)
sd(F01_A10_L100_M001_no0$real_q_values)

#Fst 0.05 M 0.05----
mean(F005_A2_L10_M005_no0$Structure_q_values)
sd(F005_A2_L10_M005_no0$Structure_q_values)
mean(F005_A2_L10_M005_no0$real_q_values)
sd(F005_A2_L10_M005_no0$real_q_values)

mean(F005_A2_L30_M005_no0$Structure_q_values)
sd(F005_A2_L30_M005_no0$Structure_q_values)
mean(F005_A2_L30_M005_no0$real_q_values)
sd(F005_A2_L30_M005_no0$real_q_values)

mean(F005_A2_L100_M005_no0$Structure_q_values)
sd(F005_A2_L100_M005_no0$Structure_q_values)
mean(F005_A2_L100_M005_no0$real_q_values)
sd(F005_A2_L100_M005_no0$real_q_values)

mean(F005_A5_L10_M005_no0$Structure_q_values)
sd(F005_A5_L10_M005_no0$Structure_q_values)
mean(F005_A5_L10_M005_no0$real_q_values)
sd(F005_A5_L10_M005_no0$real_q_values)

mean(F005_A5_L30_M005_no0$Structure_q_values)
sd(F005_A5_L30_M005_no0$Structure_q_values)
mean(F005_A5_L30_M005_no0$real_q_values)
sd(F005_A5_L30_M005_no0$real_q_values)

mean(F005_A5_L100_M005_no0$Structure_q_values)
sd(F005_A5_L100_M005_no0$Structure_q_values)
mean(F005_A5_L100_M005_no0$real_q_values)
sd(F005_A5_L100_M005_no0$real_q_values)

mean(F005_A10_L10_M005_no0$Structure_q_values)
sd(F005_A10_L10_M005_no0$Structure_q_values)
mean(F005_A10_L10_M005_no0$real_q_values)
sd(F005_A10_L10_M005_no0$real_q_values)

mean(F005_A10_L30_M005_no0$Structure_q_values)
sd(F005_A10_L30_M005_no0$Structure_q_values)
mean(F005_A10_L30_M005_no0$real_q_values)
sd(F005_A10_L30_M005_no0$real_q_values)

mean(F005_A10_L100_M005_no0$Structure_q_values)
sd(F005_A10_L100_M005_no0$Structure_q_values)
mean(F005_A10_L100_M005_no0$real_q_values)
sd(F005_A10_L100_M005_no0$real_q_values)

#Fst 0.05 M 0.01----
mean(F005_A2_L10_M001_no0$Structure_q_values)
sd(F005_A2_L10_M001_no0$Structure_q_values)
mean(F005_A2_L10_M001_no0$real_q_values)
sd(F005_A2_L10_M001_no0$real_q_values)

mean(F005_A2_L30_M001_no0$Structure_q_values)
sd(F005_A2_L30_M001_no0$Structure_q_values)
mean(F005_A2_L30_M001_no0$real_q_values)
sd(F005_A2_L30_M001_no0$real_q_values)

mean(F005_A2_L100_M001_no0$Structure_q_values)
sd(F005_A2_L100_M001_no0$Structure_q_values)
mean(F005_A2_L100_M001_no0$real_q_values)
sd(F005_A2_L100_M001_no0$real_q_values)

mean(F005_A5_L10_M001_no0$Structure_q_values)
sd(F005_A5_L10_M001_no0$Structure_q_values)
mean(F005_A5_L10_M001_no0$real_q_values)
sd(F005_A5_L10_M001_no0$real_q_values)

mean(F005_A5_L30_M001_no0$Structure_q_values)
sd(F005_A5_L30_M001_no0$Structure_q_values)
mean(F005_A5_L30_M001_no0$real_q_values)
sd(F005_A5_L30_M001_no0$real_q_values)

mean(F005_A5_L100_M001_no0$Structure_q_values)
sd(F005_A5_L100_M001_no0$Structure_q_values)
mean(F005_A5_L100_M001_no0$real_q_values)
sd(F005_A5_L100_M001_no0$real_q_values)

mean(F005_A10_L10_M001_no0$Structure_q_values)
sd(F005_A10_L10_M001_no0$Structure_q_values)
mean(F005_A10_L10_M001_no0$real_q_values)
sd(F005_A10_L10_M001_no0$real_q_values)

mean(F005_A10_L30_M001_no0$Structure_q_values)
sd(F005_A10_L30_M001_no0$Structure_q_values)
mean(F005_A10_L30_M001_no0$real_q_values)
sd(F005_A10_L30_M001_no0$real_q_values)

mean(F005_A10_L100_M001_no0$Structure_q_values)
sd(F005_A10_L100_M001_no0$Structure_q_values)
mean(F005_A10_L100_M001_no0$real_q_values)
sd(F005_A10_L100_M001_no0$real_q_values)

#Fst 0.2 M 0.05----
mean(F02_A2_L10_M005_no0$Structure_q_values)
sd(F02_A2_L10_M005_no0$Structure_q_values)
mean(F02_A2_L10_M005_no0$real_q_values)
sd(F02_A2_L10_M005_no0$real_q_values)

mean(F02_A2_L30_M005_no0$Structure_q_values)
sd(F02_A2_L30_M005_no0$Structure_q_values)
mean(F02_A2_L30_M005_no0$real_q_values)
sd(F02_A2_L30_M005_no0$real_q_values)

mean(F02_A2_L100_M005_no0$Structure_q_values)
sd(F02_A2_L100_M005_no0$Structure_q_values)
mean(F02_A2_L100_M005_no0$real_q_values)
sd(F02_A2_L100_M005_no0$real_q_values)

mean(F02_A5_L10_M005_no0$Structure_q_values)
sd(F02_A5_L10_M005_no0$Structure_q_values)
mean(F02_A5_L10_M005_no0$real_q_values)
sd(F02_A5_L10_M005_no0$real_q_values)

mean(F02_A5_L30_M005_no0$Structure_q_values)
sd(F02_A5_L30_M005_no0$Structure_q_values)
mean(F02_A5_L30_M005_no0$real_q_values)
sd(F02_A5_L30_M005_no0$real_q_values)

mean(F02_A5_L100_M005_no0$Structure_q_values)
sd(F02_A5_L100_M005_no0$Structure_q_values)
mean(F02_A5_L100_M005_no0$real_q_values)
sd(F02_A5_L100_M005_no0$real_q_values)

mean(F02_A10_L10_M005_no0$Structure_q_values)
sd(F02_A10_L10_M005_no0$Structure_q_values)
mean(F02_A10_L10_M005_no0$real_q_values)
sd(F02_A10_L10_M005_no0$real_q_values)

mean(F02_A10_L30_M005_no0$Structure_q_values)
sd(F02_A10_L30_M005_no0$Structure_q_values)
mean(F02_A10_L30_M005_no0$real_q_values)
sd(F02_A10_L30_M005_no0$real_q_values)

mean(F02_A10_L100_M005_no0$Structure_q_values)
sd(F02_A10_L100_M005_no0$Structure_q_values)
mean(F02_A10_L100_M005_no0$real_q_values)
sd(F02_A10_L100_M005_no0$real_q_values)

#Fst 0.2 M 0.01----
mean(F02_A2_L10_M001_no0$Structure_q_values)
sd(F02_A2_L10_M001_no0$Structure_q_values)
mean(F02_A2_L10_M001_no0$real_q_values)
sd(F02_A2_L10_M001_no0$real_q_values)

mean(F02_A2_L30_M001_no0$Structure_q_values)
sd(F02_A2_L30_M001_no0$Structure_q_values)
mean(F02_A2_L30_M001_no0$real_q_values)
sd(F02_A2_L30_M001_no0$real_q_values)

mean(F02_A2_L100_M001_no0$Structure_q_values)
sd(F02_A2_L100_M001_no0$Structure_q_values)
mean(F02_A2_L100_M001_no0$real_q_values)
sd(F02_A2_L100_M001_no0$real_q_values)

mean(F02_A5_L10_M001_no0$Structure_q_values)
sd(F02_A5_L10_M001_no0$Structure_q_values)
mean(F02_A5_L10_M001_no0$real_q_values)
sd(F02_A5_L10_M001_no0$real_q_values)

mean(F02_A5_L30_M001_no0$Structure_q_values)
sd(F02_A5_L30_M001_no0$Structure_q_values)
mean(F02_A5_L30_M001_no0$real_q_values)
sd(F02_A5_L30_M001_no0$real_q_values)

mean(F02_A5_L100_M001_no0$Structure_q_values)
sd(F02_A5_L100_M001_no0$Structure_q_values)
mean(F02_A5_L100_M001_no0$real_q_values)
sd(F02_A5_L100_M001_no0$real_q_values)

mean(F02_A10_L10_M001_no0$Structure_q_values)
sd(F02_A10_L10_M001_no0$Structure_q_values)
mean(F02_A10_L10_M001_no0$real_q_values)
sd(F02_A10_L10_M001_no0$real_q_values)

mean(F02_A10_L30_M001_no0$Structure_q_values)
sd(F02_A10_L30_M001_no0$Structure_q_values)
mean(F02_A10_L30_M001_no0$real_q_values)
sd(F02_A10_L30_M001_no0$real_q_values)

mean(F02_A10_L100_M001_no0$Structure_q_values)
sd(F02_A10_L100_M001_no0$Structure_q_values)
mean(F02_A10_L100_M001_no0$real_q_values)
sd(F02_A10_L100_M001_no0$real_q_values)



#table with mean q differences ----
#Fst 0.1 M 0.05----
c1 <- cbind('F01_A2_L10_M005', mean(F01_A2_L10_M005_no0$qdif), sd(F01_A2_L10_M005_no0$qdif))
c2 <- cbind('F01_A2_L30_M005', mean(F01_A2_L30_M005_no0$qdif), sd(F01_A2_L30_M005_no0$qdif))
c3 <- cbind('F01_A2_L100_M005', mean(F01_A2_L100_M005_no0$qdif), sd(F01_A2_L100_M005_no0$qdif))
c4 <- cbind('F01_A5_L10_M005', mean(F01_A5_L10_M005_no0$qdif), sd(F01_A2_L10_M005_no0$qdif))
c5 <- cbind('F01_A5_L30_M005', mean(F01_A5_L30_M005_no0$qdif), sd(F01_A2_L30_M005_no0$qdif))
c6 <- cbind('F01_A5_L100_M005', mean(F01_A5_L100_M005_no0$qdif), sd(F01_A2_L100_M005_no0$qdif))
c7 <- cbind('F01_A10_L10_M005', mean(F01_A10_L10_M005_no0$qdif), sd(F01_A2_L10_M005_no0$qdif))
c8 <- cbind('F01_A10_L30_M005', mean(F01_A10_L30_M005_no0$qdif), sd(F01_A2_L30_M005_no0$qdif))
c9 <- cbind('F01_A10_L100_M005', mean(F01_A10_L100_M005_no0$qdif), sd(F01_A2_L100_M005_no0$qdif))

mean_table <- rbind(c1,c2,c3,c4,c5,c6,c7,c8,c9)

c1 <- cbind('F01_A2_L10_M001', mean(F01_A2_L10_M001_no0$qdif), sd(F01_A2_L10_M001_no0$qdif))
c2 <- cbind('F01_A2_L30_M001', mean(F01_A2_L30_M001_no0$qdif), sd(F01_A2_L30_M001_no0$qdif))
c3 <- cbind('F01_A2_L100_M001', mean(F01_A2_L100_M001_no0$qdif), sd(F01_A2_L100_M001_no0$qdif))
c4 <- cbind('F01_A5_L10_M001', mean(F01_A5_L10_M001_no0$qdif), sd(F01_A2_L10_M001_no0$qdif))
c5 <- cbind('F01_A5_L30_M001', mean(F01_A5_L30_M001_no0$qdif), sd(F01_A2_L30_M001_no0$qdif))
c6 <- cbind('F01_A5_L100_M001', mean(F01_A5_L100_M001_no0$qdif), sd(F01_A2_L100_M001_no0$qdif))
c7 <- cbind('F01_A10_L10_M001', mean(F01_A10_L10_M001_no0$qdif), sd(F01_A2_L10_M001_no0$qdif))
c8 <- cbind('F01_A10_L30_M001', mean(F01_A10_L30_M001_no0$qdif), sd(F01_A2_L30_M001_no0$qdif))
c9 <- cbind('F01_A10_L100_M001', mean(F01_A10_L100_M001_no0$qdif), sd(F01_A2_L100_M001_no0$qdif))

mean_table <- rbind(mean_table,c1,c2,c3,c4,c5,c6,c7,c8,c9)

c1 <- cbind('F005_A2_L10_M005', mean(F005_A2_L10_M005_no0$qdif), sd(F005_A2_L10_M005_no0$qdif))
c2 <- cbind('F005_A2_L30_M005', mean(F005_A2_L30_M005_no0$qdif), sd(F005_A2_L30_M005_no0$qdif))
c3 <- cbind('F005_A2_L100_M005', mean(F005_A2_L100_M005_no0$qdif), sd(F005_A2_L100_M005_no0$qdif))
c4 <- cbind('F005_A5_L10_M005', mean(F005_A5_L10_M005_no0$qdif), sd(F005_A2_L10_M005_no0$qdif))
c5 <- cbind('F005_A5_L30_M005', mean(F005_A5_L30_M005_no0$qdif), sd(F005_A2_L30_M005_no0$qdif))
c6 <- cbind('F005_A5_L100_M005', mean(F005_A5_L100_M005_no0$qdif), sd(F005_A2_L100_M005_no0$qdif))
c7 <- cbind('F005_A10_L10_M005', mean(F005_A10_L10_M005_no0$qdif), sd(F005_A2_L10_M005_no0$qdif))
c8 <- cbind('F005_A10_L30_M005', mean(F005_A10_L30_M005_no0$qdif), sd(F005_A2_L30_M005_no0$qdif))
c9 <- cbind('F005_A10_L100_M005', mean(F005_A10_L100_M005_no0$qdif), sd(F005_A2_L100_M005_no0$qdif))

mean_table <- rbind(mean_table,c1,c2,c3,c4,c5,c6,c7,c8,c9)

c1 <- cbind('F005_A2_L10_M001', mean(F005_A2_L10_M001_no0$qdif), sd(F005_A2_L10_M001_no0$qdif))
c2 <- cbind('F005_A2_L30_M001', mean(F005_A2_L30_M001_no0$qdif), sd(F005_A2_L30_M001_no0$qdif))
c3 <- cbind('F005_A2_L100_M001', mean(F005_A2_L100_M001_no0$qdif), sd(F005_A2_L100_M001_no0$qdif))
c4 <- cbind('F005_A5_L10_M001', mean(F005_A5_L10_M001_no0$qdif), sd(F005_A2_L10_M001_no0$qdif))
c5 <- cbind('F005_A5_L30_M001', mean(F005_A5_L30_M001_no0$qdif), sd(F005_A2_L30_M001_no0$qdif))
c6 <- cbind('F005_A5_L100_M001', mean(F005_A5_L100_M001_no0$qdif), sd(F005_A2_L100_M001_no0$qdif))
c7 <- cbind('F005_A10_L10_M001', mean(F005_A10_L10_M001_no0$qdif), sd(F005_A2_L10_M001_no0$qdif))
c8 <- cbind('F005_A10_L30_M001', mean(F005_A10_L30_M001_no0$qdif), sd(F005_A2_L30_M001_no0$qdif))
c9 <- cbind('F005_A10_L100_M001', mean(F005_A10_L100_M001_no0$qdif), sd(F005_A2_L100_M001_no0$qdif))

mean_table <- rbind(mean_table,c1,c2,c3,c4,c5,c6,c7,c8,c9)

c1 <- cbind('F02_A2_L10_M005', mean(F02_A2_L10_M005_no0$qdif), sd(F02_A2_L10_M005_no0$qdif))
c2 <- cbind('F02_A2_L30_M005', mean(F02_A2_L30_M005_no0$qdif), sd(F02_A2_L30_M005_no0$qdif))
c3 <- cbind('F02_A2_L100_M005', mean(F02_A2_L100_M005_no0$qdif), sd(F02_A2_L100_M005_no0$qdif))
c4 <- cbind('F02_A5_L10_M005', mean(F02_A5_L10_M005_no0$qdif), sd(F02_A2_L10_M005_no0$qdif))
c5 <- cbind('F02_A5_L30_M005', mean(F02_A5_L30_M005_no0$qdif), sd(F02_A2_L30_M005_no0$qdif))
c6 <- cbind('F02_A5_L100_M005', mean(F02_A5_L100_M005_no0$qdif), sd(F02_A2_L100_M005_no0$qdif))
c7 <- cbind('F02_A10_L10_M005', mean(F02_A10_L10_M005_no0$qdif), sd(F02_A2_L10_M005_no0$qdif))
c8 <- cbind('F02_A10_L30_M005', mean(F02_A10_L30_M005_no0$qdif), sd(F02_A2_L30_M005_no0$qdif))
c9 <- cbind('F02_A10_L100_M005', mean(F02_A10_L100_M005_no0$qdif), sd(F02_A2_L100_M005_no0$qdif))

mean_table <- rbind(mean_table,c1,c2,c3,c4,c5,c6,c7,c8,c9)

c1 <- cbind('F02_A2_L10_M001', mean(F02_A2_L10_M001_no0$qdif), sd(F02_A2_L10_M001_no0$qdif))
c2 <- cbind('F02_A2_L30_M001', mean(F02_A2_L30_M001_no0$qdif), sd(F02_A2_L30_M001_no0$qdif))
c3 <- cbind('F02_A2_L100_M001', mean(F02_A2_L100_M001_no0$qdif), sd(F02_A2_L100_M001_no0$qdif))
c4 <- cbind('F02_A5_L10_M001', mean(F02_A5_L10_M001_no0$qdif), sd(F02_A2_L10_M001_no0$qdif))
c5 <- cbind('F02_A5_L30_M001', mean(F02_A5_L30_M001_no0$qdif), sd(F02_A2_L30_M001_no0$qdif))
c6 <- cbind('F02_A5_L100_M001', mean(F02_A5_L100_M001_no0$qdif), sd(F02_A2_L100_M001_no0$qdif))
c7 <- cbind('F02_A10_L10_M001', mean(F02_A10_L10_M001_no0$qdif), sd(F02_A2_L10_M001_no0$qdif))
c8 <- cbind('F02_A10_L30_M001', mean(F02_A10_L30_M001_no0$qdif), sd(F02_A2_L30_M001_no0$qdif))
c9 <- cbind('F02_A10_L100_M001', mean(F02_A10_L100_M001_no0$qdif), sd(F02_A2_L100_M001_no0$qdif))

mean_table <- rbind(mean_table,c1,c2,c3,c4,c5,c6,c7,c8,c9)

mean_table[ ,2] <- as.numeric(mean_table[ ,2])

# Writing mtcars data
write.table(mean_table, file = "mean_table_qdif.txt", sep = "\t",
            row.names = FALSE)


mean(m005_no0$qdif)
sd(m005_no0$qdif)

mean(m001_no0$qdif)
sd(m001_no0$qdif)


