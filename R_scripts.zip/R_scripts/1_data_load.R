### load data from the "results" folder 

# the "top' function allows to extract "num" rows from a dataframe, ordering by batches of the "c1" column after sorting according to values of "c2" column
# x = dataframe, num = number of rows to leave, c1 = reference column for batches, c2 = column to sort  

top<-function(x, num, c1,c2){
  sorted<-x[with(x,order(x[,c1],x[,c2],decreasing=F)),]
  splits<-split(sorted,sorted[,c1])
  df<-lapply(splits,head,num)
  do.call(rbind.data.frame,df)}

# same as the "top" function, but "c2" column is sorted in a descending order

top2<-function(x, num, c1,c2){
  sorted<-x[with(x,order(x[,c1],x[,c2],decreasing=T)),]
  splits<-split(sorted,sorted[,c1])
  df<-lapply(splits,head,num)
  do.call(rbind.data.frame,df)}


library(ggplot2)
library(gridExtra)
library(betareg) 

setwd('C:/results')

# Data fst 0.1 migration 0.05 ----
F01_A2_L10_M005 <- cbind(Fst=0.1, alleles=2, loci = 10, m=0.05, rep="F01_A2_L10_M005", read.table("Fst0.1_NAl2_NMar10_M0.05_N200", header=T, dec = "."))
F01_A2_L10_M005 <- cbind (qdif= F01_A2_L10_M005$Structure_q_values - F01_A2_L10_M005$real_q_values, F01_A2_L10_M005)
F01_A2_L10_M005_no0 <- top(F01_A2_L10_M005, 100, 12, 7)

F01_A5_L10_M005 <- cbind(Fst=0.1, alleles=5, loci = 10, m=0.05, rep="F01_A5_L10_M005", read.table("Fst0.1_NAl5_NMar10_M0.05_N200", header=T, dec = "."))
F01_A5_L10_M005 <- cbind (qdif= F01_A5_L10_M005$Structure_q_values - F01_A5_L10_M005$real_q_values, F01_A5_L10_M005)
F01_A5_L10_M005_no0 <- top(F01_A5_L10_M005, 100, 12, 7)

F01_A10_L10_M005 <- cbind(Fst=0.1, alleles=10, loci = 10, m=0.05, rep="F01_A10_L10_M005", read.table("Fst0.1_NAl10_NMar10_M0.05_N200", header=T, dec = "."))
F01_A10_L10_M005 <- cbind (qdif= F01_A10_L10_M005$Structure_q_values - F01_A10_L10_M005$real_q_values, F01_A10_L10_M005)
F01_A10_L10_M005_no0 <- top(F01_A10_L10_M005, 100, 12, 7)

F01_A2_L30_M005 <- cbind(Fst=0.1, alleles=2, loci = 30, m=0.05, rep="F01_A2_L30_M005", read.table("Fst0.1_NAl2_NMar30_M0.05_N200", header=T, dec = "."))
F01_A2_L30_M005 <- cbind (qdif= F01_A2_L30_M005$Structure_q_values - F01_A2_L30_M005$real_q_values, F01_A2_L30_M005)
F01_A2_L30_M005_no0 <- top(F01_A2_L30_M005, 100, 12, 7)

F01_A5_L30_M005 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005", read.table("Fst0.1_NAl5_NMar30_M0.05_N200", header=T, dec = "."))
F01_A5_L30_M005 <- cbind (qdif= F01_A5_L30_M005$Structure_q_values - F01_A5_L30_M005$real_q_values, F01_A5_L30_M005)
F01_A5_L30_M005_no0 <- top(F01_A5_L30_M005, 100, 12, 7)

F01_A10_L30_M005 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005", read.table("Fst0.1_NAl10_NMar30_M0.05_N200", header=T, dec = "."))
F01_A10_L30_M005 <- cbind (qdif= F01_A10_L30_M005$Structure_q_values - F01_A10_L30_M005$real_q_values, F01_A10_L30_M005)
F01_A10_L30_M005_no0 <- top(F01_A10_L30_M005, 100, 12, 7)

F01_A2_L100_M005 <- cbind(Fst=0.1, alleles=2, loci = 100, m=0.05, rep="F01_A2_L100_M005", read.table("Fst0.1_NAl2_NMar100_M0.05_N200", header=T, dec = "."))
F01_A2_L100_M005 <- cbind (qdif= F01_A2_L100_M005$Structure_q_values - F01_A2_L100_M005$real_q_values, F01_A2_L100_M005)
F01_A2_L100_M005_no0 <- top(F01_A2_L100_M005, 100, 12, 7)

F01_A5_L100_M005 <- cbind(Fst=0.1, alleles=5, loci = 100, m=0.05, rep="F01_A5_L100_M005", read.table("Fst0.1_NAl5_NMar100_M0.05_N200", header=T, dec = "."))
F01_A5_L100_M005 <- cbind (qdif= F01_A5_L100_M005$Structure_q_values - F01_A5_L100_M005$real_q_values, F01_A5_L100_M005)
F01_A5_L100_M005_no0 <- top(F01_A5_L100_M005, 100, 12, 7)

F01_A10_L100_M005 <- cbind(Fst=0.1, alleles=10, loci = 100, m=0.05, rep="F01_A10_L100_M005", read.table("Fst0.1_NAl10_NMar100_M0.05_N200", header=T, dec = "."))
F01_A10_L100_M005 <- cbind (qdif= F01_A10_L100_M005$Structure_q_values - F01_A10_L100_M005$real_q_values, F01_A10_L100_M005)
F01_A10_L100_M005_no0 <- top(F01_A10_L100_M005, 100, 12, 7)

F01_m005_no0 <- rbind(F01_A2_L10_M005_no0, F01_A5_L10_M005_no0, F01_A10_L10_M005_no0, 
                      F01_A2_L30_M005_no0, F01_A5_L30_M005_no0, F01_A10_L30_M005_no0,
                      F01_A2_L100_M005_no0,F01_A5_L100_M005_no0, F01_A10_L100_M005_no0)


# Data fst 0.1 migration 0.01 ----
F01_A2_L10_M001 <- cbind(Fst=0.1, alleles=2, loci = 10, m=0.01, rep="F01_A2_L10_M001", read.table("Fst0.1_NAl2_NMar10_M0.01_N200", header=T, dec = "."))
F01_A2_L10_M001 <- cbind (qdif= F01_A2_L10_M001$Structure_q_values - F01_A2_L10_M001$real_q_values, F01_A2_L10_M001)
F01_A2_L10_M001_no0 <- top(F01_A2_L10_M001, 100, 12, 7)

F01_A5_L10_M001 <- cbind(Fst=0.1, alleles=5, loci = 10, m=0.01, rep="F01_A5_L10_M001", read.table("Fst0.1_NAl5_NMar10_M0.01_N200", header=T, dec = "."))
F01_A5_L10_M001 <- cbind (qdif= F01_A5_L10_M001$Structure_q_values - F01_A5_L10_M001$real_q_values, F01_A5_L10_M001)
F01_A5_L10_M001_no0 <- top(F01_A5_L10_M001, 100, 12, 7)

F01_A10_L10_M001 <- cbind(Fst=0.1, alleles=10, loci = 10, m=0.01, rep="F01_A10_L10_M001", read.table("Fst0.1_NAl10_NMar10_M0.01_N200", header=T, dec = "."))
F01_A10_L10_M001 <- cbind (qdif= F01_A10_L10_M001$Structure_q_values - F01_A10_L10_M001$real_q_values, F01_A10_L10_M001)
F01_A10_L10_M001_no0 <- top(F01_A10_L10_M001, 100, 12, 7)

F01_A2_L30_M001 <- cbind(Fst=0.1, alleles=2, loci = 30, m=0.01, rep="F01_A2_L30_M001", read.table("Fst0.1_NAl2_NMar30_M0.01_N200", header=T, dec = "."))
F01_A2_L30_M001 <- cbind (qdif= F01_A2_L30_M001$Structure_q_values - F01_A2_L30_M001$real_q_values, F01_A2_L30_M001)
F01_A2_L30_M001_no0 <- top(F01_A2_L30_M001, 100, 12, 7)

F01_A5_L30_M001 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001", read.table("Fst0.1_NAl5_NMar30_M0.01_N200", header=T, dec = "."))
F01_A5_L30_M001 <- cbind (qdif= F01_A5_L30_M001$Structure_q_values - F01_A5_L30_M001$real_q_values, F01_A5_L30_M001)
F01_A5_L30_M001_no0 <- top(F01_A5_L30_M001, 100, 12, 7)

F01_A10_L30_M001 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001", read.table("Fst0.1_NAl10_NMar30_M0.01_N200", header=T, dec = "."))
F01_A10_L30_M001 <- cbind (qdif= F01_A10_L30_M001$Structure_q_values - F01_A10_L30_M001$real_q_values, F01_A10_L30_M001)
F01_A10_L30_M001_no0 <- top(F01_A10_L30_M001, 100, 12, 7)

F01_A2_L100_M001 <- cbind(Fst=0.1, alleles=2, loci = 100, m=0.01, rep="F01_A2_L100_M001", read.table("Fst0.1_NAl2_NMar100_M0.01_N200", header=T, dec = "."))
F01_A2_L100_M001 <- cbind (qdif= F01_A2_L100_M001$Structure_q_values - F01_A2_L100_M001$real_q_values, F01_A2_L100_M001)
F01_A2_L100_M001_no0 <- top(F01_A2_L100_M001, 100, 12, 7)

F01_A5_L100_M001 <- cbind(Fst=0.1, alleles=5, loci = 100, m=0.01, rep="F01_A5_L100_M001", read.table("Fst0.1_NAl5_NMar100_M0.01_N200", header=T, dec = "."))
F01_A5_L100_M001 <- cbind (qdif= F01_A5_L100_M001$Structure_q_values - F01_A5_L100_M001$real_q_values, F01_A5_L100_M001)
F01_A5_L100_M001_no0 <- top(F01_A5_L100_M001, 100, 12, 7)

F01_A10_L100_M001 <- cbind(Fst=0.1, alleles=10, loci = 100, m=0.01, rep="F01_A10_L100_M001", read.table("Fst0.1_NAl10_NMar100_M0.01_N200", header=T, dec = "."))
F01_A10_L100_M001 <- cbind (qdif= F01_A10_L100_M001$Structure_q_values - F01_A10_L100_M001$real_q_values, F01_A10_L100_M001)
F01_A10_L100_M001_no0 <- top(F01_A10_L100_M001, 100, 12, 7)

F01_m001_no0 <- rbind(F01_A2_L10_M001_no0, F01_A5_L10_M001_no0, F01_A10_L10_M001_no0, 
                      F01_A2_L30_M001_no0, F01_A5_L30_M001_no0, F01_A10_L30_M001_no0,
                      F01_A2_L100_M001_no0, F01_A5_L100_M001_no0, F01_A10_L100_M001_no0)

#Data Fst 0.1 ----
F01_no0 <- rbind(F01_m001_no0, F01_m005_no0)


# Data fst 0.2 migration 0.05 ----
F02_A2_L10_M005 <- cbind(Fst=0.2, alleles=2, loci = 10, m=0.05, rep="F02_A2_L10_M005", read.table("Fst0.2_NAl2_NMar10_M0.05_N200", header=T, dec = "."))
F02_A2_L10_M005 <- cbind (qdif= F02_A2_L10_M005$Structure_q_values - F02_A2_L10_M005$real_q_values, F02_A2_L10_M005)
F02_A2_L10_M005_no0 <- top(F02_A2_L10_M005, 100, 12, 7)

F02_A5_L10_M005 <- cbind(Fst=0.2, alleles=5, loci = 10, m=0.05, rep="F02_A5_L10_M005", read.table("Fst0.2_NAl5_NMar10_M0.05_N200", header=T, dec = "."))
F02_A5_L10_M005 <- cbind (qdif= F02_A5_L10_M005$Structure_q_values - F02_A5_L10_M005$real_q_values, F02_A5_L10_M005)
F02_A5_L10_M005_no0 <- top(F02_A5_L10_M005, 100, 12, 7)

F02_A10_L10_M005 <- cbind(Fst=0.2, alleles=10, loci = 10, m=0.05, rep="F02_A10_L10_M005", read.table("Fst0.2_NAl10_NMar10_M0.05_N200", header=T, dec = "."))
F02_A10_L10_M005 <- cbind (qdif= F02_A10_L10_M005$Structure_q_values - F02_A10_L10_M005$real_q_values, F02_A10_L10_M005)
F02_A10_L10_M005_no0 <- top(F02_A10_L10_M005, 100, 12, 7)

F02_A2_L30_M005 <- cbind(Fst=0.2, alleles=2, loci = 30, m=0.05, rep="F02_A2_L30_M005", read.table("Fst0.2_NAl2_NMar30_M0.05_N200", header=T, dec = "."))
F02_A2_L30_M005 <- cbind (qdif= F02_A2_L30_M005$Structure_q_values - F02_A2_L30_M005$real_q_values, F02_A2_L30_M005)
F02_A2_L30_M005_no0 <- top(F02_A2_L30_M005, 100, 12, 7)

F02_A5_L30_M005 <- cbind(Fst=0.2, alleles=5, loci = 30, m=0.05, rep="F02_A5_L30_M005", read.table("Fst0.2_NAl5_NMar30_M0.05_N200", header=T, dec = "."))
F02_A5_L30_M005 <- cbind (qdif= F02_A5_L30_M005$Structure_q_values - F02_A5_L30_M005$real_q_values, F02_A5_L30_M005)
F02_A5_L30_M005_no0 <- top(F02_A5_L30_M005, 100, 12, 7)

F02_A10_L30_M005 <- cbind(Fst=0.2, alleles=10, loci = 30, m=0.05, rep="F02_A10_L30_M005", read.table("Fst0.2_NAl10_NMar30_M0.05_N200", header=T, dec = "."))
F02_A10_L30_M005 <- cbind (qdif= F02_A10_L30_M005$Structure_q_values - F02_A10_L30_M005$real_q_values, F02_A10_L30_M005)
F02_A10_L30_M005_no0 <- top(F02_A10_L30_M005, 100, 12, 7)

F02_A2_L100_M005 <- cbind(Fst=0.2, alleles=2, loci = 100, m=0.05, rep="F02_A2_L100_M005", read.table("Fst0.2_NAl2_NMar100_M0.05_N200", header=T, dec = "."))
F02_A2_L100_M005 <- cbind (qdif= F02_A2_L100_M005$Structure_q_values - F02_A2_L100_M005$real_q_values, F02_A2_L100_M005)
F02_A2_L100_M005_no0 <- top(F02_A2_L100_M005, 100, 12, 7)

F02_A5_L100_M005 <- cbind(Fst=0.2, alleles=5, loci = 100, m=0.05, rep="F02_A5_L100_M005", read.table("Fst0.2_NAl5_NMar100_M0.05_N200", header=T, dec = "."))
F02_A5_L100_M005 <- cbind (qdif= F02_A5_L100_M005$Structure_q_values - F02_A5_L100_M005$real_q_values, F02_A5_L100_M005)
F02_A5_L100_M005_no0 <- top(F02_A5_L100_M005, 100, 12, 7)

F02_A10_L100_M005 <- cbind(Fst=0.2, alleles=10, loci = 100, m=0.05, rep="F02_A10_L100_M005", read.table("Fst0.2_NAl10_NMar100_M0.05_N200", header=T, dec = "."))
F02_A10_L100_M005 <- cbind (qdif= F02_A10_L100_M005$Structure_q_values - F02_A10_L100_M005$real_q_values, F02_A10_L100_M005)
F02_A10_L100_M005_no0 <- top(F02_A10_L100_M005, 100, 12, 7)

F02_m005_no0 <- rbind(F02_A2_L10_M005_no0, F02_A5_L10_M005_no0, F02_A10_L10_M005_no0, 
                      F02_A2_L30_M005_no0, F02_A5_L30_M005_no0, F02_A10_L30_M005_no0,
                      F02_A2_L100_M005_no0,F02_A5_L100_M005_no0, F02_A10_L100_M005_no0)


# Data fst 0.2 migration 0.01 ----
F02_A2_L10_M001 <- cbind(Fst=0.2, alleles=2, loci = 10, m=0.01, rep="F02_A2_L10_M001", read.table("Fst0.2_NAl2_NMar10_M0.01_N200", header=T, dec = "."))
F02_A2_L10_M001 <- cbind (qdif= F02_A2_L10_M001$Structure_q_values - F02_A2_L10_M001$real_q_values, F02_A2_L10_M001)
F02_A2_L10_M001_no0 <- top(F02_A2_L10_M001, 100, 12, 7)

F02_A5_L10_M001 <- cbind(Fst=0.2, alleles=5, loci = 10, m=0.01, rep="F02_A5_L10_M001", read.table("Fst0.2_NAl5_NMar10_M0.01_N200", header=T, dec = "."))
F02_A5_L10_M001 <- cbind (qdif= F02_A5_L10_M001$Structure_q_values - F02_A5_L10_M001$real_q_values, F02_A5_L10_M001)
F02_A5_L10_M001_no0 <- top(F02_A5_L10_M001, 100, 12, 7)

F02_A10_L10_M001 <- cbind(Fst=0.2, alleles=10, loci = 10, m=0.01, rep="F02_A10_L10_M001", read.table("Fst0.2_NAl10_NMar10_M0.01_N200", header=T, dec = "."))
F02_A10_L10_M001 <- cbind (qdif= F02_A10_L10_M001$Structure_q_values - F02_A10_L10_M001$real_q_values, F02_A10_L10_M001)
F02_A10_L10_M001_no0 <- top(F02_A10_L10_M001, 100, 12, 7)

F02_A2_L30_M001 <- cbind(Fst=0.2, alleles=2, loci = 30, m=0.01, rep="F02_A2_L30_M001", read.table("Fst0.2_NAl2_NMar30_M0.01_N200", header=T, dec = "."))
F02_A2_L30_M001 <- cbind (qdif= F02_A2_L30_M001$Structure_q_values - F02_A2_L30_M001$real_q_values, F02_A2_L30_M001)
F02_A2_L30_M001_no0 <- top(F02_A2_L30_M001, 100, 12, 7)

F02_A5_L30_M001 <- cbind(Fst=0.2, alleles=5, loci = 30, m=0.01, rep="F02_A5_L30_M001", read.table("Fst0.2_NAl5_NMar30_M0.01_N200", header=T, dec = "."))
F02_A5_L30_M001 <- cbind (qdif= F02_A5_L30_M001$Structure_q_values - F02_A5_L30_M001$real_q_values, F02_A5_L30_M001)
F02_A5_L30_M001_no0 <- top(F02_A5_L30_M001, 100, 12, 7)

F02_A10_L30_M001 <- cbind(Fst=0.2, alleles=10, loci = 30, m=0.01, rep="F02_A10_L30_M001", read.table("Fst0.2_NAl10_NMar30_M0.01_N200", header=T, dec = "."))
F02_A10_L30_M001 <- cbind (qdif= F02_A10_L30_M001$Structure_q_values - F02_A10_L30_M001$real_q_values, F02_A10_L30_M001)
F02_A10_L30_M001_no0 <- top(F02_A10_L30_M001, 100, 12, 7)

F02_A2_L100_M001 <- cbind(Fst=0.2, alleles=2, loci = 100, m=0.01, rep="F02_A2_L100_M001", read.table("Fst0.2_NAl2_NMar100_M0.01_N200", header=T, dec = "."))
F02_A2_L100_M001 <- cbind (qdif= F02_A2_L100_M001$Structure_q_values - F02_A2_L100_M001$real_q_values, F02_A2_L100_M001)
F02_A2_L100_M001_no0 <- top(F02_A2_L100_M001, 100, 12, 7)

F02_A5_L100_M001 <- cbind(Fst=0.2, alleles=5, loci = 100, m=0.01, rep="F02_A5_L100_M001", read.table("Fst0.2_NAl5_NMar100_M0.01_N200", header=T, dec = "."))
F02_A5_L100_M001 <- cbind (qdif= F02_A5_L100_M001$Structure_q_values - F02_A5_L100_M001$real_q_values, F02_A5_L100_M001)
F02_A5_L100_M001_no0 <- top(F02_A5_L100_M001, 100, 12, 7)

F02_A10_L100_M001 <- cbind(Fst=0.2, alleles=10, loci = 100, m=0.01, rep="F02_A10_L100_M001", read.table("Fst0.2_NAl10_NMar100_M0.01_N200", header=T, dec = "."))
F02_A10_L100_M001 <- cbind (qdif= F02_A10_L100_M001$Structure_q_values - F02_A10_L100_M001$real_q_values, F02_A10_L100_M001)
F02_A10_L100_M001_no0 <- top(F02_A10_L100_M001, 100, 12, 7)


F02_m001_no0 <- rbind(F02_A2_L10_M001_no0, F02_A5_L10_M001_no0, F02_A10_L10_M001_no0, 
                      F02_A2_L30_M001_no0, F02_A5_L30_M001_no0, F02_A10_L30_M001_no0,
                      F02_A2_L100_M001_no0, F02_A5_L100_M001_no0, F02_A10_L100_M001_no0)

#Data Fst 0.2 ----
F02_no0 <- rbind(F02_m001_no0, F02_m005_no0)


# Data fst 0.05 migration 0.05 ----
F005_A2_L10_M005 <- cbind(Fst=0.05, alleles=2, loci = 10, m=0.05, rep="F005_A2_L10_M005", read.table("Fst0.05_NAl2_NMar10_M0.05_N200", header=T, dec = "."))
F005_A2_L10_M005 <- cbind (qdif= F005_A2_L10_M005$Structure_q_values - F005_A2_L10_M005$real_q_values, F005_A2_L10_M005)
F005_A2_L10_M005_no0 <- top(F005_A2_L10_M005, 100, 12, 7)

F005_A5_L10_M005 <- cbind(Fst=0.05, alleles=5, loci = 10, m=0.05, rep="F005_A5_L10_M005", read.table("Fst0.05_NAl5_NMar10_M0.05_N200", header=T, dec = "."))
F005_A5_L10_M005 <- cbind (qdif= F005_A5_L10_M005$Structure_q_values - F005_A5_L10_M005$real_q_values, F005_A5_L10_M005)
F005_A5_L10_M005_no0 <- top(F005_A5_L10_M005, 100, 12, 7)

F005_A10_L10_M005 <- cbind(Fst=0.05, alleles=10, loci = 10, m=0.05, rep="F005_A10_L10_M005", read.table("Fst0.05_NAl10_NMar10_M0.05_N200", header=T, dec = "."))
F005_A10_L10_M005 <- cbind (qdif= F005_A10_L10_M005$Structure_q_values - F005_A10_L10_M005$real_q_values, F005_A10_L10_M005)
F005_A10_L10_M005_no0 <- top(F005_A10_L10_M005, 100, 12, 7)

F005_A2_L30_M005 <- cbind(Fst=0.05, alleles=2, loci = 30, m=0.05, rep="F005_A2_L30_M005", read.table("Fst0.05_NAl2_NMar30_M0.05_N200", header=T, dec = "."))
F005_A2_L30_M005 <- cbind (qdif= F005_A2_L30_M005$Structure_q_values - F005_A2_L30_M005$real_q_values, F005_A2_L30_M005)
F005_A2_L30_M005_no0 <- top(F005_A2_L30_M005, 100, 12, 7)

F005_A5_L30_M005 <- cbind(Fst=0.05, alleles=5, loci = 30, m=0.05, rep="F005_A5_L30_M005", read.table("Fst0.05_NAl5_NMar30_M0.05_N200", header=T, dec = "."))
F005_A5_L30_M005 <- cbind (qdif= F005_A5_L30_M005$Structure_q_values - F005_A5_L30_M005$real_q_values, F005_A5_L30_M005)
F005_A5_L30_M005_no0 <- top(F005_A5_L30_M005, 100, 12, 7)

F005_A10_L30_M005 <- cbind(Fst=0.05, alleles=10, loci = 30, m=0.05, rep="F005_A10_L30_M005", read.table("Fst0.05_NAl10_NMar30_M0.05_N200", header=T, dec = "."))
F005_A10_L30_M005 <- cbind (qdif= F005_A10_L30_M005$Structure_q_values - F005_A10_L30_M005$real_q_values, F005_A10_L30_M005)
F005_A10_L30_M005_no0 <- top(F005_A10_L30_M005, 100, 12, 7)

F005_A2_L100_M005 <- cbind(Fst=0.05, alleles=2, loci = 100, m=0.05, rep="F005_A2_L100_M005", read.table("Fst0.05_NAl2_NMar100_M0.05_N200", header=T, dec = "."))
F005_A2_L100_M005 <- cbind (qdif= F005_A2_L100_M005$Structure_q_values - F005_A2_L100_M005$real_q_values, F005_A2_L100_M005)
F005_A2_L100_M005_no0 <- top(F005_A2_L100_M005, 100, 12, 7)

F005_A5_L100_M005 <- cbind(Fst=0.05, alleles=5, loci = 100, m=0.05, rep="F005_A5_L100_M005", read.table("Fst0.05_NAl5_NMar100_M0.05_N200", header=T, dec = "."))
F005_A5_L100_M005 <- cbind (qdif= F005_A5_L100_M005$Structure_q_values - F005_A5_L100_M005$real_q_values, F005_A5_L100_M005)
F005_A5_L100_M005_no0 <- top(F005_A5_L100_M005, 100, 12, 7)

F005_A10_L100_M005 <- cbind(Fst=0.05, alleles=10, loci = 100, m=0.05, rep="F005_A10_L100_M005", read.table("Fst0.05_NAl10_NMar100_M0.05_N200", header=T, dec = "."))
F005_A10_L100_M005 <- cbind (qdif= F005_A10_L100_M005$Structure_q_values - F005_A10_L100_M005$real_q_values, F005_A10_L100_M005)
F005_A10_L100_M005_no0 <- top(F005_A10_L100_M005, 100, 12, 7)


F005_m005_no0 <- rbind(F005_A2_L10_M005_no0, F005_A5_L10_M005_no0, F005_A10_L10_M005_no0, 
                       F005_A2_L30_M005_no0, F005_A5_L30_M005_no0, F005_A10_L30_M005_no0,
                        F005_A2_L100_M005_no0, F005_A5_L100_M005_no0, F005_A10_L100_M005_no0)


# Data fst 0.05 migration 0.01 ----
F005_A2_L10_M001 <- cbind(Fst=0.05, alleles=2, loci = 10, m=0.01, rep="F005_A2_L10_M001", read.table("Fst0.05_NAl2_NMar10_M0.01_N200", header=T, dec = "."))
F005_A2_L10_M001 <- cbind (qdif= F005_A2_L10_M001$Structure_q_values - F005_A2_L10_M001$real_q_values, F005_A2_L10_M001)
F005_A2_L10_M001_no0 <- top(F005_A2_L10_M001, 100, 12, 7)

F005_A5_L10_M001 <- cbind(Fst=0.05, alleles=5, loci = 10, m=0.01, rep="F005_A5_L10_M001", read.table("Fst0.05_NAl5_NMar10_M0.01_N200", header=T, dec = "."))
F005_A5_L10_M001 <- cbind (qdif= F005_A5_L10_M001$Structure_q_values - F005_A5_L10_M001$real_q_values, F005_A5_L10_M001)
F005_A5_L10_M001_no0 <- top(F005_A5_L10_M001, 100, 12, 7)

F005_A10_L10_M001 <- cbind(Fst=0.05, alleles=10, loci = 10, m=0.01, rep="F005_A10_L10_M001", read.table("Fst0.05_NAl10_NMar10_M0.01_N200", header=T, dec = "."))
F005_A10_L10_M001 <- cbind (qdif= F005_A10_L10_M001$Structure_q_values - F005_A10_L10_M001$real_q_values, F005_A10_L10_M001)
F005_A10_L10_M001_no0 <- top(F005_A10_L10_M001, 100, 12, 7)

F005_A2_L30_M001 <- cbind(Fst=0.05, alleles=2, loci = 30, m=0.01, rep="F005_A2_L30_M001", read.table("Fst0.05_NAl2_NMar30_M0.01_N200", header=T, dec = "."))
F005_A2_L30_M001 <- cbind (qdif= F005_A2_L30_M001$Structure_q_values - F005_A2_L30_M001$real_q_values, F005_A2_L30_M001)
F005_A2_L30_M001_no0 <- top(F005_A2_L30_M001, 100, 12, 7)

F005_A5_L30_M001 <- cbind(Fst=0.05, alleles=5, loci = 30, m=0.01, rep="F005_A5_L30_M001", read.table("Fst0.05_NAl5_NMar30_M0.01_N200", header=T, dec = "."))
F005_A5_L30_M001 <- cbind (qdif= F005_A5_L30_M001$Structure_q_values - F005_A5_L30_M001$real_q_values, F005_A5_L30_M001)
F005_A5_L30_M001_no0 <- top(F005_A5_L30_M001, 100, 12, 7)

F005_A10_L30_M001 <- cbind(Fst=0.05, alleles=10, loci = 30, m=0.01, rep="F005_A10_L30_M001", read.table("Fst0.05_NAl10_NMar30_M0.01_N200", header=T, dec = "."))
F005_A10_L30_M001 <- cbind (qdif= F005_A10_L30_M001$Structure_q_values - F005_A10_L30_M001$real_q_values, F005_A10_L30_M001)
F005_A10_L30_M001_no0 <- top(F005_A10_L30_M001, 100, 12, 7)

F005_A2_L100_M001 <- cbind(Fst=0.05, alleles=2, loci = 100, m=0.01, rep="F005_A2_L100_M001", read.table("Fst0.05_NAl2_NMar100_M0.01_N200", header=T, dec = "."))
F005_A2_L100_M001 <- cbind (qdif= F005_A2_L100_M001$Structure_q_values - F005_A2_L100_M001$real_q_values, F005_A2_L100_M001)
F005_A2_L100_M001_no0 <- top(F005_A2_L100_M001, 100, 12, 7)

F005_A5_L100_M001 <- cbind(Fst=0.05, alleles=5, loci = 100, m=0.01, rep="F005_A5_L100_M001", read.table("Fst0.05_NAl5_NMar100_M0.01_N200", header=T, dec = "."))
F005_A5_L100_M001 <- cbind (qdif= F005_A5_L100_M001$Structure_q_values - F005_A5_L100_M001$real_q_values, F005_A5_L100_M001)
F005_A5_L100_M001_no0 <- top(F005_A5_L100_M001, 100, 12, 7)

F005_A10_L100_M001 <- cbind(Fst=0.05, alleles=10, loci = 100, m=0.01, rep="F005_A10_L100_M001", read.table("Fst0.05_NAl10_NMar100_M0.01_N200", header=T, dec = "."))
F005_A10_L100_M001 <- cbind (qdif= F005_A10_L100_M001$Structure_q_values - F005_A10_L100_M001$real_q_values, F005_A10_L100_M001)
F005_A10_L100_M001_no0 <- top(F005_A10_L100_M001, 100, 12, 7)


F005_m001_no0 <- rbind(F005_A2_L10_M001_no0, F005_A5_L10_M001_no0, F005_A10_L10_M001_no0, 
                       F005_A2_L30_M001_no0, F005_A5_L30_M001_no0, F005_A10_L30_M001_no0,
                      F005_A2_L100_M001_no0,F005_A5_L100_M001_no0, F005_A10_L100_M001_no0)

#Data Fst 0.05 ----
F005_no0 <- rbind(F005_m001_no0, F005_m005_no0)

#Data m 0.05 ----
m005_no0 <- rbind(F01_m005_no0, F02_m005_no0, F005_m005_no0)

# Data m 0.05 sólo de buenas regresiones ----
m005_no0_reg <- rbind(F02_A5_L100_M005_no0, F02_A10_L100_M005_no0, 
              F01_A5_L100_M005_no0, F01_A10_L100_M005_no0, 
              F005_A5_L100_M005_no0, F005_A10_L100_M005_no0)

# Data m 0.01 sólo regresiones últimas condiciones ----
m001_no0_reg <- rbind(F02_A5_L100_M001_no0, F02_A10_L100_M001_no0, 
                      F01_A5_L100_M001_no0, F01_A10_L100_M001_no0, 
                      F005_A5_L100_M001_no0, F005_A10_L100_M001_no0)

#complete database ----
database_no0 <- rbind(F01_no0, F02_no0, F005_no0)



#Data with reference pop=1 ----
F01_A5_L30_M005_ref <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005", reference = 1, read.table("Fst0.1_NAl5_NMar30_M0.05_N200_reference", header=T, dec = "."))
F01_A5_L30_M005_ref <- cbind (qdif= F01_A5_L30_M005_ref$Structure_q_values - F01_A5_L30_M005_ref$real_q_values, F01_A5_L30_M005_ref)
F01_A5_L30_M005_ref_no0 <- top(F01_A5_L30_M005_ref, 100, 13, 7)
F01_A5_L30_M005_ref_no0_no1 <- top2(F01_A5_L30_M005_ref, 70, 13, 7)

F01_A10_L30_M005_ref <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005", reference = 1, read.table("Fst0.1_NAl10_NMar30_M0.05_N200_reference", header=T, dec = "."))
F01_A10_L30_M005_ref <- cbind (qdif= F01_A10_L30_M005_ref$Structure_q_values - F01_A10_L30_M005_ref$real_q_values, F01_A10_L30_M005_ref)
F01_A10_L30_M005_ref_no0 <- top(F01_A10_L30_M005_ref, 100, 13, 7)
F01_A10_L30_M005_ref_no0_no1 <- top2(F01_A10_L30_M005_ref, 70, 13, 7)

F01_A5_L30_M001_ref <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001", reference = 1, read.table("Fst0.1_NAl5_NMar30_M0.01_N200_reference", header=T, dec = "."))
F01_A5_L30_M001_ref <- cbind (qdif= F01_A5_L30_M001_ref$Structure_q_values - F01_A5_L30_M001_ref$real_q_values, F01_A5_L30_M001_ref)
F01_A5_L30_M001_ref_no0 <- top(F01_A5_L30_M001_ref, 100, 13, 7)
F01_A5_L30_M001_ref_no0_no1 <- top2(F01_A5_L30_M001_ref, 70, 13, 7)

F01_A10_L30_M001_ref <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001", reference = 1, read.table("Fst0.1_NAl10_NMar30_M0.01_N200_reference", header=T, dec = "."))
F01_A10_L30_M001_ref <- cbind (qdif= F01_A10_L30_M001_ref$Structure_q_values - F01_A10_L30_M001_ref$real_q_values, F01_A10_L30_M001_ref)
F01_A10_L30_M001_ref_no0 <- top(F01_A10_L30_M001_ref, 100, 13, 7)
F01_A10_L30_M001_ref_no0_no1 <- top2(F01_A10_L30_M001_ref, 70, 13, 7)

F01_A5_L30_M005 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005", reference = 0, read.table("Fst0.1_NAl5_NMar30_M0.05_N200", header=T, dec = "."))
F01_A5_L30_M005 <- cbind (qdif= F01_A5_L30_M005$Structure_q_values - F01_A5_L30_M005$real_q_values, F01_A5_L30_M005)
F01_A5_L30_M005_no0 <- top(F01_A5_L30_M005, 100, 13, 7)

F01_A10_L30_M005 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005", reference = 0, read.table("Fst0.1_NAl10_NMar30_M0.05_N200", header=T, dec = "."))
F01_A10_L30_M005 <- cbind (qdif= F01_A10_L30_M005$Structure_q_values - F01_A10_L30_M005$real_q_values, F01_A10_L30_M005)
F01_A10_L30_M005_no0 <- top(F01_A10_L30_M005, 100, 13, 7)

F01_A5_L30_M001 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001", reference = 0, read.table("Fst0.1_NAl5_NMar30_M0.01_N200", header=T, dec = "."))
F01_A5_L30_M001 <- cbind (qdif= F01_A5_L30_M001$Structure_q_values - F01_A5_L30_M001$real_q_values, F01_A5_L30_M001)
F01_A5_L30_M001_no0 <- top(F01_A5_L30_M001, 100, 13, 7)

F01_A10_L30_M001 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001", reference = 0, read.table("Fst0.1_NAl10_NMar30_M0.01_N200", header=T, dec = "."))
F01_A10_L30_M001 <- cbind (qdif= F01_A10_L30_M001$Structure_q_values - F01_A10_L30_M001$real_q_values, F01_A10_L30_M001)
F01_A10_L30_M001_no0 <- top(F01_A10_L30_M001, 100, 13, 7)


F01_L30_reftest_no0 <- rbind(F01_A5_L30_M005_no0, F01_A5_L30_M005_ref_no0, 
                         F01_A10_L30_M005_no0, F01_A10_L30_M005_ref_no0, 
                         F01_A5_L30_M001_no0, F01_A5_L30_M001_ref_no0,
                         F01_A10_L30_M001_no0,  F01_A10_L30_M001_ref_no0)

F01_L30_reftest_no0_no1 <- rbind(F01_A5_L30_M005_no0, F01_A5_L30_M005_ref_no0_no1, 
                             F01_A10_L30_M005_no0, F01_A10_L30_M005_ref_no0_no1, 
                             F01_A5_L30_M001_no0, F01_A5_L30_M001_ref_no0_no1,
                             F01_A10_L30_M001_no0,  F01_A10_L30_M001_ref_no0_no1)

reftest_m005_no0_no1 <- rbind(F01_A5_L30_M005_no0, F01_A5_L30_M005_ref_no0_no1, 
                              F01_A10_L30_M005_no0, F01_A10_L30_M005_ref_no0_no1)

reftest_m001_no0_no1 <- rbind(F01_A5_L30_M001_no0, F01_A5_L30_M001_ref_no0_no1, 
                              F01_A10_L30_M001_no0, F01_A10_L30_M001_ref_no0_no1)

#Data with reference popinfo----
#reference 30 out of 100
F01_A5_L30_M005_ref30 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005", reference = 0.30, popinfo = "OFF", read.table("Fst0.1_NAl5_NMar30_M0.05_N200_reference", header=T, dec = "."))
F01_A5_L30_M005_ref30 <- cbind (qdif= F01_A5_L30_M005_ref30$Structure_q_values - F01_A5_L30_M005_ref30$real_q_values, F01_A5_L30_M005_ref30)
F01_A5_L30_M005_ref30_no0 <- top(F01_A5_L30_M005_ref30, 100, 14, 7)
F01_A5_L30_M005_ref30_no0_no1 <- top2(F01_A5_L30_M005_ref30, 70, 14, 7)

F01_A10_L30_M005_ref30 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005", reference = 0.30, popinfo = "OFF", read.table("Fst0.1_NAl10_NMar30_M0.05_N200_reference", header=T, dec = "."))
F01_A10_L30_M005_ref30 <- cbind (qdif= F01_A10_L30_M005_ref30$Structure_q_values - F01_A10_L30_M005_ref30$real_q_values, F01_A10_L30_M005_ref30)
F01_A10_L30_M005_ref30_no0 <- top(F01_A10_L30_M005_ref30, 100, 14, 7)
F01_A10_L30_M005_ref30_no0_no1 <- top2(F01_A10_L30_M005_ref30, 70, 14, 7)

F01_A5_L30_M001_ref30 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001", reference = 0.30, popinfo = "OFF", read.table("Fst0.1_NAl5_NMar30_M0.01_N200_reference", header=T, dec = "."))
F01_A5_L30_M001_ref30 <- cbind (qdif= F01_A5_L30_M001_ref30$Structure_q_values - F01_A5_L30_M001_ref30$real_q_values, F01_A5_L30_M001_ref30)
F01_A5_L30_M001_ref30_no0 <- top(F01_A5_L30_M001_ref30, 100, 14, 7)
F01_A5_L30_M001_ref30_no0_no1 <- top2(F01_A5_L30_M001_ref30, 70, 14, 7)

F01_A10_L30_M001_ref30 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001", reference = 0.30, popinfo = "OFF", read.table("Fst0.1_NAl10_NMar30_M0.01_N200_reference", header=T, dec = "."))
F01_A10_L30_M001_ref30 <- cbind (qdif= F01_A10_L30_M001_ref30$Structure_q_values - F01_A10_L30_M001_ref30$real_q_values, F01_A10_L30_M001_ref30)
F01_A10_L30_M001_ref30_no0 <- top(F01_A10_L30_M001_ref30, 100, 14, 7)
F01_A10_L30_M001_ref30_no0_no1 <- top2(F01_A10_L30_M001_ref30, 70, 14, 7)

#reference 30 out of 100 with popinfo
F01_A5_L30_M005_ref30_popinfo <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005", reference = 0.30, popinfo = "ON", read.table("Fst0.1_NAl5_NMar30_M0.05_N200_reference_30_popinfo", header=T, dec = "."))
F01_A5_L30_M005_ref30_popinfo <- cbind (qdif= F01_A5_L30_M005_ref30_popinfo$Structure_q_values - F01_A5_L30_M005_ref30_popinfo$real_q_values, F01_A5_L30_M005_ref30_popinfo)
F01_A5_L30_M005_ref30_popinfo_no0 <- top(F01_A5_L30_M005_ref30_popinfo, 100, 12, 7)
F01_A5_L30_M005_ref30_popinfo_no0_no1 <- top2(F01_A5_L30_M005_ref30_popinfo, 70, 12, 7)

F01_A10_L30_M005_ref30_popinfo <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005", reference = 0.30, popinfo = "ON", read.table("Fst0.1_NAl10_NMar30_M0.05_N200_reference_30_popinfo", header=T, dec = "."))
F01_A10_L30_M005_ref30_popinfo <- cbind (qdif= F01_A10_L30_M005_ref30_popinfo$Structure_q_values - F01_A10_L30_M005_ref30_popinfo$real_q_values, F01_A10_L30_M005_ref30_popinfo)
F01_A10_L30_M005_ref30_popinfo_no0 <- top(F01_A10_L30_M005_ref30_popinfo, 100, 12, 7)
F01_A10_L30_M005_ref30_popinfo_no0_no1 <- top2(F01_A10_L30_M005_ref30_popinfo, 70, 12, 7)

F01_A5_L30_M001_ref30_popinfo <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001", reference = 0.30, popinfo = "ON", read.table("Fst0.1_NAl5_NMar30_M0.01_N200_reference_30_popinfo", header=T, dec = "."))
F01_A5_L30_M001_ref30_popinfo <- cbind (qdif= F01_A5_L30_M001_ref30_popinfo$Structure_q_values - F01_A5_L30_M001_ref30_popinfo$real_q_values, F01_A5_L30_M001_ref30_popinfo)
F01_A5_L30_M001_ref30_popinfo_no0 <- top(F01_A5_L30_M001_ref30_popinfo, 100, 12, 7)
F01_A5_L30_M001_ref30_popinfo_no0_no1 <- top2(F01_A5_L30_M001_ref30_popinfo, 70, 12, 7)

F01_A10_L30_M001_ref30_popinfo <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001", reference = 0.30, popinfo = "ON", read.table("Fst0.1_NAl10_NMar30_M0.01_N200_reference_30_popinfo", header=T, dec = "."))
F01_A10_L30_M001_ref30_popinfo <- cbind (qdif= F01_A10_L30_M001_ref30_popinfo$Structure_q_values - F01_A10_L30_M001_ref30_popinfo$real_q_values, F01_A10_L30_M001_ref30_popinfo)
F01_A10_L30_M001_ref30_popinfo_no0 <- top(F01_A10_L30_M001_ref30_popinfo, 100, 12, 7)
F01_A10_L30_M001_ref30_popinfo_no0_no1 <- top2(F01_A10_L30_M001_ref30_popinfo, 70, 12, 7)

#reference 10 out of 100
F01_A5_L30_M005_ref10 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005", reference = 0.10, popinfo = "OFF", read.table("Fst0.1_NAl5_NMar30_M0.05_N200_reference_10", header=T, dec = "."))
F01_A5_L30_M005_ref10 <- cbind (qdif= F01_A5_L30_M005_ref10$Structure_q_values - F01_A5_L30_M005_ref10$real_q_values, F01_A5_L30_M005_ref10)
F01_A5_L30_M005_ref10_no0 <- top(F01_A5_L30_M005_ref10, 100, 14, 7)
F01_A5_L30_M005_ref10_no0_no1 <- top2(F01_A5_L30_M005_ref10, 90, 14, 7)

F01_A10_L30_M005_ref10 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005", reference = 0.10, popinfo = "OFF", read.table("Fst0.1_NAl10_NMar30_M0.05_N200_reference_10", header=T, dec = "."))
F01_A10_L30_M005_ref10 <- cbind (qdif= F01_A10_L30_M005_ref10$Structure_q_values - F01_A10_L30_M005_ref10$real_q_values, F01_A10_L30_M005_ref10)
F01_A10_L30_M005_ref10_no0 <- top(F01_A10_L30_M005_ref10, 100, 14, 7)
F01_A10_L30_M005_ref10_no0_no1 <- top2(F01_A10_L30_M005_ref10, 90, 14, 7)

F01_A5_L30_M001_ref10 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001", reference = 0.10, popinfo = "OFF", read.table("Fst0.1_NAl5_NMar30_M0.01_N200_reference_10", header=T, dec = "."))
F01_A5_L30_M001_ref10 <- cbind (qdif= F01_A5_L30_M001_ref10$Structure_q_values - F01_A5_L30_M001_ref10$real_q_values, F01_A5_L30_M001_ref10)
F01_A5_L30_M001_ref10_no0 <- top(F01_A5_L30_M001_ref10, 100, 14, 7)
F01_A5_L30_M001_ref10_no0_no1 <- top2(F01_A5_L30_M001_ref10, 90, 14, 7)

F01_A10_L30_M001_ref10 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001", reference = 0.10, popinfo = "OFF", read.table("Fst0.1_NAl10_NMar30_M0.01_N200_reference_10", header=T, dec = "."))
F01_A10_L30_M001_ref10 <- cbind (qdif= F01_A10_L30_M001_ref10$Structure_q_values - F01_A10_L30_M001_ref10$real_q_values, F01_A10_L30_M001_ref10)
F01_A10_L30_M001_ref10_no0 <- top(F01_A10_L30_M001_ref10, 100, 14, 7)
F01_A10_L30_M001_ref10_no0_no1 <- top2(F01_A10_L30_M001_ref10, 90, 14, 7)

#reference 10 out of 100 with popinfo
F01_A5_L30_M005_ref10_popinfo <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005", reference = 0.10, popinfo = "ON", read.table("Fst0.1_NAl5_NMar30_M0.05_N200_reference_10_popinfo", header=T, dec = "."))
F01_A5_L30_M005_ref10_popinfo <- cbind (qdif= F01_A5_L30_M005_ref10_popinfo$Structure_q_values - F01_A5_L30_M005_ref10_popinfo$real_q_values, F01_A5_L30_M005_ref10_popinfo)
F01_A5_L30_M005_ref10_popinfo_no0 <- top(F01_A5_L30_M005_ref10_popinfo, 100, 12, 7)
F01_A5_L30_M005_ref10_popinfo_no0_no1 <- top2(F01_A5_L30_M005_ref10_popinfo, 90, 12, 7)

F01_A10_L30_M005_ref10_popinfo <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005", reference = 0.10, popinfo = "ON", read.table("Fst0.1_NAl10_NMar30_M0.05_N200_reference_10_popinfo", header=T, dec = "."))
F01_A10_L30_M005_ref10_popinfo <- cbind (qdif= F01_A10_L30_M005_ref10_popinfo$Structure_q_values - F01_A10_L30_M005_ref10_popinfo$real_q_values, F01_A10_L30_M005_ref10_popinfo)
F01_A10_L30_M005_ref10_popinfo_no0 <- top(F01_A10_L30_M005_ref10_popinfo, 100, 12, 7)
F01_A10_L30_M005_ref10_popinfo_no0_no1 <- top2(F01_A10_L30_M005_ref10_popinfo, 90, 12, 7)

F01_A5_L30_M001_ref10_popinfo <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001", reference = 0.10, popinfo = "ON", read.table("Fst0.1_NAl5_NMar30_M0.01_N200_reference_10_popinfo", header=T, dec = "."))
F01_A5_L30_M001_ref10_popinfo <- cbind (qdif= F01_A5_L30_M001_ref10_popinfo$Structure_q_values - F01_A5_L30_M001_ref10_popinfo$real_q_values, F01_A5_L30_M001_ref10_popinfo)
F01_A5_L30_M001_ref10_popinfo_no0 <- top(F01_A5_L30_M001_ref10_popinfo, 100, 12, 7)
F01_A5_L30_M001_ref10_popinfo_no0_no1 <- top2(F01_A5_L30_M001_ref10_popinfo, 90, 12, 7)

F01_A10_L30_M001_ref10_popinfo <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001", reference = 0.10, popinfo = "ON", read.table("Fst0.1_NAl10_NMar30_M0.01_N200_reference_10_popinfo", header=T, dec = "."))
F01_A10_L30_M001_ref10_popinfo <- cbind (qdif= F01_A10_L30_M001_ref10_popinfo$Structure_q_values - F01_A10_L30_M001_ref10_popinfo$real_q_values, F01_A10_L30_M001_ref10_popinfo)
F01_A10_L30_M001_ref10_popinfo_no0 <- top(F01_A10_L30_M001_ref10_popinfo, 100, 12, 7)
F01_A10_L30_M001_ref10_popinfo_no0_no1 <- top2(F01_A10_L30_M001_ref10_popinfo, 90, 12, 7)


#no reference 
F01_A5_L30_M005 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005", reference = 0, popinfo = "OFF", read.table("Fst0.1_NAl5_NMar30_M0.05_N200", header=T, dec = "."))
F01_A5_L30_M005 <- cbind (qdif= F01_A5_L30_M005$Structure_q_values - F01_A5_L30_M005$real_q_values, F01_A5_L30_M005)
F01_A5_L30_M005_no0 <- top(F01_A5_L30_M005, 100, 14, 7)

F01_A10_L30_M005 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005", reference = 0, popinfo = "OFF", read.table("Fst0.1_NAl10_NMar30_M0.05_N200", header=T, dec = "."))
F01_A10_L30_M005 <- cbind (qdif= F01_A10_L30_M005$Structure_q_values - F01_A10_L30_M005$real_q_values, F01_A10_L30_M005)
F01_A10_L30_M005_no0 <- top(F01_A10_L30_M005, 100, 14, 7)

F01_A5_L30_M001 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001", reference = 0, popinfo = "OFF", read.table("Fst0.1_NAl5_NMar30_M0.01_N200", header=T, dec = "."))
F01_A5_L30_M001 <- cbind (qdif= F01_A5_L30_M001$Structure_q_values - F01_A5_L30_M001$real_q_values, F01_A5_L30_M001)
F01_A5_L30_M001_no0 <- top(F01_A5_L30_M001, 100, 14, 7)

F01_A10_L30_M001 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001", reference = 0, popinfo = "OFF", read.table("Fst0.1_NAl10_NMar30_M0.01_N200", header=T, dec = "."))
F01_A10_L30_M001 <- cbind (qdif= F01_A10_L30_M001$Structure_q_values - F01_A10_L30_M001$real_q_values, F01_A10_L30_M001)
F01_A10_L30_M001_no0 <- top(F01_A10_L30_M001, 100, 14, 7)


F01_L30_reftest2_no0 <- rbind(F01_A5_L30_M005_no0, F01_A5_L30_M005_ref10_no0, F01_A5_L30_M005_ref30_no0,
                              F01_A10_L30_M005_no0, F01_A10_L30_M005_ref10_no0, F01_A10_L30_M005_ref30_no0,
                              F01_A5_L30_M001_no0, F01_A5_L30_M001_ref10_no0, F01_A5_L30_M001_ref30_no0,
                              F01_A10_L30_M001_no0,  F01_A10_L30_M001_ref10_no0,  F01_A10_L30_M001_ref30_no0)
F01_L30_reftest2_no0 <- F01_L30_reftest2_no0[,-12]
F01_L30_reftest2_no0 <- F01_L30_reftest2_no0[,-12]
F01_L30_reftest2_no0 <- rbind(F01_L30_reftest2_no0, F01_A5_L30_M005_ref10_popinfo_no0, F01_A5_L30_M005_ref30_popinfo_no0, F01_A10_L30_M005_ref10_popinfo_no0, F01_A10_L30_M005_ref30_popinfo_no0,
                              F01_A5_L30_M001_ref10_popinfo_no0, F01_A5_L30_M001_ref30_popinfo_no0, F01_A10_L30_M001_ref10_popinfo_no0, F01_A10_L30_M001_ref30_popinfo_no0)


F01_L30_reftest2_no0_no1 <- rbind(F01_A5_L30_M005_no0, F01_A5_L30_M005_ref10_no0_no1, F01_A5_L30_M005_ref30_no0_no1, 
                                  F01_A10_L30_M005_no0, F01_A10_L30_M005_ref10_no0_no1, F01_A10_L30_M005_ref30_no0_no1, 
                                  F01_A5_L30_M001_no0, F01_A5_L30_M001_ref10_no0_no1, F01_A5_L30_M001_ref30_no0_no1, 
                                  F01_A10_L30_M001_no0,  F01_A10_L30_M001_ref10_no0_no1, F01_A10_L30_M001_ref30_no0_no1)
F01_L30_reftest2_no0_no1 <- F01_L30_reftest2_no0_no1[,-12]
F01_L30_reftest2_no0_no1 <- F01_L30_reftest2_no0_no1[,-12]
F01_L30_reftest2_no0_no1 <- rbind(F01_L30_reftest2_no0_no1, F01_A5_L30_M005_ref10_popinfo_no0_no1, F01_A5_L30_M005_ref30_popinfo_no0_no1, 
                                  F01_A10_L30_M005_ref10_popinfo_no0_no1, F01_A10_L30_M005_ref30_popinfo_no0_no1, 
                                  F01_A5_L30_M001_ref10_popinfo_no0_no1, F01_A5_L30_M001_ref30_popinfo_no0_no1,
                                  F01_A10_L30_M001_ref10_popinfo_no0_no1, F01_A10_L30_M001_ref30_popinfo_no0_no1)



reftest2_m005_no0_no1 <- rbind(F01_A5_L30_M005_no0, F01_A5_L30_M005_ref10_no0_no1, F01_A5_L30_M005_ref30_no0_no1, 
                               F01_A10_L30_M005_no0, F01_A10_L30_M005_ref10_no0_no1, F01_A10_L30_M005_ref30_no0_no1)
reftest2_m005_no0_no1 <- reftest2_m005_no0_no1[,-12]
reftest2_m005_no0_no1 <- reftest2_m005_no0_no1[,-12]
reftest2_m005_no0_no1 <- rbind(reftest2_m005_no0_no1, F01_A5_L30_M005_ref10_popinfo_no0_no1, F01_A5_L30_M005_ref30_popinfo_no0_no1, 
                               F01_A10_L30_M005_ref10_popinfo_no0_no1, F01_A10_L30_M005_ref30_popinfo_no0_no1)


reftest2_m001_no0_no1 <- rbind(F01_A5_L30_M001_no0, F01_A5_L30_M001_ref10_no0_no1, F01_A5_L30_M001_ref30_no0_no1,  
                               F01_A10_L30_M001_no0, F01_A10_L30_M001_ref10_no0_no1, F01_A10_L30_M001_ref30_no0_no1)
reftest2_m001_no0_no1 <- reftest2_m001_no0_no1[,-12]
reftest2_m001_no0_no1 <- reftest2_m001_no0_no1[,-12]
reftest2_m001_no0_no1 <- rbind(reftest2_m001_no0_no1, F01_A5_L30_M001_ref10_popinfo_no0_no1, F01_A5_L30_M001_ref30_popinfo_no0_no1, 
                              F01_A10_L30_M001_ref10_popinfo_no0_no1, F01_A10_L30_M001_ref30_popinfo_no0_no1)

#Data with N=200----
#30 markers and 5 alleles
F01_A5_L30_M001_N200 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001_N200", read.table("Fst0.1_NAl5_NMar30_M0.01_N400", header=T, dec = "."))
F01_A5_L30_M001_N200 <- cbind (qdif= F01_A5_L30_M001_N200$Structure_q_values - F01_A5_L30_M001_N200$real_q_values, F01_A5_L30_M001_N200)
F01_A5_L30_M001_N200_no0 <- top(F01_A5_L30_M001_N200, 200, 12, 7)

F01_A5_L30_M005_N200 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005_N200", read.table("Fst0.1_NAl5_NMar30_M0.05_N400", header=T, dec = "."))
F01_A5_L30_M005_N200 <- cbind (qdif= F01_A5_L30_M005_N200$Structure_q_values - F01_A5_L30_M005_N200$real_q_values, F01_A5_L30_M005_N200)
F01_A5_L30_M005_N200_no0 <- top(F01_A5_L30_M005_N200, 200, 12, 7)

#30 markers and 10 alleles
F01_A10_L30_M001_N200 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001_N200", read.table("Fst0.1_NAl10_NMar30_M0.01_N400", header=T, dec = "."))
F01_A10_L30_M001_N200 <- cbind (qdif= F01_A10_L30_M001_N200$Structure_q_values - F01_A10_L30_M001_N200$real_q_values, F01_A10_L30_M001_N200)
F01_A10_L30_M001_N200_no0 <- top(F01_A10_L30_M001_N200, 200, 12, 7)

F01_A10_L30_M005_N200 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005_N200", read.table("Fst0.1_NAl10_NMar30_M0.05_N400", header=T, dec = "."))
F01_A10_L30_M005_N200 <- cbind (qdif= F01_A10_L30_M005_N200$Structure_q_values - F01_A10_L30_M005_N200$real_q_values, F01_A10_L30_M005_N200)
F01_A10_L30_M005_N200_no0 <- top(F01_A10_L30_M005_N200, 200, 12, 7)

#Data with N=500----
#30 markers and 5 alleles
F01_A5_L30_M001_N500 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001_N500", read.table("Fst0.1_NAl5_NMar30_M0.01_N1000", header=T, dec = "."))
F01_A5_L30_M001_N500 <- cbind (qdif= F01_A5_L30_M001_N500$Structure_q_values - F01_A5_L30_M001_N500$real_q_values, F01_A5_L30_M001_N500)
F01_A5_L30_M001_N500_no0 <- top(F01_A5_L30_M001_N500, 500, 12, 7)

F01_A5_L30_M005_N500 <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005_N500", read.table("Fst0.1_NAl5_NMar30_M0.05_N1000", header=T, dec = "."))
F01_A5_L30_M005_N500 <- cbind (qdif= F01_A5_L30_M005_N500$Structure_q_values - F01_A5_L30_M005_N500$real_q_values, F01_A5_L30_M005_N500)
F01_A5_L30_M005_N500_no0 <- top(F01_A5_L30_M005_N500, 500, 12, 7)

#30 markers and 10 alleles
F01_A10_L30_M001_N500 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001_N500", read.table("Fst0.1_NAl10_NMar30_M0.01_N1000", header=T, dec = "."))
F01_A10_L30_M001_N500 <- cbind (qdif= F01_A10_L30_M001_N500$Structure_q_values - F01_A10_L30_M001_N500$real_q_values, F01_A10_L30_M001_N500)
F01_A10_L30_M001_N500_no0 <- top(F01_A10_L30_M001_N500, 500, 12, 7)

F01_A10_L30_M005_N500 <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005_N500", read.table("Fst0.1_NAl10_NMar30_M0.05_N1000", header=T, dec = "."))
F01_A10_L30_M005_N500 <- cbind (qdif= F01_A10_L30_M005_N500$Structure_q_values - F01_A10_L30_M005_N500$real_q_values, F01_A10_L30_M005_N500)
F01_A10_L30_M005_N500_no0 <- top(F01_A10_L30_M005_N500, 500, 12, 7)

#Data with N=100 and independent allele frequencies----
#30 markers and 5 alleles
F01_A5_L30_M001_N100_indep <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.01, rep="F01_A5_L30_M001_N100_indep", read.table("Fst0.1_NAl5_NMar30_M0.01_N200_indep", header=T, dec = "."))
F01_A5_L30_M001_N100_indep <- cbind (qdif= F01_A5_L30_M001_N100_indep$Structure_q_values - F01_A5_L30_M001_N100_indep$real_q_values, F01_A5_L30_M001_N100_indep)
F01_A5_L30_M001_N100_indep_no0 <- top(F01_A5_L30_M001_N100_indep, 100, 12, 7)

F01_A5_L30_M005_N100_indep <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_M005_N100_indep", read.table("Fst0.1_NAl5_NMar30_M0.05_N200_indep", header=T, dec = "."))
F01_A5_L30_M005_N100_indep <- cbind (qdif= F01_A5_L30_M005_N100_indep$Structure_q_values - F01_A5_L30_M005_N100_indep$real_q_values, F01_A5_L30_M005_N100_indep)
F01_A5_L30_M005_N100_indep_no0 <- top(F01_A5_L30_M005_N100_indep, 100, 12, 7)

#30 markers and 10 alleles
F01_A10_L30_M001_N100_indep <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.01, rep="F01_A10_L30_M001_N100_indep", read.table("Fst0.1_NAl10_NMar30_M0.01_N200_indep", header=T, dec = "."))
F01_A10_L30_M001_N100_indep <- cbind (qdif= F01_A10_L30_M001_N100_indep$Structure_q_values - F01_A10_L30_M001_N100_indep$real_q_values, F01_A10_L30_M001_N100_indep)
F01_A10_L30_M001_N100_indep_no0 <- top(F01_A10_L30_M001_N100_indep, 100, 12, 7)

F01_A10_L30_M005_N100_indep <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_M005_N100_indep", read.table("Fst0.1_NAl10_NMar30_M0.05_N200_indep", header=T, dec = "."))
F01_A10_L30_M005_N100_indep <- cbind (qdif= F01_A10_L30_M005_N100_indep$Structure_q_values - F01_A10_L30_M005_N100_indep$real_q_values, F01_A10_L30_M005_N100_indep)
F01_A10_L30_M005_N100_indep_no0 <- top(F01_A10_L30_M005_N100_indep, 100, 12, 7)


#100 markers and 5 alleles
F01_A5_L100_M001_N100_indep <- cbind(Fst=0.1, alleles=5, loci = 100, m=0.01, rep="F01_A5_L100_M001_N100_indep", read.table("Fst0.1_NAl5_NMar100_M0.01_N200_indep", header=T, dec = "."))
F01_A5_L100_M001_N100_indep <- cbind (qdif= F01_A5_L100_M001_N100_indep$Structure_q_values - F01_A5_L100_M001_N100_indep$real_q_values, F01_A5_L100_M001_N100_indep)
F01_A5_L100_M001_N100_indep_no0 <- top(F01_A5_L100_M001_N100_indep, 100, 12, 7)

F01_A5_L100_M005_N100_indep <- cbind(Fst=0.1, alleles=5, loci = 100, m=0.05, rep="F01_A5_L100_M005_N100_indep", read.table("Fst0.1_NAl5_NMar100_M0.05_N200_indep", header=T, dec = "."))
F01_A5_L100_M005_N100_indep <- cbind (qdif= F01_A5_L100_M005_N100_indep$Structure_q_values - F01_A5_L100_M005_N100_indep$real_q_values, F01_A5_L100_M005_N100_indep)
F01_A5_L100_M005_N100_indep_no0 <- top(F01_A5_L100_M005_N100_indep, 100, 12, 7)

#100 markers and 10 alleles
F01_A10_L100_M001_N100_indep <- cbind(Fst=0.1, alleles=10, loci = 100, m=0.01, rep="F01_A10_L100_M001_N100_indep", read.table("Fst0.1_NAl10_NMar100_M0.01_N200_indep", header=T, dec = "."))
F01_A10_L100_M001_N100_indep <- cbind (qdif= F01_A10_L100_M001_N100_indep$Structure_q_values - F01_A10_L100_M001_N100_indep$real_q_values, F01_A10_L30_M001_N100_indep)
F01_A10_L100_M001_N100_indep_no0 <- top(F01_A10_L100_M001_N100_indep, 100, 12, 7)

F01_A10_L100_M005_N100_indep <- cbind(Fst=0.1, alleles=10, loci = 100, m=0.05, rep="F01_A10_L100_M005_N100_indep", read.table("Fst0.1_NAl10_NMar100_M0.05_N200_indep", header=T, dec = "."))
F01_A10_L100_M005_N100_indep <- cbind (qdif= F01_A10_L100_M005_N100_indep$Structure_q_values - F01_A10_L100_M005_N100_indep$real_q_values, F01_A10_L100_M005_N100_indep)
F01_A10_L100_M005_N100_indep_no0 <- top(F01_A10_L100_M005_N100_indep, 100, 12, 7)


#Reference test: reference 200 and 5 admixed with independent allele frequencies----
#30 markers and 5 alleles
F01_A5_L30_N205_reference_indep <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_N205_reference_indep", read.table("Fst0.1_NAl5_NMar30_M_N205_200_reference", header=T, dec = "."))
F01_A5_L30_N205_reference_indep <- cbind (qdif= F01_A5_L30_N205_reference_indep$Structure_q_values - F01_A5_L30_N205_reference_indep$real_q_values, F01_A5_L30_N205_reference_indep)
F01_A5_L30_N205_reference_indep_no0 <- top(F01_A5_L30_N205_reference_indep, 100, 10, 7)
F01_A5_L30_N205_reference_indep_no0_no1 <- top2(F01_A5_L30_N205_reference_indep, 5, 10, 7)

#30 markers and 10 alleles
F01_A10_L30_N205_reference_indep <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_N205_reference_indep", read.table("Fst0.1_NAl10_NMar30_M_N205_200_reference", header=T, dec = "."))
F01_A10_L30_N205_reference_indep <- cbind (qdif= F01_A10_L30_N205_reference_indep$Structure_q_values - F01_A10_L30_N205_reference_indep$real_q_values, F01_A10_L30_N205_reference_indep)
F01_A10_L30_N205_reference_indep_no0 <- top(F01_A10_L30_N205_reference_indep, 100, 10, 7)
F01_A10_L30_N205_reference_indep_no0_no1 <- top2(F01_A10_L30_N205_reference_indep, 5, 10, 7)

#Reference test: reference 200 and 5 admixed with correlated allele frequencies----
#30 markers and 5 alleles
F01_A5_L30_N205_reference_corr <- cbind(Fst=0.1, alleles=5, loci = 30, m=0.05, rep="F01_A5_L30_N205_reference_corr", read.table("Fst0.1_NAl5_NMar30_M_N205_200_reference_corr", header=T, dec = "."))
F01_A5_L30_N205_reference_corr <- cbind (qdif= F01_A5_L30_N205_reference_corr$Structure_q_values - F01_A5_L30_N205_reference_corr$real_q_values, F01_A5_L30_N205_reference_corr)
F01_A5_L30_N205_reference_corr_no0 <- top(F01_A5_L30_N205_reference_corr, 100, 10, 7)
F01_A5_L30_N205_reference_corr_no0_no1 <- top2(F01_A5_L30_N205_reference_corr, 5, 10, 7)

#30 markers and 10 alleles
F01_A10_L30_N205_reference_corr <- cbind(Fst=0.1, alleles=10, loci = 30, m=0.05, rep="F01_A10_L30_N205_reference_corr", read.table("Fst0.1_NAl10_NMar30_M_N205_200_reference", header=T, dec = "."))
F01_A10_L30_N205_reference_corr <- cbind (qdif= F01_A10_L30_N205_reference_corr$Structure_q_values - F01_A10_L30_N205_reference_corr$real_q_values, F01_A10_L30_N205_reference_corr)
F01_A10_L30_N205_reference_corr_no0 <- top(F01_A10_L30_N205_reference_corr, 100, 10, 7)
F01_A10_L30_N205_reference_corr_no0_no1 <- top2(F01_A10_L30_N205_reference_corr, 5, 10, 7)


#Reference test: reference 200 and 5 admixed with correlated allele frequencies----
#100 markers and 5 alleles
F01_A5_L100_N205_reference_corr <- cbind(Fst=0.1, alleles=5, loci = 100, m=0.05, rep="F01_A5_L100_N205_reference_corr", read.table("Fst0.1_NAl5_NMar100_M_N205_200_reference_corr", header=T, dec = "."))
F01_A5_L100_N205_reference_corr <- cbind (qdif= F01_A5_L100_N205_reference_corr$Structure_q_values - F01_A5_L100_N205_reference_corr$real_q_values, F01_A5_L100_N205_reference_corr)
F01_A5_L100_N205_reference_corr_no0 <- top(F01_A5_L100_N205_reference_corr, 100, 10, 7)
F01_A5_L100_N205_reference_corr_no0_no1 <- top2(F01_A5_L100_N205_reference_corr, 5, 10, 7)

#100 markers and 10 alleles
F01_A10_L100_N205_reference_corr <- cbind(Fst=0.1, alleles=10, loci = 100, m=0.05, rep="F01_A10_L100_N205_reference_corr", read.table("Fst0.1_NAl10_NMar100_M_N205_200_reference_corr", header=T, dec = "."))
F01_A10_L100_N205_reference_corr <- cbind (qdif= F01_A10_L100_N205_reference_corr$Structure_q_values - F01_A10_L100_N205_reference_corr$real_q_values, F01_A10_L100_N205_reference_corr)
F01_A10_L100_N205_reference_corr_no0 <- top(F01_A10_L100_N205_reference_corr, 100, 10, 7)
F01_A10_L100_N205_reference_corr_no0_no1 <- top2(F01_A10_L100_N205_reference_corr, 5, 10, 7)


##other softwares----
#admixture
#100 markers, 2 alleles, migration 1%
F01_A2_L100_M001_N200_admixture <- cbind(Fst=0.1, alleles=2, loci = 100, m=0.01, rep="F01_A2_L100_M001_N200_admixture", software = "Admixture", read.table("Fst0.1_NAl2_NMar100_M0.01_N200_admixture", header=T, dec = "."))
F01_A2_L100_M001_N200_admixture <- cbind (qdif= F01_A2_L100_M001_N200_admixture$Structure_q_values - F01_A2_L100_M001_N200_admixture$real_q_values, F01_A2_L100_M001_N200_admixture)
F01_A2_L100_M001_N200_admixture_no0 <- top(F01_A2_L100_M001_N200_admixture, 100, 11, 7)

#100 markers, 2 alleles, migration 5% 
F01_A2_L100_M005_N200_admixture <- cbind(Fst=0.1, alleles=2, loci = 100, m=0.05, rep="F01_A2_L100_M005_N200_admixture", software = "Admixture", read.table("Fst0.1_NAl2_NMar100_M0.05_N200_admixture", header=T, dec = "."))
F01_A2_L100_M005_N200_admixture <- cbind (qdif= F01_A2_L100_M005_N200_admixture$Structure_q_values - F01_A2_L100_M005_N200_admixture$real_q_values, F01_A2_L100_M005_N200_admixture)
F01_A2_L100_M005_N200_admixture_no0 <- top(F01_A2_L100_M005_N200_admixture, 100, 11, 7)

#ohana
#100 markers, 2 alleles, migration 1%
F01_A2_L100_M001_N200_ohana <- cbind(Fst=0.1, alleles=2, loci = 100, m=0.01, rep="F01_A2_L100_M001_N200_ohana", software = "Ohana", read.table("Fst0.1_NAl2_NMar100_M0.01_N200_ohana", header=T, dec = "."))
F01_A2_L100_M001_N200_ohana <- cbind (qdif= F01_A2_L100_M001_N200_ohana$Structure_q_values - F01_A2_L100_M001_N200_ohana$real_q_values, F01_A2_L100_M001_N200_ohana)
F01_A2_L100_M001_N200_ohana_no0 <- top(F01_A2_L100_M001_N200_ohana, 100, 11, 7)

#100 markers, 2 alleles, migration 5% 
F01_A2_L100_M005_N200_ohana <- cbind(Fst=0.1, alleles=2, loci = 100, m=0.05, rep="F01_A2_L100_M005_N200_ohana", software = "Ohana", read.table("Fst0.1_NAl2_NMar100_M0.05_N200_ohana", header=T, dec = "."))
F01_A2_L100_M005_N200_ohana <- cbind (qdif= F01_A2_L100_M005_N200_ohana$Structure_q_values - F01_A2_L100_M005_N200_ohana$real_q_values, F01_A2_L100_M005_N200_ohana)
F01_A2_L100_M005_N200_ohana_no0 <- top(F01_A2_L100_M005_N200_ohana, 100, 11, 7)

#sNMF
#100 markers, 2 alleles, migration 1%
F01_A2_L100_M001_N200_snmf <- cbind(Fst=0.1, alleles=2, loci = 100, m=0.01, rep="F01_A2_L100_M001_N200_snmf", software = "sNMF", read.table("Fst0.1_NAl2_NMar100_M0.01_N200_snmf", header=T, dec = "."))
F01_A2_L100_M001_N200_snmf <- cbind (qdif= F01_A2_L100_M001_N200_snmf$Structure_q_values - F01_A2_L100_M001_N200_snmf$real_q_values, F01_A2_L100_M001_N200_snmf)
F01_A2_L100_M001_N200_snmf_no0 <- top(F01_A2_L100_M001_N200_snmf, 100, 11, 7)

#100 markers, 2 alleles, migration 5% 
F01_A2_L100_M005_N200_snmf <- cbind(Fst=0.1, alleles=2, loci = 100, m=0.05, rep="F01_A2_L100_M005_N200_snmf", software = "sNMF", read.table("Fst0.1_NAl2_NMar100_M0.05_N200_snmf", header=T, dec = "."))
F01_A2_L100_M005_N200_snmf <- cbind (qdif= F01_A2_L100_M005_N200_snmf$Structure_q_values - F01_A2_L100_M005_N200_snmf$real_q_values, F01_A2_L100_M005_N200_snmf)
F01_A2_L100_M005_N200_snmf_no0 <- top(F01_A2_L100_M005_N200_snmf, 100, 11, 7)

#structure
F01_A2_L100_M001_str <- cbind(Fst=0.1, alleles=2, loci = 100, m=0.01, rep="F01_A2_L100_M001_str", software = "Structure", read.table("Fst0.1_NAl2_NMar100_M0.01_N200", header=T, dec = "."))
F01_A2_L100_M001_str <- cbind (qdif= F01_A2_L100_M001_str$Structure_q_values - F01_A2_L100_M001_str$real_q_values, F01_A2_L100_M001_str)
F01_A2_L100_M001_str$minimum_CI <- NULL
F01_A2_L100_M001_str$maximum_CI <- NULL
F01_A2_L100_M001_str_no0 <- top(F01_A2_L100_M001_str, 100, 11, 7)

F01_A2_L100_M005_str <- cbind(Fst=0.1, alleles=2, loci = 100, m=0.05, rep="F01_A2_L100_M005_str", software = "Structure", read.table("Fst0.1_NAl2_NMar100_M0.05_N200", header=T, dec = "."))
F01_A2_L100_M005_str <- cbind (qdif= F01_A2_L100_M005_str$Structure_q_values - F01_A2_L100_M005_str$real_q_values, F01_A2_L100_M005_str)
F01_A2_L100_M005_str$minimum_CI <- NULL
F01_A2_L100_M005_str$maximum_CI <- NULL
F01_A2_L100_M005_str_no0 <- top(F01_A2_L100_M005_str, 100, 11, 7)

dataset_softwares <- rbind(F01_A2_L100_M001_str, F01_A2_L100_M005_str, F01_A2_L100_M001_N200_admixture, F01_A2_L100_M005_N200_admixture,
                           F01_A2_L100_M001_N200_ohana, F01_A2_L100_M005_N200_ohana, F01_A2_L100_M001_N200_snmf, F01_A2_L100_M005_N200_snmf)


