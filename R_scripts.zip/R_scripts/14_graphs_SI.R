### S2: number of alleles per locus ----

setwd('C:/results/alleles_number')


# Fst 0.1
read.table("allele_number_Fst0.1_NAl2_NMar100_M0.01", header=T, sep=" ") -> alleles11
F01_Al2_M001 <- cbind(Fst=0.1, allele_maximum_number=2, loci = 100, m=0.01, rep="F01_Al2_M001", alleles11)

read.table("allele_number_Fst0.1_NAl2_NMar100_M0.05", header=T, sep=" ") -> alleles12
F01_Al2_M005 <- cbind(Fst=0.1, allele_maximum_number=2, loci = 100, m=0.05, rep="F01_Al2_M005", alleles12)

read.table("allele_number_Fst0.1_NAl5_NMar100_M0.01", header=T, sep=" ") -> alleles29
F01_Al5_M001 <- cbind(Fst=0.1, allele_maximum_number=5, loci = 100, m=0.01, rep="F01_Al5_M001", alleles29)

read.table("allele_number_Fst0.1_NAl5_NMar100_M0.05", header=T, sep=" ") -> alleles30
F01_Al5_M005 <- cbind(Fst=0.1, allele_maximum_number=5, loci = 100, m=0.05, rep="F01_Al5_M005", alleles30)

read.table("allele_number_Fst0.1_NAl10_NMar100_M0.01", header=T, sep=" ") -> alleles47
F01_Al10_M001 <- cbind(Fst=0.1, allele_maximum_number=10, loci = 100, m=0.01, rep="F01_Al10_M001", alleles47)

read.table("allele_number_Fst0.1_NAl10_NMar100_M0.05", header=T, sep=" ") -> alleles48
F01_Al10_M005 <- cbind(Fst=0.1, allele_maximum_number=10, loci = 100, m=0.05, rep="F01_Al10_M005", alleles48)

alleles <- rbind(F01_Al2_M001, F01_Al2_M005, F01_Al5_M001, F01_Al5_M005, F01_Al10_M001, F01_Al10_M005)

#Fst 0.05
read.table("allele_number_Fst0.05_NAl2_NMar100_M0.01", header=T, sep=" ") -> alleles5
F005_Al2_M001 <- cbind(Fst=0.05, allele_maximum_number=2, loci = 100, m=0.01, rep="F005_Al2_M001", alleles5)

read.table("allele_number_Fst0.05_NAl2_NMar100_M0.05", header=T, sep=" ") -> alleles6
F005_Al2_M005 <- cbind(Fst=0.05, allele_maximum_number=2, loci = 100, m=0.05, rep="F005_Al2_M005", alleles6)

read.table("allele_number_Fst0.05_NAl5_NMar100_M0.01", header=T, sep=" ") -> alleles23
F005_Al5_M001 <- cbind(Fst=0.05, allele_maximum_number=5, loci = 100, m=0.01, rep="F005_Al5_M001", alleles23)

read.table("allele_number_Fst0.05_NAl5_NMar100_M0.05", header=T, sep=" ") -> alleles24
F005_Al5_M005 <- cbind(Fst=0.05, allele_maximum_number=5, loci = 100, m=0.05, rep="F005_Al5_M005", alleles24)

read.table("allele_number_Fst0.05_NAl10_NMar100_M0.01", header=T, sep=" ") -> alleles41
F005_Al10_M001 <- cbind(Fst=0.05, allele_maximum_number=10, loci = 100, m=0.01, rep="F005_Al10_M001", alleles41)

read.table("allele_number_Fst0.05_NAl10_NMar100_M0.05", header=T, sep=" ") -> alleles42
F005_Al10_M005 <- cbind(Fst=0.05, allele_maximum_number=10, loci = 100, m=0.05, rep="F005_Al10_M005", alleles42)

alleles <- rbind(alleles, F005_Al2_M001, F005_Al2_M005, F005_Al5_M001, F005_Al5_M005, F005_Al10_M001, F005_Al10_M005)

#Fst 0.2
read.table("allele_number_Fst0.2_NAl2_NMar100_M0.01", header=T, sep=" ") -> alleles17
F02_Al2_M001 <- cbind(Fst=0.2, allele_maximum_number=2, loci = 100, m=0.01, rep="F02_Al2_M001", alleles17)

read.table("allele_number_Fst0.2_NAl2_NMar100_M0.05", header=T, sep=" ") -> alleles18
F02_Al2_M005 <- cbind(Fst=0.2, allele_maximum_number=2, loci = 100, m=0.05, rep="F02_Al2_M005", alleles18)

read.table("allele_number_Fst0.2_NAl5_NMar100_M0.01", header=T, sep=" ") -> alleles35
F02_Al5_M001 <- cbind(Fst=0.2, allele_maximum_number=5, loci = 100, m=0.01, rep="F02_Al5_M001", alleles35)

read.table("allele_number_Fst0.2_NAl5_NMar100_M0.05", header=T, sep=" ") -> alleles36
F02_Al5_M005 <- cbind(Fst=0.2, allele_maximum_number=5, loci = 100, m=0.05, rep="F02_Al5_M005", alleles36)

read.table("allele_number_Fst0.2_NAl10_NMar100_M0.01", header=T, sep=" ") -> alleles53
F02_Al10_M001 <- cbind(Fst=0.2, allele_maximum_number=10, loci = 100, m=0.01, rep="F02_Al10_M001", alleles53)

read.table("allele_number_Fst0.2_NAl10_NMar100_M0.05", header=T, sep=" ") -> alleles54
F02_Al10_M005 <- cbind(Fst=0.2, allele_maximum_number=10, loci = 100, m=0.05, rep="F02_Al10_M005", alleles54)

alleles <- rbind(alleles, F02_Al2_M001, F02_Al2_M005, F02_Al5_M001, F02_Al5_M005, F02_Al10_M001, F02_Al10_M005)

alleles$Fst <- as.factor(alleles$Fst)
alleles$allele_maximum_number <- as.factor(alleles$allele_maximum_number)

ggplot(aes(y = allele_number, x = allele_maximum_number, color = Fst), data = alleles) + geom_boxplot() + labs(color = expression("F"[ST])) + #labs(fill = expression("F"[ST])) +
  xlab('Maximum number of alleles') + ylab('Average number of alleles per locus in simulations') + theme_bw()

subset10 <- subset(alleles, allele_maximum_number == 5) 
subset10_02 <- subset(subset10, Fst == 0.2)
subset10_01 <- subset(subset10, Fst == 0.1)
subset10_005 <- subset(subset10, Fst == 0.05)
summary(subset10_02)
summary(subset10_01)
summary(subset10_005)

subset10 <- subset(alleles, allele_maximum_number == 10) 
subset10_02 <- subset(subset10, Fst == 0.2)
subset10_01 <- subset(subset10, Fst == 0.1)
subset10_005 <- subset(subset10, Fst == 0.05)
summary(subset10_02)
summary(subset10_01)
summary(subset10_005)

subset10 <- subset(alleles, allele_maximum_number == 2) 
subset10_02 <- subset(subset10, Fst == 0.2)
subset10_01 <- subset(subset10, Fst == 0.1)
subset10_005 <- subset(subset10, Fst == 0.05)
summary(subset10_02)
summary(subset10_01)
summary(subset10_005)

### S1: Fst vs number of alleles per locus ----

setwd('C:/results/fst')

#microsatellites 10 alleles
read.table("Fst0.0510microsatellites", header=F, sep=" ")->fst1 
F005_A10 <- cbind(Fst=0.05, alleles=10, fst1)
summary(F005_A10)

read.table("Fst0.110microsatellites", header=F, sep=" ")->fst2 
F01_A10 <- cbind(Fst=0.1, alleles=10, fst2)
summary(F01_A10)

read.table("Fst0.210microsatellites", header=F, sep=" ")->fst3
F02_A10 <- cbind(Fst=0.2, alleles=10, fst3)
summary(F02_A10)

Fst_10 <- rbind(F005_A10, F01_A10, F02_A10)
Fst_10$Fst <- as.factor(Fst_10$Fst)

ggplot(Fst_10, aes(x = Fst, y = V1, group = Fst, color = Fst)) +
  geom_boxplot() +
  labs(title="Fst_10_alleles") + xlab('expected_Fst') + ylab('obtained_Fst') + theme_bw() + theme(legend.position="none") 

p3 <- ggplot(Fst_10, aes(x = Fst, y = V1, group = Fst)) +
  geom_boxplot() + ylim(0,0.25) +
  labs(title="Fst_10_alleles") + xlab('expected_Fst') + ylab('obtained_Fst') + theme_bw() + theme(legend.position="none") 

#microsatellites 5 alleles
read.table("Fst0.055microsatellites", header=F, sep=" ")->fst4 
F005_A5 <- cbind(Fst=0.05, alleles=5, fst4)
summary(F005_A5)

read.table("Fst0.15microsatellites", header=F, sep=" ")->fst5 
F01_A5 <- cbind(Fst=0.1, alleles=5, fst5)
summary(F01_A5)

read.table("Fst0.25microsatellites", header=F, sep=" ")->fst6 
F02_A5 <- cbind(Fst=0.2, alleles=5, fst6)
summary(F02_A5)

Fst_5 <- rbind(F005_A5, F01_A5, F02_A5)
Fst_5$Fst <- as.factor(Fst_5$Fst)

ggplot(Fst_5, aes(x = Fst, y = V1, group = Fst, fill = Fst)) +
  geom_boxplot() +
  labs(title="Fst_5_alleles") + xlab('expected_Fst') + ylab('obtained_Fst') + theme(legend.position="none")

p2 <- ggplot(Fst_5, aes(x = Fst, y = V1, group = Fst)) +
  geom_boxplot() + ylim(0,0.25) +
  labs(title="Fst_5_alleles") + xlab('expected_Fst') + ylab('obtained_Fst') + theme_bw() + theme(legend.position="none") 

#snp 2 alles
read.table("Fst0.052SNP", header=F, sep=" ")->fst7 
F005_A2 <- cbind(Fst=0.05, alleles=2, fst7)
summary(F005_A2)

read.table("Fst0.12SNP", header=F, sep=" ")->fst8 
F01_A2 <- cbind(Fst=0.1, alleles=2, fst8)
summary(F01_A2)

read.table("Fst0.22SNP", header=F, sep=" ")->fst9 
F02_A2 <- cbind(Fst=0.2, alleles=2, fst9)
summary(F02_A2)

Fst_2 <- rbind(F005_A2, F01_A2, F02_A2)
Fst_2$Fst <- as.factor(Fst_2$Fst)

ggplot(Fst_2, aes(x = Fst, y = V1, group = Fst, fill = Fst)) +
  geom_boxplot() +
  labs(title="Fst_2_alleles") + xlab('expected_Fst') + ylab('obtained_Fst') + theme(legend.position="none")

ggplot(Fst_2, aes(x = Fst, y = V1, group = Fst, color = Fst)) +
  geom_boxplot() +
  labs(title="Fst_2_alleles") + xlab('expected_Fst') + ylab('obtained_Fst') + theme_bw() + theme(legend.position="none") 

p1 <- ggplot(Fst_2, aes(x = Fst, y = V1, group = Fst)) +
  geom_boxplot() + ylim(0,0.25) +
  labs(title="Fst_2_alleles") + xlab('expected_Fst') + ylab('obtained_Fst') + theme_bw() + theme(legend.position="none") 

grid.arrange(p1, p2, p3, ncol=3)

#table
Fst_tot <- rbind(F005_A10, F01_A10, F02_A10, F005_A5, F01_A5, F02_A5, F005_A2, F01_A2, F02_A2)
