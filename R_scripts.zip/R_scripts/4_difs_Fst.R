### plot q difference between q structure and q real, check assumptions and run models for number of alleles and Fst values

library(betareg) 

# m 0.05 ----
  
  qdif26 <- ggplot(data= F02_A5_L100_M005_no0, aes(x=real_q_values, y=qdif)) +
    labs(title = "F02_A5_L100_M005_no0", x= "real_q_values", y = "qdif")  + theme_bw() + 
    geom_point(size=1, colour=I(alpha("blue",1/15))) + 
    geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(-0.35,0.5), xlim=c(0,1))

  qdif27 <- ggplot(data= F02_A10_L100_M005_no0, aes(x=real_q_values, y=qdif)) +
    labs(title = "F02_A10_L100_M005_no0", x= "real_q_values", y = "qdif")  + theme_bw() + 
    geom_point(size=1, colour=I(alpha("blue",1/15))) + 
    geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(-0.35,0.5), xlim=c(0,1))

  qdif8 <- ggplot(data= F01_A5_L100_M005_no0, aes(x=real_q_values, y=qdif)) +
    labs(title = "F01_A5_L100_M005_no0", x= "real_q_values", y = "qdif")  + theme_bw() + 
    geom_point(size=1, colour=I(alpha("blue",1/15))) + 
    geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(-0.35,0.5), xlim=c(0,1))

  qdif9 <- ggplot(data= F01_A10_L100_M005_no0, aes(x=real_q_values, y=qdif)) +
    labs(title = "F01_A10_L100_M005_no0", x= "real_q_values", y = "qdif")  + theme_bw() + 
    geom_point(size=1, colour=I(alpha("blue",1/15))) + 
    geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(-0.35,0.5), xlim=c(0,1))

  qdif44 <- ggplot(data= F005_A5_L100_M005_no0, aes(x=real_q_values, y=qdif)) +
    labs(title = "F005_A5_L100_M005_no0", x= "real_q_values", y = "qdif")  + theme_bw() + 
    geom_point(size=1, colour=I(alpha("blue",1/15))) + 
    geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(-0.35,0.5), xlim=c(0,1))

  qdif45 <- ggplot(data= F005_A10_L100_M005_no0, aes(x=real_q_values, y=qdif)) +
    labs(title = "F005_A10_L100_M005_no0", x= "real_q_values", y = "qdif")  + theme_bw() + 
    geom_point(size=1, colour=I(alpha("blue",1/15))) + 
    geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(-0.35,0.5), xlim=c(0,1))

  grid.arrange(qdif26, qdif27, qdif8, qdif9, qdif44, qdif45, top = "m 0.05")


  F02_A5_L100_M005_no0$qdif_abs <- abs(F02_A5_L100_M005_no0$qdif)
  F02_A10_L100_M005_no0$qdif_abs <- abs(F02_A10_L100_M005_no0$qdif)
  F01_A5_L100_M005_no0$qdif_abs <- abs(F01_A5_L100_M005_no0$qdif)
  F01_A10_L100_M005_no0$qdif_abs <- abs(F01_A10_L100_M005_no0$qdif)
  F005_A5_L100_M005_no0$qdif_abs <- abs(F005_A5_L100_M005_no0$qdif)
  F005_A10_L100_M005_no0$qdif_abs <- abs(F005_A10_L100_M005_no0$qdif)
    
    
  qdif_abs26 <- ggplot(data= F02_A5_L100_M005_no0, aes(x=real_q_values, y=qdif_abs)) +
      labs(title = "F02_A5_L100_M005_no0", x= "real_q_values", y = "qdif_abs")  + theme_bw() + 
      geom_point(size=1, colour=I(alpha("blue",1/15))) + 
      geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(0,0.8), xlim=c(0,1))
    
  qdif_abs27 <- ggplot(data= F02_A10_L100_M005_no0, aes(x=real_q_values, y=qdif_abs)) +
      labs(title = "F02_A10_L100_M005_no0", x= "real_q_values", y = "qdif_abs")  + theme_bw() + 
      geom_point(size=1, colour=I(alpha("blue",1/15))) + 
      geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(0,0.8), xlim=c(0,1))
    
  qdif_abs8 <- ggplot(data= F01_A5_L100_M005_no0, aes(x=real_q_values, y=qdif_abs)) +
      labs(title = "F01_A5_L100_M005_no0", x= "real_q_values", y = "qdif_abs")  + theme_bw() + 
      geom_point(size=1, colour=I(alpha("blue",1/15))) + 
      geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(0,0.8), xlim=c(0,1))
    
  qdif_abs9 <- ggplot(data= F01_A10_L100_M005_no0, aes(x=real_q_values, y=qdif_abs)) +
      labs(title = "F01_A10_L100_M005_no0", x= "real_q_values", y = "qdif_abs")  + theme_bw() + 
      geom_point(size=1, colour=I(alpha("blue",1/15))) + 
      geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(0,0.8), xlim=c(0,1))
    
  qdif_abs44 <- ggplot(data= F005_A5_L100_M005_no0, aes(x=real_q_values, y=qdif_abs)) +
      labs(title = "F005_A5_L100_M005_no0", x= "real_q_values", y = "qdif_abs")  + theme_bw() + 
      geom_point(size=1, colour=I(alpha("blue",1/15))) + 
      geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(0,0.8), xlim=c(0,1))
    
  qdif_abs45 <- ggplot(data= F005_A10_L100_M005_no0, aes(x=real_q_values, y=qdif_abs)) +
      labs(title = "F005_A10_L100_M005_no0", x= "real_q_values", y = "qdif_abs")  + theme_bw() + 
      geom_point(size=1, colour=I(alpha("blue",1/15))) + 
      geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(0,0.8), xlim=c(0,1))
    
  grid.arrange(qdif_abs26, qdif_abs27, qdif_abs8, qdif_abs9, qdif_abs44, qdif_abs45, top = "m 0.05")
    
    
    
  m005_no0_reg$qdif_abs <- abs(m005_no0_reg$qdif)
  m <- betareg(qdif_abs ~ Fst + alleles, m005_no0_reg)
      summary(m, type="pearson")
      res <- residuals(m, type= "pearson") #The higher Fst value and number of alleles, the better the estimate (lower absolute q difference). . 
      qqnorm(res); qqline(res)    #Good normality
      nrow(model.frame(m)) 
      
  ggplot(m005_no0_reg, aes(x = Fst, y = qdif_abs, group=Fst)) +
      labs(title = "m005_no0_reg", x= "Fst", y = "qdif_abs") +
      geom_point(shape= 16, size=1.5) +  theme_bw() + theme (text = element_text(size=22)) +
      scale_color_grey(start = 0, end = 0.65) + 
      geom_boxplot(outlier.size = 0, outlier.alpha = 0) + geom_point()
  
  ggplot(m005_no0_reg, aes(x = alleles, y = qdif_abs, group=alleles)) +
    labs(title = "m005_no0_reg", x= "alleles", y = "qdif_abs") +
    geom_point() +  theme_bw() + theme(text = element_text(size=22)) +
    geom_boxplot()
  
   
  
# m 0.01 ----
    
    qdif35 <- ggplot(data= F02_A5_L100_M001_no0, aes(x=real_q_values, y=qdif)) +
      labs(title = "F02_A5_L100_M001_no0", x= "real_q_values", y = "qdif")  + theme_bw() + 
      geom_point(size=1, colour=I(alpha("blue",1/15))) + 
      geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(-0.35,0.5), xlim=c(0,1))
    
    qdif36 <- ggplot(data= F02_A10_L100_M001_no0, aes(x=real_q_values, y=qdif)) +
      labs(title = "F02_A10_L100_M001_no0", x= "real_q_values", y = "qdif")  + theme_bw() + 
      geom_point(size=1, colour=I(alpha("blue",1/15))) + 
      geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(-0.35,0.5), xlim=c(0,1))
    
    qdif17 <- ggplot(data= F01_A5_L100_M001_no0, aes(x=real_q_values, y=qdif)) +
      labs(title = "F01_A5_L100_M001_no0", x= "real_q_values", y = "qdif")  + theme_bw() + 
      geom_point(size=1, colour=I(alpha("blue",1/15))) + 
      geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(-0.35,0.5), xlim=c(0,1))
    
    qdif18 <- ggplot(data= F01_A10_L100_M001_no0, aes(x=real_q_values, y=qdif)) +
      labs(title = "F01_A10_L100_M001_no0", x= "real_q_values", y = "qdif")  + theme_bw() + 
      geom_point(size=1, colour=I(alpha("blue",1/15))) + 
      geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(-0.35,0.5), xlim=c(0,1))
    
    qdif53 <- ggplot(data= F005_A5_L100_M001_no0, aes(x=real_q_values, y=qdif)) +
      labs(title = "F005_A5_L100_M001_no0", x= "real_q_values", y = "qdif")  + theme_bw() + 
      geom_point(size=1, colour=I(alpha("blue",1/15))) + 
      geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(-0.35,0.5), xlim=c(0,1))
    
    qdif54 <- ggplot(data= F005_A10_L100_M001_no0, aes(x=real_q_values, y=qdif)) +
      labs(title = "F005_A10_L100_M001_no0", x= "real_q_values", y = "qdif")  + theme_bw() + 
      geom_point(size=1, colour=I(alpha("blue",1/15))) + 
      geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(-0.35,0.5), xlim=c(0,1))
    
    
    grid.arrange(qdif35, qdif36, qdif17, qdif18, qdif53, qdif54, top = "m 0.01")
    
    
    F02_A5_L100_M001_no0$qdif_abs <- abs(F02_A5_L100_M001_no0$qdif)
    F02_A10_L100_M001_no0$qdif_abs <- abs(F02_A10_L100_M001_no0$qdif)
    F01_A5_L100_M001_no0$qdif_abs <- abs(F01_A5_L100_M001_no0$qdif)
    F01_A10_L100_M001_no0$qdif_abs <- abs(F01_A10_L100_M001_no0$qdif)
    F005_A5_L100_M001_no0$qdif_abs <- abs(F005_A5_L100_M001_no0$qdif)
    F005_A10_L100_M001_no0$qdif_abs <- abs(F005_A10_L100_M001_no0$qdif)    
    
    
    qdif_abs35 <- ggplot(data= F02_A5_L100_M001_no0, aes(x=real_q_values, y=qdif_abs)) +
      labs(title = "F02_A5_L100_M001_no0", x= "real_q_values", y = "qdif_abs")  + theme_bw() + 
      geom_point(size=1, colour=I(alpha("blue",1/15))) + 
      geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(0,0.8), xlim=c(0,1))
    
    qdif_abs36 <- ggplot(data= F02_A10_L100_M001_no0, aes(x=real_q_values, y=qdif_abs)) +
      labs(title = "F02_A10_L100_M001_no0", x= "real_q_values", y = "qdif_abs")  + theme_bw() + 
      geom_point(size=1, colour=I(alpha("blue",1/15))) + 
      geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(0,0.8), xlim=c(0,1))
    
    qdif_abs17 <- ggplot(data= F01_A5_L100_M001_no0, aes(x=real_q_values, y=qdif_abs)) +
      labs(title = "F01_A5_L100_M001_no0", x= "real_q_values", y = "qdif_abs")  + theme_bw() + 
      geom_point(size=1, colour=I(alpha("blue",1/15))) + 
      geom_abline(slope = 0, intercept = 0, color="blue")  + coord_cartesian(ylim=c(0,0.8), xlim=c(0,1))
    
    qdif_abs18 <- ggplot(data= F01_A10_L100_M001_no0, aes(x=real_q_values, y=qdif_abs)) +
      labs(title = "F01_A10_L100_M001_no0", x= "real_q_values", y = "qdif_abs")  + theme_bw() + 
      geom_point(size=1, colour=I(alpha("blue",1/15))) + 
      geom_abline(slope = 0, intercept = 0, color="blue")  + coord_cartesian(ylim=c(0,0.8), xlim=c(0,1))
    
    qdif_abs53 <- ggplot(data= F005_A5_L100_M001_no0, aes(x=real_q_values, y=qdif_abs)) +
      labs(title = "F005_A5_L100_M001_no0", x= "real_q_values", y = "qdif_abs")  + theme_bw() + 
      geom_point(size=1, colour=I(alpha("blue",1/15))) + 
      geom_abline(slope = 0, intercept = 0, color="blue") + coord_cartesian(ylim=c(0,0.8), xlim=c(0,1))
    
    qdif_abs54 <- ggplot(data= F005_A10_L100_M001_no0, aes(x=real_q_values, y=qdif_abs)) +
      labs(title = "F005_A10_L100_M001_no0", x= "real_q_values", y = "qdif_abs")  + theme_bw() + 
      geom_point(size=1, colour=I(alpha("blue",1/15))) + 
      geom_abline(slope = 0, intercept = 0, color="blue")  + coord_cartesian(ylim=c(0,0.8), xlim=c(0,1))   

    grid.arrange(qdif_abs35, qdif_abs36, qdif_abs17, qdif_abs18, qdif_abs53, qdif_abs54, top = "m 0.01")
    
    
    m001_no0_reg$qdif_abs <- abs(m001_no0_reg$qdif)
    m001_no0_reg$qdif_abs_t <- (m001_no0_reg$qdif_abs * (10000 - 1) + 0.5) / 10000
    
    m <- betareg(qdif_abs_t ~ alleles + Fst, m001_no0_reg)
    summary(m, type="pearson")
    res <- residuals(m, type= "pearson")
    qqnorm(res); qqline(res)  
    
    summary(m, type="weighted")
    res <- residuals(m, type= "weighted") 
    qqnorm(res); qqline(res)  
    
    summary(m, type="sweighted")
    res <- residuals(m, type= "sweighted") 
    qqnorm(res); qqline(res)
    
    summary(m, type="deviance")
    res <- residuals(m, type= "deviance") #The higher Fst value and number of alleles, the better the estimate (lower absolute q difference).  
    qqnorm(res); qqline(res) 
    